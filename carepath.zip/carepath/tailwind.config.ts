import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    container: { center: true, padding: "1.25rem", screens: { "2xl": "1240px" } },
    extend: {
      colors: {
        ink: { DEFAULT: "#0f2a3d", soft: "#34495c", muted: "#5b6b7a", faint: "#8a98a6" },
        sea: {
          50: "#effaf9", 100: "#d5f2ef", 200: "#aee5e0", 300: "#7dd1ca", 400: "#46b5ae",
          500: "#2a9a94", 600: "#1e7c79", 700: "#1b6462", 800: "#1a5050", 900: "#173f40",
        },
        calm: {
          50: "#f1f6ff", 100: "#e1ebfe", 200: "#c6d8fc", 300: "#9dbcf8", 400: "#7098f0",
          500: "#4f77e4", 600: "#3c5ccf", 700: "#334aa8", 800: "#2d3f86", 900: "#29386b",
        },
        lav: { 50: "#f7f6fe", 100: "#efedfc", 200: "#e0dbf8", 300: "#c8bff2", 400: "#a898e8" },
        mist: "#f6f9fb",
        line: "#e4ebf0",
      },
      fontFamily: {
        sans: ["'Plus Jakarta Sans'", "system-ui", "-apple-system", "Segoe UI", "sans-serif"],
        display: ["Fraunces", "Georgia", "serif"],
      },
      borderRadius: { xl: "14px", "2xl": "18px", "3xl": "24px" },
      boxShadow: {
        soft: "0 1px 2px rgba(15,42,61,0.04), 0 4px 16px rgba(15,42,61,0.05)",
        lift: "0 2px 4px rgba(15,42,61,0.04), 0 12px 32px rgba(15,42,61,0.08)",
        glow: "0 0 0 4px rgba(42,154,148,0.14)",
      },
      keyframes: {
        flow: { "0%": { strokeDashoffset: "24" }, "100%": { strokeDashoffset: "0" } },
        breathe: { "0%,100%": { transform: "scale(0.82)" }, "50%": { transform: "scale(1)" } },
        shimmer: { "0%": { backgroundPosition: "-400px 0" }, "100%": { backgroundPosition: "400px 0" } },
      },
      animation: {
        flow: "flow 1.2s linear infinite",
        breathe: "breathe 8s ease-in-out infinite",
        shimmer: "shimmer 1.4s linear infinite",
      },
    },
  },
  plugins: [],
};
export default config;
