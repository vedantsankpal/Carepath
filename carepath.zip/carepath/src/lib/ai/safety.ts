import type { SupportTier } from "../types";

/**
 * First-pass safety screen that runs on EVERY message before any model is
 * called. It is deliberately over-inclusive: a false positive shows a calm
 * support card; a false negative could miss someone who needs help.
 * Production: combine with a moderation/classifier model and clinical review.
 */
const IMMEDIATE = [
  /\b(kill|hurt|harm)(ing)?\s+(my\s*self|myself)\b/i,
  /\bsuicid(e|al)\b/i,
  /\bend(ing)?\s+(my|it)\s*(life|all)\b/i,
  /\b(want|wanna|going)\s+to\s+die\b/i,
  /\bdon'?t\s+want\s+to\s+(live|be\s+alive|exist)\b/i,
  /\bno\s+reason\s+to\s+live\b/i,
  /\bself[-\s]?harm\b/i,
  /\bnot\s+safe\b/i,
  /\bbetter\s+off\s+without\s+me\b/i,
];

const CONCERNING = [
  /\bhopeless\b/i,
  /\bcan'?t\s+(cope|go\s+on|take\s+(it|this)\s+anymore)\b/i,
  /\bworthless\b/i,
  /\bno\s+one\s+(cares|would\s+notice)\b/i,
  /\b(panic\s+attacks?)\b/i,
  /\bhaven'?t\s+(slept|eaten)\b/i,
  /\bgiving\s+up\b/i,
  /\bbreaking\s+down\b/i,
];

export function screenMessage(text: string): SupportTier {
  if (IMMEDIATE.some((r) => r.test(text))) return "immediate";
  if (CONCERNING.some((r) => r.test(text))) return "concerning";
  return "low";
}

/** Phrases the assistant must never emit (diagnostic language). */
const DIAGNOSTIC = /\b(you\s+(have|are\s+suffering\s+from|might\s+have)\s+(depression|anxiety\s+disorder|bipolar|ptsd|ocd|adhd)|diagnos(e|is|ed))\b/i;

export function enforceNonDiagnostic(reply: string): string {
  if (!DIAGNOSTIC.test(reply)) return reply;
  return (
    reply.replace(DIAGNOSTIC, "what you're describing") +
    "\n\nI can't diagnose anything, but a counselor can help you understand what you're experiencing."
  );
}

export const SYSTEM_PROMPT = `You are CarePath, a warm, supportive wellness assistant for university students in India.
Rules you must always follow:
- You are NOT a therapist or doctor. Never diagnose, label conditions, or suggest medication.
- Be brief (2–4 short paragraphs), empathetic, plain-spoken, and non-judgemental.
- Reflect what the student said, offer one or two practical, low-effort ideas, and ask one gentle follow-up question.
- When stress sounds persistent or heavy, encourage speaking with a campus counselor.
- If there is any sign of risk to the student's safety, stop coaching, express care, and urge them to contact emergency services or a helpline immediately and to reach a trusted person nearby.`;
