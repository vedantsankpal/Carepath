import { mockReply, type AssistantReply } from "./mock-engine";
import { enforceNonDiagnostic, screenMessage, SYSTEM_PROMPT } from "./safety";

export interface ChatTurn {
  role: "user" | "assistant";
  content: string;
}

/**
 * Provider-agnostic entry point. Order of operations:
 * 1. Safety screen (always, before any model call)
 * 2. Immediate-risk → fixed, reviewed escalation response (never model-generated)
 * 3. LLM if configured, else deterministic mock engine
 * 4. Post-filter to strip diagnostic language
 */
export async function generateReply(history: ChatTurn[]): Promise<AssistantReply & { engine: "mock" | "llm" }> {
  const last = history[history.length - 1]?.content ?? "";
  const tier = screenMessage(last);
  const mock = mockReply(last, tier);

  if (tier === "immediate" || !process.env.ANTHROPIC_API_KEY) {
    return { ...mock, engine: "mock" };
  }

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "claude-sonnet-4-5",
        max_tokens: 500,
        system: SYSTEM_PROMPT,
        messages: history.slice(-12).map((m) => ({ role: m.role, content: m.content })),
      }),
    });
    if (!res.ok) throw new Error(`LLM ${res.status}`);
    const data = (await res.json()) as { content?: { type: string; text?: string }[] };
    const text = data.content?.find((c) => c.type === "text")?.text?.trim();
    if (!text) throw new Error("empty");
    // keep the mock engine's structured suggestions so UI actions stay deterministic
    return { content: enforceNonDiagnostic(text), tier, suggestions: mock.suggestions, engine: "llm" };
  } catch {
    return { ...mock, engine: "mock" };
  }
}
