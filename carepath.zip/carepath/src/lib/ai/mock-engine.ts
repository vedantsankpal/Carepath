import type { ChatSuggestion, SupportTier } from "../types";

export interface AssistantReply {
  content: string;
  tier: SupportTier;
  suggestions: ChatSuggestion[];
}

interface Intent {
  match: RegExp;
  reply: string[];
  suggestions: ChatSuggestion[];
}

const INTENTS: Intent[] = [
  {
    match: /overwhelm|too much|so much|drowning|burn(ed|t)?\s*out/i,
    reply: [
      "That sounds like a lot to be carrying right now, and it makes sense that you're feeling overwhelmed. College can pile things up quickly — classes, deadlines, expectations, and everything happening outside of it too.",
      "One thing that often helps is getting everything out of your head and onto paper, then choosing just *one* small next step. You don't have to solve it all today.",
      "Would it help to talk through what's weighing on you most right now — is it mostly academic, or is there more going on?",
    ],
    suggestions: [
      { kind: "resource", resourceId: "deadline-planner", label: "Untangle a deadline pile-up · 7 min" },
      { kind: "resource", resourceId: "breathing-2min", label: "2-minute breathing reset" },
      { kind: "counselor", label: "Talk to a counselor" },
    ],
  },
  {
    match: /exam|academic|grades?|marks|assignment|deadline|semester|results?|cgpa|placement/i,
    reply: [
      "Academic pressure can feel intense — especially when it seems like your future depends on every result. That pressure is real, and it's okay to find it hard.",
      "It may help to separate the facts (what's due, when) from the fears (what you imagine might happen). Then pick the single next thing you can do in the next 30 minutes.",
      "If you're comfortable, what's the next deadline or exam on your mind?",
    ],
    suggestions: [
      { kind: "resource", resourceId: "exam-reset", label: "Exam stress reset · 5 min" },
      { kind: "resource", resourceId: "deadline-planner", label: "Untangle a deadline pile-up" },
      { kind: "checkin", label: "Do a 2-minute check-in" },
    ],
  },
  {
    match: /stress|stressed|pressure|tense|anxious|nervous|worried|worry/i,
    reply: [
      "Thank you for sharing that. Feeling stressed is a really common response when a lot is being asked of you — it's your mind and body trying to keep up.",
      "A quick reset can take the edge off: a couple of minutes of slow breathing, stepping outside, or loosening your shoulders. After that, it's often easier to see what's actually urgent.",
      "What do you think is driving the stress most right now?",
    ],
    suggestions: [
      { kind: "resource", resourceId: "breathing-2min", label: "2-minute breathing exercise" },
      { kind: "resource", resourceId: "understanding-stress", label: "Understanding your stress" },
    ],
  },
  {
    match: /lonely|alone|isolated|no friends|homesick|left out/i,
    reply: [
      "Feeling lonely can be really painful, and I'm glad you said it out loud. A lot of students feel this way — especially when they're far from home or in a new environment — even if it doesn't look like it from the outside.",
      "Connection often starts small: one message to someone you miss, sitting with a classmate, or joining something where there's an activity to share.",
      "Is there anyone — even one person — you'd feel comfortable reaching out to this week?",
    ],
    suggestions: [
      { kind: "resource", resourceId: "lonely-connect", label: "Small steps to feel less alone" },
      { kind: "counselor", label: "Talk to someone at the counselling centre" },
    ],
  },
  {
    match: /focus|concentrat|distract|procrastinat|can'?t study/i,
    reply: [
      "Struggling to focus is frustrating — especially when you know what you need to do. It often happens when we're tired, stressed, or facing a task that feels too big.",
      "Try shrinking the task: set a 15-minute timer for one small piece, and put your phone out of reach. Short, focused sprints with real breaks usually beat long, distracted hours.",
      "How has your sleep been lately? That can make a big difference to concentration.",
    ],
    suggestions: [
      { kind: "resource", resourceId: "focus-reset", label: "Focus reset · 4 min" },
      { kind: "resource", resourceId: "pomodoro", label: "Study sprints that stick" },
    ],
  },
  {
    match: /sleep|insomnia|tired|exhausted|awake|night/i,
    reply: [
      "Not sleeping well makes everything else feel harder — mood, focus, patience. Late-night studying and a racing mind are a tough combination.",
      "A short wind-down can help: screens away for 20 minutes, jot down tomorrow's top three tasks so your mind can let go of them, and try a slow body scan.",
      "Has this been going on for a while, or is it mostly around exams?",
    ],
    suggestions: [
      { kind: "resource", resourceId: "sleep-winddown", label: "Wind-down for better sleep" },
      { kind: "resource", resourceId: "body-scan", label: "10-minute body scan" },
    ],
  },
  {
    match: /family|parents?|home|mom|dad|mother|father/i,
    reply: [
      "Family can be a big source of support and, at the same time, a source of pressure. Both can be true at once.",
      "It might help to notice which expectations feel like yours, and which feel like someone else's. A counselor can also help you plan a difficult conversation if there's one you've been avoiding.",
      "What's been happening with your family that's on your mind?",
    ],
    suggestions: [
      { kind: "resource", resourceId: "family-pressure", label: "Navigating family expectations" },
      { kind: "counselor", label: "Talk it through with a counselor" },
    ],
  },
  {
    match: /money|fees|financ|loan|afford|broke/i,
    reply: [
      "Money worries can quietly affect everything — sleep, focus, and how you feel about the future. You're not alone in this.",
      "It can help to write down the actual numbers separately from the worries, and to check with your institution's scholarship or fee office — many students are eligible for support they don't know about.",
      "Would you like some ideas for where to start on campus?",
    ],
    suggestions: [{ kind: "resource", resourceId: "money-stress", label: "When money worries weigh on you" }],
  },
  {
    match: /talk to (someone|a person|a counsel|a human)|counsel(l)?or|therapist|professional|real person/i,
    reply: [
      "That's a really good step, and I'm glad you're thinking about it. Talking to a trained counselor gives you space to be heard by someone who can support you properly.",
      "You can book a session in under a minute — choose video, chat or in-person, and pick a time that works for you. You decide what you share.",
    ],
    suggestions: [{ kind: "counselor", label: "Book a counselor session" }],
  },
  {
    match: /^(hi|hello|hey|namaste|good (morning|evening|afternoon))\b/i,
    reply: [
      "Hi, I'm glad you're here. This is a private space to talk about whatever's on your mind — big or small.",
      "How are you feeling today?",
    ],
    suggestions: [{ kind: "checkin", label: "Start a 2-minute check-in" }],
  },
  {
    match: /thank|thanks|better|helpful|that helps/i,
    reply: [
      "I'm really glad that helped a little. Small steps count.",
      "I'm here whenever you want to talk again — and if things start to feel heavier, a counselor is always an option too.",
    ],
    suggestions: [{ kind: "checkin", label: "Log how you feel now" }],
  },
];

const FALLBACK: AssistantReply = {
  content:
    "Thank you for sharing that with me. I'm here to listen, and there's no right or wrong way to say how you feel.\n\nCould you tell me a little more about what's been going on — and how long it's been feeling this way?",
  tier: "low",
  suggestions: [
    { kind: "checkin", label: "Do a 2-minute check-in" },
    { kind: "resource", resourceId: "emotions-wheel", label: "Naming what you feel" },
  ],
};

export function mockReply(text: string, tier: SupportTier): AssistantReply {
  if (tier === "immediate") {
    return {
      content:
        "I'm really glad you told me, and I'm sorry you're going through this. What you're feeling matters, and you deserve support from a real person right now.\n\nIf you might be in danger or could act on these thoughts, please call emergency services (112) or a 24×7 helpline now, and let someone nearby — a friend, roommate, warden or family member — know you need them.\n\nYou don't have to go through this alone. Would you be willing to reach out to one of those contacts now?",
      tier,
      suggestions: [
        { kind: "safety", label: "Get help now" },
        { kind: "counselor", label: "Request an urgent counselor callback" },
      ],
    };
  }

  const intent = INTENTS.find((i) => i.match.test(text));
  const base = intent
    ? { content: intent.reply.join("\n\n"), tier, suggestions: intent.suggestions }
    : { ...FALLBACK, tier };

  if (tier === "concerning") {
    return {
      ...base,
      content:
        base.content +
        "\n\nIt sounds like this has been really heavy. I think it would help to talk with a counselor — they're trained for exactly this, and you don't need to have the right words first.",
      suggestions: [{ kind: "counselor" as const, label: "Connect with a counselor" } as ChatSuggestion, ...base.suggestions.filter((s) => s.kind !== "counselor")].slice(0, 3),
    };
  }
  return base;
}
