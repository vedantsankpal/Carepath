/**
 * SAMPLE aggregated data for the university & counselor dashboards.
 * Values are illustrative demo figures, not real-world statistics.
 * In production these come from aggregate queries with k-anonymity
 * thresholds (groups smaller than K are suppressed) — see ARCHITECTURE.md.
 */

export const K_ANONYMITY_THRESHOLD = 10;

export const CAMPUS_OVERVIEW = {
  checkIns: 3842,
  checkInsDelta: 12,
  activeStudents: 1206,
  resourceSessions: 5210,
  resourceDelta: 18,
  bookings: 214,
  bookingsDelta: 9,
  feedback: 167,
  feedbackDelta: -4,
};

export const CAMPUS_WEEKLY = [
  { week: "Aug 04", wellbeing: 3.6, checkIns: 612, bookings: 28 },
  { week: "Aug 11", wellbeing: 3.5, checkIns: 640, bookings: 31 },
  { week: "Aug 18", wellbeing: 3.4, checkIns: 701, bookings: 34 },
  { week: "Aug 25", wellbeing: 3.1, checkIns: 820, bookings: 41 },
  { week: "Sep 01", wellbeing: 3.0, checkIns: 866, bookings: 46 },
  { week: "Sep 08", wellbeing: 3.2, checkIns: 790, bookings: 38 },
  { week: "Sep 15", wellbeing: 3.4, checkIns: 742, bookings: 33 },
  { week: "Sep 22", wellbeing: 3.5, checkIns: 718, bookings: 30 },
];

export const CAMPUS_CATEGORIES = [
  { name: "Academics", value: 41 },
  { name: "Sleep", value: 18 },
  { name: "General stress", value: 14 },
  { name: "Loneliness", value: 11 },
  { name: "Relationships", value: 8 },
  { name: "Family", value: 5 },
  { name: "Financial", value: 3 },
];

export const CAMPUS_RESOURCE_USAGE = [
  { name: "Breathing", sessions: 1320 },
  { name: "Exam Reset", sessions: 980 },
  { name: "Sleep Wind-Down", sessions: 760 },
  { name: "Focus Reset", sessions: 690 },
  { name: "Mindfulness", sessions: 610 },
  { name: "Anxious Thoughts", sessions: 480 },
];

export const CAMPUS_BY_YEAR = [
  { group: "1st year", participation: 38 },
  { group: "2nd year", participation: 31 },
  { group: "3rd year", participation: 27 },
  { group: "4th year", participation: 22 },
  { group: "PG", participation: 19 },
];

export const FEEDBACK_THEMES = [
  { theme: "More evening counselor slots", count: 34, trend: "up" as const },
  { theme: "Quieter study spaces during exams", count: 27, trend: "up" as const },
  { theme: "Resources in regional languages", count: 21, trend: "flat" as const },
  { theme: "Hostel mess timings & sleep", count: 12, trend: "down" as const },
];

/** Counselor-side queue — pseudonymous IDs, consented context only. */
export const COUNSELOR_REQUESTS = [
  {
    id: "S-4821",
    requested: "Today, 10:12",
    preferred: "Video · this week",
    priority: "priority" as const,
    context: { sharing: true, recentTrend: "Lower mood for 5 of last 7 check-ins", themes: ["Academics", "Sleep"], note: "Routed after check-in suggested counselor support." },
  },
  {
    id: "S-3307",
    requested: "Today, 09:40",
    preferred: "In person · any",
    priority: "standard" as const,
    context: { sharing: true, recentTrend: "Stable, occasional stress spikes", themes: ["Relationships"], note: "Self-referred from Counselor Connect." },
  },
  {
    id: "S-5190",
    requested: "Yesterday, 18:05",
    preferred: "Chat · evenings",
    priority: "standard" as const,
    context: { sharing: false, recentTrend: "", themes: [], note: "Student chose not to share check-in context." },
  },
];

export const COUNSELOR_APPOINTMENTS = [
  { id: "a1", time: "10:30", student: "S-2144", type: "Video", topic: "Follow-up · exam planning" },
  { id: "a2", time: "12:00", student: "S-0987", type: "In person", topic: "First session" },
  { id: "a3", time: "14:00", student: "S-3552", type: "Chat", topic: "Follow-up · sleep routine" },
  { id: "a4", time: "16:30", student: "S-4410", type: "Video", topic: "First session" },
];
