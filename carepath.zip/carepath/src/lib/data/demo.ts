import type { CheckIn, Intensity, MoodLevel, StressFactor } from "../types";
import { addDays } from "../utils";

/**
 * Demo history for the sample student "Aarav". Deterministic so every demo
 * looks the same: a stressful exam fortnight, then gradual improvement.
 */
export function buildDemoCheckIns(): CheckIn[] {
  const moods: MoodLevel[] = [4, 4, 3, 4, 3, 3, 2, 3, 2, 2, 3, 2, 3, 3, 4, 3, 3, 4, 3, 4, 4, 3, 4, 4, 3, 4, 4, 4, 3];
  const intens: Intensity[] = [2, 2, 3, 2, 3, 3, 4, 3, 4, 4, 4, 4, 3, 3, 2, 3, 3, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 2, 3];
  const factorSets: StressFactor[][] = [
    ["academics"], ["sleep"], ["academics", "sleep"], ["general"], ["academics"], ["loneliness"],
    ["academics", "sleep"], ["academics"], ["academics", "family"], ["academics", "sleep"],
  ];
  const skip = new Set([5, 12, 19, 24]); // a few missed days feel realistic
  const today = new Date();
  const out: CheckIn[] = [];
  moods.forEach((mood, i) => {
    if (skip.has(i)) return;
    const d = addDays(today, -(moods.length - i));
    d.setHours(20, 15, 0, 0);
    const intensity = intens[i];
    out.push({
      id: `demo_ci_${i}`,
      date: d.toISOString(),
      mood,
      intensity,
      factors: factorSets[i % factorSets.length],
      feelsUnsafe: "no",
      tier: mood <= 2 || intensity >= 4 ? "moderate" : "low",
    });
  });
  return out;
}

/** Resources the demo student has used, for "What has helped you recently?" */
export const DEMO_RESOURCE_USAGE: { resourceId: string; uses: number; helpful: number }[] = [
  { resourceId: "breathing-2min", uses: 9, helpful: 8 },
  { resourceId: "exam-reset", uses: 5, helpful: 4 },
  { resourceId: "sleep-winddown", uses: 4, helpful: 3 },
  { resourceId: "focus-reset", uses: 3, helpful: 2 },
  { resourceId: "mindful-break", uses: 2, helpful: 2 },
];

export const DEMO_SUPPORT_USAGE = [
  { week: "Wk 1", assistant: 2, resources: 3, counselor: 0 },
  { week: "Wk 2", assistant: 4, resources: 5, counselor: 0 },
  { week: "Wk 3", assistant: 3, resources: 6, counselor: 1 },
  { week: "Wk 4", assistant: 2, resources: 4, counselor: 1 },
];
