import type { Counselor } from "../types";
import { addDays, toISODate } from "../utils";

const SLOTS = ["09:30", "10:30", "11:30", "13:00", "14:00", "15:30", "16:30"];

/** Deterministic pseudo-availability for the next 14 days (weekdays + Saturday). */
function buildAvailability(seed: number): Record<string, string[]> {
  const out: Record<string, string[]> = {};
  const today = new Date();
  for (let i = 1; i <= 14; i++) {
    const d = addDays(today, i);
    if (d.getDay() === 0) continue; // Sundays closed
    const slots = SLOTS.filter((_, idx) => (idx + i + seed) % 3 !== 0);
    if ((i + seed) % 5 === 0) continue; // some full days
    out[toISODate(d)] = slots;
  }
  return out;
}

export const COUNSELORS: Counselor[] = [
  {
    id: "c-ananya",
    name: "Dr. Ananya Rao",
    title: "Clinical Psychologist",
    specializations: ["Academic stress", "Anxiety", "Transitions"],
    languages: ["English", "Hindi", "Kannada"],
    sessionTypes: ["Video", "In person"],
    bio: "Works with students navigating exam pressure, first-year transitions and anxious thinking.",
    nextAvailable: "Tomorrow",
    availability: buildAvailability(1),
    initials: "AR",
    tint: "bg-sea-100 text-sea-800",
  },
  {
    id: "c-rahul",
    name: "Rahul Mehta",
    title: "Counselling Psychologist",
    specializations: ["Relationships", "Loneliness", "Family"],
    languages: ["English", "Hindi", "Gujarati"],
    sessionTypes: ["Video", "Chat", "In person"],
    bio: "Supports students with relationship concerns, homesickness and family expectations.",
    nextAvailable: "Tomorrow",
    availability: buildAvailability(2),
    initials: "RM",
    tint: "bg-calm-100 text-calm-800",
  },
  {
    id: "c-sneha",
    name: "Sneha Kulkarni",
    title: "Student Wellbeing Counselor",
    specializations: ["Sleep & routine", "Focus", "Burnout"],
    languages: ["English", "Marathi", "Hindi"],
    sessionTypes: ["In person", "Chat"],
    bio: "Helps students rebuild routines, manage workload and recover from burnout.",
    nextAvailable: "In 2 days",
    availability: buildAvailability(3),
    initials: "SK",
    tint: "bg-lav-100 text-[#4b3f8f]",
  },
  {
    id: "c-joseph",
    name: "Dr. Joseph Thomas",
    title: "Psychiatric Social Worker",
    specializations: ["Crisis follow-up", "Grief", "Financial stress"],
    languages: ["English", "Malayalam", "Tamil"],
    sessionTypes: ["Video", "In person"],
    bio: "Provides follow-up support after difficult experiences and connects students with campus services.",
    nextAvailable: "Tomorrow",
    availability: buildAvailability(4),
    initials: "JT",
    tint: "bg-amber-100 text-amber-900",
  },
];

export const getCounselor = (id: string) => COUNSELORS.find((c) => c.id === id);
