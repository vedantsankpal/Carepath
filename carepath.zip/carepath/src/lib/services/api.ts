"use client";

/**
 * Client service layer. Every UI call goes through here, so swapping the
 * Next.js API routes for an external Express/FastAPI backend is a one-line
 * change to BASE_URL. Each call falls back to local logic if the network
 * fails, so a live demo never dead-ends.
 */
import type { AssistantReply } from "../ai/mock-engine";
import { mockReply } from "../ai/mock-engine";
import { screenMessage } from "../ai/safety";
import { assessSupportTier, recommendResources } from "../assessment";
import type { Booking, CheckIn, FeedbackItem, Intensity, MoodLevel, StressFactor, SupportTier } from "../types";
import { sleep, uid } from "../utils";

const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? "/api";

async function post<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(data.error ?? "Something went wrong", res.status);
  return data as T;
}

export class ApiError extends Error {
  constructor(message: string, public status: number) {
    super(message);
  }
}

export async function sendChat(history: { role: "user" | "assistant"; content: string }[]): Promise<AssistantReply & { engine?: string }> {
  try {
    const [reply] = await Promise.all([post<AssistantReply>("/chat", { messages: history }), sleep(700)]);
    return reply;
  } catch (e) {
    if (e instanceof ApiError && e.status < 500) throw e;
    await sleep(700);
    const last = history[history.length - 1].content;
    return mockReply(last, screenMessage(last));
  }
}

export async function submitCheckIn(input: {
  mood: MoodLevel;
  intensity: Intensity;
  factors: StressFactor[];
  feelsUnsafe: CheckIn["feelsUnsafe"];
  recent: CheckIn[];
}): Promise<{ tier: SupportTier; resources: string[] }> {
  try {
    const [r] = await Promise.all([post<{ tier: SupportTier; resources: string[] }>("/check-in", input), sleep(900)]);
    return r;
  } catch {
    return { tier: assessSupportTier(input), resources: recommendResources(input.factors).map((r) => r.id) };
  }
}

export async function createBooking(input: Omit<Booking, "id" | "status" | "createdAt">): Promise<Booking> {
  try {
    const { booking } = await post<{ booking: Booking }>("/bookings", input);
    await sleep(500);
    return booking;
  } catch (e) {
    if (e instanceof ApiError && e.status < 500) throw e;
    return { ...input, id: uid("bk"), status: "confirmed", createdAt: new Date().toISOString() };
  }
}

export async function submitFeedback(input: Omit<FeedbackItem, "id" | "createdAt">) {
  await sleep(600);
  return post<{ ok: true; id: string }>("/feedback", input);
}
