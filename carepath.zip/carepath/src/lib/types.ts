/**
 * Domain models. Shapes are kept flat and serialisable so they map 1:1 to
 * PostgreSQL tables or Firestore documents later (see /docs/ARCHITECTURE.md).
 */

export type MoodLevel = 1 | 2 | 3 | 4 | 5; // 1 = Very low … 5 = Great
export type Intensity = 1 | 2 | 3 | 4 | 5; // 1 = Very mild … 5 = Overwhelming

export type SupportTier = "low" | "moderate" | "concerning" | "immediate";

export type StressFactor =
  | "academics"
  | "relationships"
  | "family"
  | "loneliness"
  | "sleep"
  | "financial"
  | "general"
  | "other";

export type Role = "student" | "counselor" | "university_admin";

export interface Session {
  id: string;
  role: Role;
  mode: "anonymous" | "account";
  displayName: string;
  email?: string;
  institution?: string;
  consent: ConsentRecord | null;
  createdAt: string;
}

export interface ConsentRecord {
  version: string;
  acceptedAt: string;
  aiNotReplacement: boolean;
  dataProcessing: boolean;
  shareWithCounselor: boolean; // opt-in: counselor sees check-in context on booking
  anonymousAnalytics: boolean; // opt-in: contributes to aggregate campus insights
}

export interface CheckIn {
  id: string;
  date: string; // ISO
  mood: MoodLevel;
  intensity: Intensity;
  factors: StressFactor[];
  feelsUnsafe: "no" | "yes" | "unsure" | null;
  note?: string;
  tier: SupportTier;
}

export type ResourceCategory =
  | "Stress"
  | "Anxiety"
  | "Academic Pressure"
  | "Sleep"
  | "Relationships"
  | "Focus"
  | "Mindfulness"
  | "Emotional Well-being";

export type ResourceFormat = "exercise" | "guide" | "audio" | "article";

export interface ResourceStep {
  title: string;
  body: string;
  seconds?: number;
}

export interface Resource {
  id: string;
  title: string;
  description: string;
  minutes: number;
  category: ResourceCategory;
  format: ResourceFormat;
  tags: StressFactor[];
  steps: ResourceStep[];
  breathing?: boolean;
}

export type SessionType = "Video" | "In person" | "Chat";

export interface Counselor {
  id: string;
  name: string;
  title: string;
  specializations: string[];
  languages: string[];
  sessionTypes: SessionType[];
  bio: string;
  nextAvailable: string; // human label
  availability: Record<string, string[]>; // yyyy-mm-dd -> ["10:00", …]
  initials: string;
  tint: string;
}

export interface Booking {
  id: string;
  counselorId: string;
  date: string; // yyyy-mm-dd
  time: string; // HH:mm
  sessionType: SessionType;
  shareCheckInContext: boolean;
  reason?: string;
  status: "confirmed" | "requested" | "cancelled";
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
  tier?: SupportTier;
  suggestions?: ChatSuggestion[];
}

export type ChatSuggestion =
  | { kind: "resource"; resourceId: string; label: string }
  | { kind: "counselor"; label: string }
  | { kind: "safety"; label: string }
  | { kind: "checkin"; label: string };

export type FeedbackKind = "feedback" | "campus" | "resource" | "counselor";

export interface FeedbackItem {
  id: string;
  kind: FeedbackKind;
  message: string;
  rating?: number;
  anonymous: boolean;
  createdAt: string;
}

export interface HelpContact {
  id: string;
  name: string;
  description: string;
  phone?: string;
  hours: string;
  kind: "emergency" | "helpline" | "campus";
}
