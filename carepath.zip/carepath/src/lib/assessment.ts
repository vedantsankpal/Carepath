import type { CheckIn, Intensity, MoodLevel, StressFactor, SupportTier } from "./types";
import { RESOURCES } from "./data/resources";

/**
 * Rule-based support routing — NOT a diagnostic or clinical instrument.
 * It only decides which level of support to *offer*. Thresholds are
 * intentionally conservative (they route toward humans sooner rather than later)
 * and should be reviewed by the institution's clinical team before a pilot.
 */
export function assessSupportTier(input: {
  mood: MoodLevel;
  intensity: Intensity;
  feelsUnsafe: CheckIn["feelsUnsafe"];
  recent?: CheckIn[];
}): SupportTier {
  if (input.feelsUnsafe === "yes") return "immediate";
  if (input.feelsUnsafe === "unsure") return "concerning";

  const lowStreak = (input.recent ?? []).slice(-3).filter((c) => c.mood <= 2).length;
  if (input.intensity >= 5 && input.mood <= 2) return "concerning";
  if (input.mood === 1 && input.intensity >= 4) return "concerning";
  if (lowStreak >= 2 && input.mood <= 2) return "concerning";
  if (input.intensity >= 4 || input.mood <= 2) return "moderate";
  return "low";
}

export const TIER_COPY: Record<SupportTier, { title: string; body: string; tone: "sea" | "calm" | "amber" | "rose" }> = {
  low: {
    title: "Here are some resources that may help.",
    body: "It sounds like you're managing. A few short practices can help you keep things steady.",
    tone: "sea",
  },
  moderate: {
    title: "Here are some resources that may help.",
    body: "Things feel heavier right now. These short, practical resources are a good place to start — and a counselor is always an option.",
    tone: "calm",
  },
  concerning: {
    title: "You may benefit from speaking with a counselor.",
    body: "What you're carrying sounds like a lot to hold on your own. Talking with a trained counselor can help — you don't need to have everything figured out first.",
    tone: "amber",
  },
  immediate: {
    title: "Let's get you support right now.",
    body: "Thank you for telling us. Your safety matters most. Please reach out to one of the people below — you don't have to go through this alone.",
    tone: "rose",
  },
};

export function recommendResources(factors: StressFactor[], limit = 3) {
  const scored = RESOURCES.map((r) => ({
    r,
    score: r.tags.filter((t) => factors.includes(t)).length + (r.minutes <= 3 ? 0.3 : 0),
  }))
    .sort((a, b) => b.score - a.score)
    .map((x) => x.r);
  return scored.slice(0, limit);
}

export const MOODS: { value: MoodLevel; emoji: string; label: string }[] = [
  { value: 5, emoji: "😀", label: "Great" },
  { value: 4, emoji: "🙂", label: "Good" },
  { value: 3, emoji: "😐", label: "Okay" },
  { value: 2, emoji: "😟", label: "Low" },
  { value: 1, emoji: "😞", label: "Very low" },
];

export const FACTORS: { value: StressFactor; label: string }[] = [
  { value: "academics", label: "Academics" },
  { value: "relationships", label: "Relationships" },
  { value: "family", label: "Family" },
  { value: "loneliness", label: "Loneliness" },
  { value: "sleep", label: "Sleep" },
  { value: "financial", label: "Financial concerns" },
  { value: "general", label: "General stress" },
  { value: "other", label: "Other" },
];

export const INTENSITY_LABELS: Record<Intensity, string> = {
  1: "Very mild",
  2: "Mild",
  3: "Noticeable",
  4: "Strong",
  5: "Overwhelming",
};
