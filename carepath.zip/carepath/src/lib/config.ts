import type { HelpContact } from "./types";

export const APP = {
  name: "CarePath",
  tagline: "Detect early. Support instantly. Connect when it matters.",
  institution: "Demo University",
  consentVersion: "2026.09",
};

/**
 * INSTITUTION-CONFIGURABLE help contacts.
 *
 * These are placeholders for a demo. Before any real deployment the partner
 * institution must review and replace them with approved, verified contacts.
 * National numbers below were publicly listed as of Sept 2026 — re-verify
 * them on the official source before launch.
 */
export const HELP_CONTACTS: HelpContact[] = [
  {
    id: "emergency",
    name: "National Emergency Number",
    description: "Police, fire and ambulance — for immediate danger.",
    phone: "112",
    hours: "24 × 7",
    kind: "emergency",
  },
  {
    id: "tele-manas",
    name: "Tele-MANAS (Govt. of India)",
    description: "Free mental-health support in multiple Indian languages.",
    phone: "14416",
    hours: "24 × 7",
    kind: "helpline",
  },
  {
    id: "campus-counselling",
    name: "Campus Counselling Centre",
    description: "Configure with your institution's counselling desk number.",
    phone: "+91 00000 00000",
    hours: "Mon–Sat · 9:00–18:00",
    kind: "campus",
  },
  {
    id: "campus-warden",
    name: "Hostel Warden / Campus Security",
    description: "Configure with the on-duty campus safety contact.",
    phone: "+91 00000 00001",
    hours: "24 × 7",
    kind: "campus",
  },
];

export const HELP_CONTACTS_NOTE =
  "Contacts are configurable by your institution. Numbers marked 00000 are demo placeholders.";

export const DISCLAIMER =
  "This AI provides general support and does not replace a qualified mental-health professional.";

export const PRINCIPLE = "AI supports, never diagnoses. Human professionals remain in the loop.";
