import type { CheckIn, StressFactor } from "./types";
import { addDays, toISODate } from "./utils";

export function trendSeries(checkIns: CheckIn[], days: number) {
  const byDay = new Map<string, CheckIn>();
  checkIns.forEach((c) => byDay.set(toISODate(new Date(c.date)), c)); // latest per day wins
  const today = new Date();
  return Array.from({ length: days }, (_, i) => {
    const d = addDays(today, -(days - 1 - i));
    const c = byDay.get(toISODate(d));
    return {
      date: toISODate(d),
      label: days <= 7 ? d.toLocaleDateString("en-IN", { weekday: "short" }) : d.toLocaleDateString("en-IN", { day: "numeric", month: "short" }),
      mood: c ? c.mood : null,
      stress: c ? c.intensity : null,
    };
  });
}

export function summary(checkIns: CheckIn[], days = 7) {
  const cutoff = addDays(new Date(), -days).getTime();
  const prevCutoff = addDays(new Date(), -days * 2).getTime();
  const cur = checkIns.filter((c) => new Date(c.date).getTime() >= cutoff);
  const prev = checkIns.filter((c) => {
    const t = new Date(c.date).getTime();
    return t >= prevCutoff && t < cutoff;
  });
  const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);
  const moodAvg = avg(cur.map((c) => c.mood));
  const prevMood = avg(prev.map((c) => c.mood));
  const stressAvg = avg(cur.map((c) => c.intensity));
  const prevStress = avg(prev.map((c) => c.intensity));
  const days_ = new Set(cur.map((c) => toISODate(new Date(c.date)))).size;
  return {
    count: cur.length,
    daysCheckedIn: days_,
    consistency: Math.round((days_ / days) * 100),
    moodAvg,
    moodDelta: moodAvg !== null && prevMood !== null ? moodAvg - prevMood : null,
    stressAvg,
    stressDelta: stressAvg !== null && prevStress !== null ? stressAvg - prevStress : null,
  };
}

export function streak(checkIns: CheckIn[]) {
  const days = new Set(checkIns.map((c) => toISODate(new Date(c.date))));
  let n = 0;
  let d = new Date();
  if (!days.has(toISODate(d))) d = addDays(d, -1);
  while (days.has(toISODate(d))) {
    n++;
    d = addDays(d, -1);
  }
  return n;
}

export function topFactors(checkIns: CheckIn[], limit = 4) {
  const counts = new Map<StressFactor, number>();
  checkIns.forEach((c) => c.factors.forEach((f) => counts.set(f, (counts.get(f) ?? 0) + 1)));
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit);
}

export function moodWord(avg: number | null) {
  if (avg === null) return "—";
  if (avg >= 4.3) return "Great";
  if (avg >= 3.5) return "Good";
  if (avg >= 2.7) return "Okay";
  if (avg >= 1.8) return "Low";
  return "Very low";
}
