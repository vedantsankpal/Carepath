"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { APP } from "./config";
import { buildDemoCheckIns } from "./data/demo";
import type { Booking, ChatMessage, CheckIn, ConsentRecord, Session } from "./types";
import { addDays, toISODate, uid } from "./utils";
import { COUNSELORS } from "./data/counselors";

interface Toast {
  id: string;
  title: string;
  body?: string;
  tone?: "success" | "info" | "warning";
}

interface State {
  session: Session | null;
  checkIns: CheckIn[];
  bookings: Booking[];
  chat: ChatMessage[];
  completedResources: string[];
  savedResources: string[];
  demoStep: number | null; // null = demo guide hidden
  prefs: { reminders: boolean; reduceMotion: boolean; anonymousMode: boolean };
}

const STORAGE_KEY = "carepath.v1";

const initialState: State = {
  session: null,
  checkIns: [],
  bookings: [],
  chat: [],
  completedResources: [],
  savedResources: [],
  demoStep: null,
  prefs: { reminders: true, reduceMotion: false, anonymousMode: false },
};

function demoBooking(): Booking {
  const c = COUNSELORS[0];
  const dates = Object.keys(c.availability).sort();
  const date = dates[1] ?? toISODate(addDays(new Date(), 2));
  return {
    id: "demo_bk_1",
    counselorId: c.id,
    date,
    time: c.availability[date]?.[1] ?? "11:30",
    sessionType: "Video",
    shareCheckInContext: true,
    reason: "Exam stress follow-up",
    status: "confirmed",
    createdAt: new Date().toISOString(),
  };
}

interface Ctx extends State {
  hydrated: boolean;
  signIn: (s: Omit<Session, "id" | "createdAt" | "consent" | "role"> & { role?: Session["role"] }) => void;
  giveConsent: (c: Omit<ConsentRecord, "version" | "acceptedAt">) => void;
  signOut: () => void;
  startDemo: () => void;
  setDemoStep: (n: number | null) => void;
  advanceDemo: (n: number) => void;
  addCheckIn: (c: CheckIn) => void;
  addBooking: (b: Booking) => void;
  cancelBooking: (id: string) => void;
  setChat: (updater: (prev: ChatMessage[]) => ChatMessage[]) => void;
  completeResource: (id: string) => void;
  toggleSaved: (id: string) => void;
  updatePrefs: (p: Partial<State["prefs"]>) => void;
  updateConsent: (p: Partial<ConsentRecord>) => void;
  deleteAllData: () => void;
  toasts: Toast[];
  toast: (t: Omit<Toast, "id">) => void;
  dismissToast: (id: string) => void;
}

const AppContext = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(initialState);
  const [hydrated, setHydrated] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const first = useRef(true);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setState({ ...initialState, ...JSON.parse(raw) });
    } catch {
      /* storage unavailable — run in memory */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    if (!hydrated) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* ignore */
    }
  }, [state, hydrated]);

  const toast = useCallback((t: Omit<Toast, "id">) => {
    const id = uid("t");
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 4200);
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      ...state,
      hydrated,
      toasts,
      toast,
      dismissToast: (id) => setToasts((p) => p.filter((t) => t.id !== id)),
      signIn: (s) =>
        setState((prev) => ({
          ...prev,
          session: { id: uid("u"), role: s.role ?? "student", consent: prev.session?.consent ?? null, createdAt: new Date().toISOString(), ...s },
          prefs: { ...prev.prefs, anonymousMode: s.mode === "anonymous" },
        })),
      giveConsent: (c) =>
        setState((prev) =>
          prev.session
            ? { ...prev, session: { ...prev.session, consent: { ...c, version: APP.consentVersion, acceptedAt: new Date().toISOString() } } }
            : prev,
        ),
      updateConsent: (p) =>
        setState((prev) =>
          prev.session?.consent ? { ...prev, session: { ...prev.session, consent: { ...prev.session.consent, ...p } } } : prev,
        ),
      signOut: () => setState(initialState),
      startDemo: () =>
        setState({
          ...initialState,
          session: {
            id: "demo_student",
            role: "student",
            mode: "account",
            displayName: "Aarav",
            email: "aarav.demo@university.edu",
            institution: APP.institution,
            consent: {
              version: APP.consentVersion,
              acceptedAt: new Date().toISOString(),
              aiNotReplacement: true,
              dataProcessing: true,
              shareWithCounselor: true,
              anonymousAnalytics: true,
            },
            createdAt: new Date().toISOString(),
          },
          checkIns: buildDemoCheckIns(),
          bookings: [demoBooking()],
          completedResources: ["breathing-2min", "exam-reset"],
          demoStep: 0,
        }),
      setDemoStep: (n) => setState((p) => ({ ...p, demoStep: n })),
      advanceDemo: (n) => setState((p) => (p.demoStep !== null && p.demoStep < n ? { ...p, demoStep: n } : p)),
      addCheckIn: (c) => setState((p) => ({ ...p, checkIns: [...p.checkIns, c] })),
      addBooking: (b) => setState((p) => ({ ...p, bookings: [...p.bookings, b] })),
      cancelBooking: (id) =>
        setState((p) => ({ ...p, bookings: p.bookings.map((b) => (b.id === id ? { ...b, status: "cancelled" } : b)) })),
      setChat: (updater) => setState((p) => ({ ...p, chat: updater(p.chat) })),
      completeResource: (id) =>
        setState((p) => ({ ...p, completedResources: p.completedResources.includes(id) ? p.completedResources : [...p.completedResources, id] })),
      toggleSaved: (id) =>
        setState((p) => ({
          ...p,
          savedResources: p.savedResources.includes(id) ? p.savedResources.filter((x) => x !== id) : [...p.savedResources, id],
        })),
      updatePrefs: (pr) => setState((p) => ({ ...p, prefs: { ...p.prefs, ...pr } })),
      deleteAllData: () =>
        setState((p) => ({ ...initialState, session: p.session })),
    }),
    [state, hydrated, toasts, toast],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside <AppProvider>");
  return ctx;
}
