"use client";

import { motion, useReducedMotion } from "framer-motion";
import { BookOpen, CalendarCheck, HeartPulse, MessageCircleHeart, ShieldCheck, Sparkles, Sprout } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

export const PATHWAY = [
  { key: "checkin", label: "Check-in", icon: HeartPulse, text: "30-second mood & stress check" },
  { key: "ai", label: "AI support", icon: MessageCircleHeart, text: "Supportive, non-diagnostic guidance" },
  { key: "resources", label: "Resources", icon: BookOpen, text: "Short, practical self-help" },
  { key: "counselor", label: "Counselor", icon: CalendarCheck, text: "Human support when it matters" },
  { key: "wellness", label: "Continuous wellness", icon: Sprout, text: "Trends that help you notice patterns" },
] as const;

const MOODS = [
  { e: "😞", l: "Very low", v: 1 },
  { e: "😟", l: "Low", v: 2 },
  { e: "😐", l: "Okay", v: 3 },
  { e: "🙂", l: "Good", v: 4 },
  { e: "😀", l: "Great", v: 5 },
];

const TREND = [3, 2.6, 2.4, 3, 3.2, 3.6, 3.9];

export function usePathwayCycle(len: number, ms = 2200) {
  const reduce = useReducedMotion();
  const [i, setI] = useState(0);
  useEffect(() => {
    if (reduce) return;
    const t = setInterval(() => setI((x) => (x + 1) % len), ms);
    return () => clearInterval(t);
  }, [len, ms, reduce]);
  return [i, setI] as const;
}

export function HeroVisual() {
  const [mood, setMood] = useState(4);
  const [active, setActive] = usePathwayCycle(PATHWAY.length);

  const pts = TREND.map((v, i) => `${(i / (TREND.length - 1)) * 220},${60 - (v - 1) * 13}`).join(" ");

  return (
    <div className="relative mx-auto w-full max-w-[560px]" aria-label="Interactive preview of the CarePath student dashboard">
      <div className="absolute -inset-6 -z-10 rounded-[40px] bg-gradient-to-br from-sea-100/60 via-white/0 to-calm-100/60 blur-2xl" />

      <div className="grid grid-cols-6 gap-3">
        {/* Mood card */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass col-span-6 rounded-3xl p-5 sm:col-span-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-ink-muted">Today’s check-in</p>
              <p className="mt-0.5 font-semibold">How are you feeling, Aarav?</p>
            </div>
            <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-800 ring-1 ring-emerald-200">Day 12 streak</span>
          </div>
          <div className="mt-4 flex justify-between gap-1.5" role="radiogroup" aria-label="Preview mood">
            {MOODS.map((m) => (
              <button
                key={m.v}
                role="radio"
                aria-checked={mood === m.v}
                onClick={() => setMood(m.v)}
                className={cn(
                  "flex flex-1 flex-col items-center gap-1 rounded-2xl border py-2 text-[11px] transition",
                  mood === m.v ? "border-sea-400 bg-sea-50 text-sea-800 shadow-glow" : "border-transparent bg-white/70 text-ink-muted hover:bg-white",
                )}
              >
                <span className="text-xl leading-none" aria-hidden>
                  {m.e}
                </span>
                {m.l}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Score */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass col-span-3 rounded-3xl p-5 sm:col-span-2">
          <p className="text-xs font-medium text-ink-muted">Wellness trend</p>
          <p className="mt-1 text-3xl font-bold text-ink">
            {mood >= 4 ? "Rising" : mood === 3 ? "Steady" : "Dipping"}
          </p>
          <svg viewBox="0 0 220 64" className="mt-2 h-12 w-full" aria-hidden>
            <defs>
              <linearGradient id="hv-g" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0" stopColor="#2a9a94" stopOpacity="0.25" />
                <stop offset="1" stopColor="#2a9a94" stopOpacity="0" />
              </linearGradient>
            </defs>
            <polygon points={`0,64 ${pts} 220,64`} fill="url(#hv-g)" />
            <motion.polyline
              points={pts}
              fill="none"
              stroke="#1e7c79"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 1.4, delay: 0.4 }}
            />
          </svg>
          <p className="text-[11px] text-ink-muted">Last 7 days</p>
        </motion.div>

        {/* AI */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass col-span-3 rounded-3xl p-4 sm:col-span-3">
          <div className="flex items-center gap-2">
            <span className="grid h-7 w-7 place-items-center rounded-xl bg-gradient-to-br from-sea-400 to-calm-500 text-white">
              <Sparkles className="h-3.5 w-3.5" aria-hidden />
            </span>
            <p className="text-xs font-semibold">AI Wellness Assistant</p>
          </div>
          <div className="mt-3 space-y-2 text-[12px] leading-snug">
            <p className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-br-md bg-sea-600 px-3 py-2 text-white">Exams are piling up and I can’t focus.</p>
            <p className="w-fit max-w-[92%] rounded-2xl rounded-bl-md bg-white px-3 py-2 text-ink-soft ring-1 ring-line">
              That sounds like a lot. Want to try a 4-minute focus reset, then plan one next step?
            </p>
          </div>
        </motion.div>

        {/* Pathway */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="glass col-span-6 rounded-3xl p-4 sm:col-span-3">
          <p className="text-xs font-medium text-ink-muted">Your support pathway</p>
          <ol className="mt-2 space-y-1">
            {PATHWAY.map((p, i) => (
              <li key={p.key}>
                <button
                  onMouseEnter={() => setActive(i)}
                  onFocus={() => setActive(i)}
                  className={cn(
                    "flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left text-[12px] transition",
                    active === i ? "bg-white text-ink shadow-soft" : "text-ink-muted",
                  )}
                >
                  <span className={cn("grid h-6 w-6 place-items-center rounded-lg", active === i ? "bg-sea-600 text-white" : "bg-sea-50 text-sea-700")}>
                    <p.icon className="h-3.5 w-3.5" aria-hidden />
                  </span>
                  <span className="font-medium">{p.label}</span>
                  {i < active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sea-500" aria-hidden />}
                </button>
              </li>
            ))}
          </ol>
        </motion.div>

        {/* Counselor */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="glass col-span-6 flex items-center gap-3 rounded-3xl p-4">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-sea-100 text-sm font-bold text-sea-800">AR</span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold">Session with Dr. Ananya Rao</p>
            <p className="text-xs text-ink-muted">Thu · 11:30 AM · Video · you chose what to share</p>
          </div>
          <span className="hidden items-center gap-1 rounded-full bg-white px-2.5 py-1 text-[11px] font-medium text-ink-soft ring-1 ring-line sm:inline-flex">
            <ShieldCheck className="h-3 w-3 text-sea-600" aria-hidden /> Private
          </span>
        </motion.div>
      </div>
    </div>
  );
}
