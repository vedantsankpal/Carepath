"use client";

import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight, BarChart3, BookOpen, Building2, CalendarCheck, CheckCircle2, ClipboardCheck, EyeOff, Fingerprint, GraduationCap,
  HeartHandshake, HeartPulse, KeyRound, LifeBuoy, Lock, MessageCircleHeart, MessagesSquare, ShieldCheck, Siren, Sparkles, Sprout,
  Timer, TrendingDown, UserX, Users, type LucideIcon,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Badge, Button } from "@/components/ui";
import { FadeIn } from "@/components/ui/motion";
import { Modal } from "@/components/ui/modal";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { HeroVisual, PATHWAY, usePathwayCycle } from "./hero-visual";

/* ---------------- HERO ---------------- */

export function Hero() {
  const { startDemo } = useApp();
  const router = useRouter();
  return (
    <section className="bg-hero relative -mt-16 overflow-hidden pt-16">
      <div className="container grid items-center gap-12 pb-16 pt-10 lg:grid-cols-[1.02fr_1fr] lg:pb-24 lg:pt-16">
        <div>
          <FadeIn>
            <p className="inline-flex items-center gap-2 rounded-full border border-white/80 bg-white/70 px-3 py-1.5 text-xs font-semibold text-ink-soft shadow-soft backdrop-blur">
              <span className="h-1.5 w-1.5 rounded-full bg-sea-500" aria-hidden />
              AI-assisted • Human-centered • Privacy-first
            </p>
          </FadeIn>
          <FadeIn delay={0.05}>
            <h1 className="mt-5 font-display text-[40px] font-medium leading-[1.05] tracking-[-0.02em] sm:text-[56px] lg:text-[64px]">
              Your first step toward <span className="italic text-sea-700">feeling better.</span>
            </h1>
          </FadeIn>
          <FadeIn delay={0.1}>
            <p className="mt-5 max-w-xl text-lg text-ink-muted">
              Private, accessible and AI-assisted mental health support designed for students — with real counselors one tap away when it matters.
            </p>
          </FadeIn>
          <FadeIn delay={0.15}>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button size="lg" href="/check-in" iconRight={ArrowRight}>
                Start a Check-In
              </Button>
              <Button size="lg" variant="outline" href="#support">
                Explore Support
              </Button>
            </div>
            <button
              onClick={() => {
                startDemo();
                router.push("/dashboard");
              }}
              className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-sea-700 hover:text-sea-800"
            >
              <Sparkles className="h-4 w-4" aria-hidden /> Or explore the full demo with sample data
            </button>
          </FadeIn>
          <FadeIn delay={0.2}>
            <dl className="mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-ink/5 pt-6 text-sm">
              {[
                ["2 min", "to check in"],
                ["24 × 7", "AI first response"],
                ["0", "diagnoses made by AI"],
              ].map(([a, b]) => (
                <div key={b}>
                  <dt className="text-xl font-bold text-ink">{a}</dt>
                  <dd className="text-ink-muted">{b}</dd>
                </div>
              ))}
            </dl>
          </FadeIn>
        </div>
        <HeroVisual />
      </div>
    </section>
  );
}

/* ---------------- PATHWAY ---------------- */

export function PathwayStrip() {
  const [active, setActive] = usePathwayCycle(PATHWAY.length, 2000);
  const reduce = useReducedMotion();
  return (
    <section id="how-it-works" className="scroll-mt-20 border-y border-line bg-white py-16">
      <div className="container">
        <FadeIn className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">How it works</p>
          <h2 className="mt-2 text-3xl font-bold sm:text-4xl">A gentle path from “I’m not okay” to real support.</h2>
          <p className="mt-3 text-ink-muted">Each step is optional. Students move forward only when they want to — and are never left at a dead end.</p>
        </FadeIn>
        <ol className="relative mt-12 grid gap-4 md:grid-cols-5">
          <div className="absolute left-[10%] right-[10%] top-7 hidden h-px md:block" aria-hidden>
            <svg className="h-2 w-full overflow-visible" preserveAspectRatio="none">
              <line x1="0" y1="1" x2="100%" y2="1" stroke="#aee5e0" strokeWidth="2" strokeDasharray="6 6" className={reduce ? "" : "animate-flow"} />
            </svg>
          </div>
          {PATHWAY.map((p, i) => (
            <li key={p.key}>
              <button
                onMouseEnter={() => setActive(i)}
                onFocus={() => setActive(i)}
                className="group relative flex w-full items-center gap-4 rounded-2xl p-3 text-left md:flex-col md:text-center"
              >
                <span
                  className={cn(
                    "relative grid h-14 w-14 shrink-0 place-items-center rounded-2xl border transition-all duration-500",
                    active === i ? "border-sea-500 bg-sea-600 text-white shadow-lift" : "border-line bg-white text-sea-700",
                  )}
                >
                  <p.icon className="h-6 w-6" aria-hidden />
                  {active === i && !reduce && <motion.span layoutId="pulse" className="absolute -inset-1.5 rounded-[20px] ring-4 ring-sea-500/15" />}
                </span>
                <span>
                  <span className="block text-[11px] font-bold uppercase tracking-[0.14em] text-ink-faint">Step {i + 1}</span>
                  <span className="block font-semibold">{p.label}</span>
                  <span className="block text-sm text-ink-muted">{p.text}</span>
                </span>
              </button>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

/* ---------------- GAP ---------------- */

const GAP: { icon: LucideIcon; title: string; body: string; detail: string }[] = [
  { icon: GraduationCap, title: "Academic Pressure", body: "Deadlines, exams and performance expectations.", detail: "Pressure peaks around assessments and placements — exactly when students have the least time to seek help." },
  { icon: HeartPulse, title: "Emotional Stress", body: "Anxiety, loneliness, relationship and personal challenges.", detail: "Moving away from home, new relationships and uncertainty about the future can quietly build up." },
  { icon: Timer, title: "Delayed Support", body: "Students may avoid or postpone seeking professional help.", detail: "Stigma, not knowing whether it's ‘serious enough’, or simply not knowing where to start keeps students waiting." },
  { icon: UserX, title: "Limited Accessibility", body: "Counseling can have limited slots or inconvenient access.", detail: "Fixed office hours, waitlists and walk-in-only models make the first step harder than it should be." },
];

export function GapSection() {
  const [open, setOpen] = useState<number | null>(null);
  const flow = ["Stress builds", "Isolation & stigma", "Help is delayed", "Academic / social impact"];
  return (
    <section id="support" className="scroll-mt-20 py-20">
      <div className="container">
        <FadeIn className="max-w-2xl">
          <p className="eyebrow">The gap</p>
          <h2 className="mt-2 text-3xl font-bold sm:text-4xl">Students don’t always know where to start.</h2>
          <p className="mt-3 text-ink-muted">Support often exists on campus — but the path to it isn’t visible when students need it most.</p>
        </FadeIn>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {GAP.map((g, i) => (
            <FadeIn key={g.title} delay={i * 0.05}>
              <button
                onClick={() => setOpen(open === i ? null : i)}
                aria-expanded={open === i}
                className="card group h-full w-full p-6 text-left transition hover:-translate-y-0.5 hover:shadow-lift"
              >
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-sea-50 to-calm-50 text-sea-700 ring-1 ring-sea-100">
                  <g.icon className="h-5 w-5" aria-hidden />
                </span>
                <h3 className="mt-5 font-semibold">{g.title}</h3>
                <p className="mt-1.5 text-sm text-ink-muted">{g.body}</p>
                <motion.p
                  initial={false}
                  animate={{ height: open === i ? "auto" : 0, opacity: open === i ? 1 : 0 }}
                  className="overflow-hidden text-sm text-ink-soft"
                >
                  <span className="mt-3 block border-t border-line pt-3">{g.detail}</span>
                </motion.p>
                <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-sea-700">
                  {open === i ? "Show less" : "Why it matters"} <ArrowRight className={cn("h-3 w-3 transition", open === i && "rotate-90")} aria-hidden />
                </span>
              </button>
            </FadeIn>
          ))}
        </div>

        <FadeIn className="mt-10">
          <div className="card overflow-hidden p-6 sm:p-8">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <p className="font-semibold">How small struggles become big ones</p>
              <p className="text-sm text-ink-muted">CarePath intervenes at the first two stages.</p>
            </div>
            <ol className="mt-6 grid gap-3 md:grid-cols-4">
              {flow.map((f, i) => (
                <motion.li
                  key={f}
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.15 * i }}
                  className={cn(
                    "relative flex items-center gap-3 rounded-2xl border p-4",
                    i < 2 ? "border-sea-200 bg-sea-50/70" : "border-line bg-slate-50/60",
                  )}
                >
                  <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-full text-sm font-bold", i < 2 ? "bg-sea-600 text-white" : "bg-white text-ink-muted ring-1 ring-line")}>
                    {i + 1}
                  </span>
                  <span className="text-sm font-medium">{f}</span>
                  {i < flow.length - 1 && <ArrowRight className="absolute -right-3 top-1/2 z-10 hidden h-5 w-5 -translate-y-1/2 rounded-full bg-white p-0.5 text-ink-faint md:block" aria-hidden />}
                  {i === 1 && <TrendingDown className="ml-auto h-4 w-4 text-sea-600" aria-label="Early intervention point" />}
                </motion.li>
              ))}
            </ol>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}

/* ---------------- ECOSYSTEM ---------------- */

export const MODULES: { icon: LucideIcon; title: string; body: string; href: string; features: string[]; tint: string }[] = [
  { icon: MessageCircleHeart, title: "AI Wellness Assistant", body: "A supportive, private first conversation — any time of day.", href: "/assistant", features: ["Empathetic, non-diagnostic replies", "Quick prompts for common struggles", "One-tap handoff to a counselor", "Safety screening on every message"], tint: "from-sea-100 to-sea-50 text-sea-700" },
  { icon: ClipboardCheck, title: "Check-ins & Screening", body: "A 2-minute check-in that routes to the right level of support.", href: "/check-in", features: ["Mood, stressors and intensity", "Conservative, rule-based routing", "Clear escalation for safety concerns", "No labels, no diagnoses"], tint: "from-calm-100 to-calm-50 text-calm-700" },
  { icon: BookOpen, title: "Self-Help Resources", body: "Short, practical exercises and guides students actually finish.", href: "/resources", features: ["Searchable & filterable library", "2–10 minute formats", "Guided breathing player", "Personalised recommendations"], tint: "from-lav-100 to-lav-50 text-[#4b3f8f]" },
  { icon: CalendarCheck, title: "Counselor Connect", body: "Book a video, chat or in-person session in under a minute.", href: "/counselor", features: ["Counselor profiles & specialisations", "Real-time slot selection", "Student controls what's shared", "Counselor portal with triage"], tint: "from-sea-100 to-calm-50 text-sea-700" },
  { icon: BarChart3, title: "Wellness Dashboard", body: "Personal trends that help students notice their own patterns.", href: "/wellness", features: ["Mood & stress trends", "Check-in consistency", "What has helped recently", "No clinical scoring"], tint: "from-emerald-50 to-sea-50 text-emerald-700" },
  { icon: MessagesSquare, title: "Anonymous Feedback", body: "A safe channel to raise campus concerns and suggestions.", href: "/feedback", features: ["Truly anonymous submission", "Campus concerns & suggestions", "Counselor experience ratings", "Aggregated for administrators"], tint: "from-amber-50 to-lav-50 text-amber-800" },
  { icon: LifeBuoy, title: "Crisis Escalation", body: "A calm, clear pathway to human help when safety is at risk.", href: "/safety", features: ["Three-tier support model", "Institution-configured contacts", "Urgent counselor callback", "Humans always in the loop"], tint: "from-rose-50 to-amber-50 text-rose-700" },
];

export function EcosystemSection() {
  const [sel, setSel] = useState<number | null>(null);
  const m = sel !== null ? MODULES[sel] : null;
  const router = useRouter();
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-white to-mist py-20">
      <div className="container">
        <FadeIn className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">The platform</p>
          <h2 className="mt-2 text-3xl font-bold sm:text-4xl">One ecosystem. The right support at the right time.</h2>
          <p className="mt-3 text-ink-muted">Seven connected modules — so a student’s first step naturally leads to the next one they need.</p>
        </FadeIn>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {MODULES.map((mod, i) => (
            <FadeIn key={mod.title} delay={i * 0.04} className={i === 0 ? "sm:col-span-2 lg:row-span-2" : ""}>
              <button
                onClick={() => setSel(i)}
                className={cn(
                  "card group relative flex h-full w-full flex-col overflow-hidden p-6 text-left transition hover:-translate-y-0.5 hover:border-sea-200 hover:shadow-lift",
                  i === 0 && "lg:p-8",
                )}
              >
                <span className={cn("grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br", mod.tint)}>
                  <mod.icon className="h-5 w-5" aria-hidden />
                </span>
                <span className="mt-5 text-[11px] font-bold uppercase tracking-[0.14em] text-ink-faint">Module {i + 1}</span>
                <h3 className={cn("mt-1 font-semibold", i === 0 && "text-xl")}>{mod.title}</h3>
                <p className="mt-1.5 text-sm text-ink-muted">{mod.body}</p>
                {i === 0 && (
                  <div className="mt-6 hidden flex-1 flex-col justify-end gap-2 text-[13px] lg:flex">
                    <p className="ml-auto max-w-[80%] rounded-2xl rounded-br-md bg-sea-600 px-3.5 py-2.5 text-white">I’ve been feeling overwhelmed with college lately.</p>
                    <p className="max-w-[90%] rounded-2xl rounded-bl-md bg-slate-50 px-3.5 py-2.5 text-ink-soft ring-1 ring-line">
                      That sounds like a lot to carry. Let’s take it one piece at a time — what’s weighing on you most right now?
                    </p>
                  </div>
                )}
                <span className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-sea-700">
                  Preview <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" aria-hidden />
                </span>
              </button>
            </FadeIn>
          ))}
        </div>
      </div>
      <Modal open={!!m} onClose={() => setSel(null)} title={m?.title ?? ""} description={m?.body}>
        {m && (
          <div>
            <ul className="space-y-2.5">
              {m.features.map((f) => (
                <li key={f} className="flex items-start gap-2.5 text-sm text-ink-soft">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-sea-600" aria-hidden />
                  {f}
                </li>
              ))}
            </ul>
            <div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <Button variant="outline" onClick={() => setSel(null)}>
                Close
              </Button>
              <Button
                iconRight={ArrowRight}
                data-autofocus
                onClick={() => {
                  setSel(null);
                  router.push(m.href);
                }}
              >
                Open {m.title}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </section>
  );
}

/* ---------------- SAFETY + PRIVACY ---------------- */

export function SafetyPrivacySection() {
  const tiers = [
    { label: "Low / Moderate", body: "Self-help resources and AI support", tone: "bg-sea-50 text-sea-800 ring-sea-200", dot: "bg-sea-500" },
    { label: "Concerning signals", body: "Counselor / human support is offered first", tone: "bg-amber-50 text-amber-900 ring-amber-200", dot: "bg-amber-500" },
    { label: "Immediate safety concern", body: "Emergency support pathway, shown calmly and clearly", tone: "bg-rose-50 text-rose-800 ring-rose-200", dot: "bg-rose-500" },
  ];
  const privacy: [LucideIcon, string][] = [
    [Fingerprint, "Consent-driven data collection"],
    [EyeOff, "Anonymous mode, no name required"],
    [Lock, "Encryption in transit & at rest"],
    [KeyRound, "Role-based access control"],
    [Users, "Aggregated-only campus insights"],
    [ShieldCheck, "Export or delete your data anytime"],
  ];
  return (
    <section id="resources" className="scroll-mt-20 py-20">
      <div className="container grid gap-6 lg:grid-cols-2">
        <FadeIn>
          <div className="card h-full p-7 sm:p-9">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-rose-50 text-rose-700">
              <Siren className="h-5 w-5" aria-hidden />
            </span>
            <h2 className="mt-5 text-2xl font-bold">Safety that routes to humans.</h2>
            <p className="mt-2 text-ink-muted">Every check-in and chat message passes a conservative safety screen. The system decides only which kind of support to <em>offer</em> — never what someone “has”.</p>
            <ol className="mt-6 space-y-2.5">
              {tiers.map((t) => (
                <li key={t.label} className={cn("flex items-center gap-3 rounded-2xl px-4 py-3 ring-1 ring-inset", t.tone)}>
                  <span className={cn("h-2.5 w-2.5 rounded-full", t.dot)} aria-hidden />
                  <span className="text-sm font-semibold">{t.label}</span>
                  <span className="ml-auto text-right text-xs opacity-90 sm:text-sm">{t.body}</span>
                </li>
              ))}
            </ol>
            <p className="mt-6 rounded-2xl bg-slate-50 px-4 py-3 text-sm font-medium text-ink-soft">AI supports, never diagnoses. Human professionals remain in the loop.</p>
          </div>
        </FadeIn>
        <FadeIn delay={0.08}>
          <div className="card h-full p-7 sm:p-9">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-sea-50 text-sea-700">
              <ShieldCheck className="h-5 w-5" aria-hidden />
            </span>
            <h2 className="mt-5 text-2xl font-bold">Private by design, not by policy.</h2>
            <p className="mt-2 text-ink-muted">Students decide what is collected and who can see it. Universities see trends, never individuals.</p>
            <ul className="mt-6 grid gap-2.5 sm:grid-cols-2">
              {privacy.map(([Icon, t]) => (
                <li key={t} className="flex items-center gap-3 rounded-2xl border border-line p-3 text-sm">
                  <Icon className="h-4 w-4 shrink-0 text-sea-600" aria-hidden />
                  {t}
                </li>
              ))}
            </ul>
            <Button variant="soft" className="mt-6" href="/privacy" iconRight={ArrowRight}>
              Visit the Privacy Center
            </Button>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}

/* ---------------- UNIVERSITIES + ROADMAP ---------------- */

export const ROADMAP = [
  { phase: "Phase 1", name: "MVP", items: ["AI assistant", "Check-ins", "Resources", "Student dashboard"], status: "Built in this prototype" },
  { phase: "Phase 2", name: "Campus Pilot", items: ["Counselor portal", "Appointments", "Anonymous analytics"], status: "Prototype ready" },
  { phase: "Phase 3", name: "Intelligent", items: ["Multilingual", "Voice", "Personalised plans"], status: "Planned" },
  { phase: "Phase 4", name: "Scale", items: ["Multi-university", "Cloud", "Institutional APIs"], status: "Planned" },
];

export function RoadmapTimeline() {
  return (
    <ol className="relative grid gap-4 md:grid-cols-4">
      {ROADMAP.map((r, i) => (
        <FadeIn key={r.phase} delay={i * 0.06}>
          <li className="card relative h-full p-6">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-[0.14em] text-sea-700">{r.phase}</span>
              <Badge tone={i === 0 ? "green" : i === 1 ? "sea" : "slate"}>{r.status}</Badge>
            </div>
            <h3 className="mt-3 text-lg font-semibold">{r.name}</h3>
            <ul className="mt-3 space-y-1.5">
              {r.items.map((it) => (
                <li key={it} className="flex items-center gap-2 text-sm text-ink-muted">
                  <span className="h-1.5 w-1.5 rounded-full bg-sea-400" aria-hidden />
                  {it}
                </li>
              ))}
            </ul>
          </li>
        </FadeIn>
      ))}
    </ol>
  );
}

export function UniversitiesSection() {
  return (
    <section id="about" className="scroll-mt-20 border-t border-line bg-white py-20">
      <div className="container">
        <div className="grid items-center gap-10 lg:grid-cols-[1fr_1.1fr]">
          <FadeIn>
            <p className="eyebrow">For universities</p>
            <h2 className="mt-2 text-3xl font-bold sm:text-4xl">See the campus picture. Never the individual.</h2>
            <p className="mt-3 text-ink-muted">
              Wellbeing teams get aggregated trends, support demand and resource engagement to plan counselling capacity and campus initiatives — with small groups automatically suppressed.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button href="/university" icon={Building2}>
                University dashboard
              </Button>
              <Button variant="outline" href="/counselor-portal" icon={HeartHandshake}>
                Counselor portal
              </Button>
              <Button variant="ghost" href="/technology" iconRight={ArrowRight}>
                Architecture
              </Button>
            </div>
          </FadeIn>
          <FadeIn delay={0.08}>
            <div className="grid grid-cols-2 gap-3">
              {[
                ["Aggregate wellbeing trend", "Week-over-week, campus-wide"],
                ["Common support themes", "Academics, sleep, loneliness…"],
                ["Counselling demand", "Bookings vs. capacity"],
                ["Resource engagement", "What students actually use"],
              ].map(([a, b]) => (
                <div key={a} className="rounded-2xl border border-line bg-gradient-to-br from-white to-mist p-5">
                  <p className="font-semibold">{a}</p>
                  <p className="mt-1 text-sm text-ink-muted">{b}</p>
                </div>
              ))}
            </div>
          </FadeIn>
        </div>
        <div className="mt-16">
          <FadeIn className="mb-6 flex items-end justify-between gap-4">
            <div>
              <p className="eyebrow">Roadmap</p>
              <h3 className="mt-2 text-2xl font-bold">From campus MVP to multi-university platform.</h3>
            </div>
          </FadeIn>
          <RoadmapTimeline />
        </div>
      </div>
    </section>
  );
}

export function ClosingCTA() {
  return (
    <section className="py-20">
      <div className="container">
        <FadeIn>
          <div className="relative overflow-hidden rounded-[32px] bg-gradient-to-br from-sea-700 via-sea-800 to-calm-900 px-6 py-14 text-center text-white sm:px-12 sm:py-20">
            <div className="absolute -left-24 -top-24 h-72 w-72 rounded-full bg-sea-400/20 blur-3xl" aria-hidden />
            <div className="absolute -bottom-24 -right-16 h-72 w-72 rounded-full bg-calm-400/25 blur-3xl" aria-hidden />
            <p className="relative mx-auto max-w-3xl font-display text-3xl leading-tight sm:text-[44px]">
              Technology can’t replace human care — but it can help students reach it <span className="italic text-sea-200">sooner.</span>
            </p>
            <div className="relative mt-9 flex flex-col justify-center gap-3 sm:flex-row">
              <Button size="lg" href="/check-in" className="bg-white !text-sea-800 hover:bg-sea-50">
                Start a Check-In
              </Button>
              <Button size="lg" href="/login" className="border border-white/30 bg-white/10 hover:bg-white/20">
                Create a private account
              </Button>
            </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
