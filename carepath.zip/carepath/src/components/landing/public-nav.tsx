"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, PlayCircle, X } from "lucide-react";
import { Button, Logo } from "@/components/ui";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/#how-it-works", label: "How It Works" },
  { href: "/#support", label: "Support" },
  { href: "/#resources", label: "Resources" },
  { href: "/university", label: "For Universities" },
  { href: "/#about", label: "About" },
];

export function PublicNav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { session, startDemo } = useApp();
  const router = useRouter();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const demo = () => {
    startDemo();
    router.push("/dashboard");
  };

  return (
    <header className={cn("sticky top-0 z-50 transition-all", scrolled ? "border-b border-line/80 bg-white/80 backdrop-blur-xl" : "bg-transparent")}>
      <nav className="container flex h-16 items-center justify-between gap-4" aria-label="Main">
        <Link href="/" aria-label="CarePath home">
          <Logo />
        </Link>
        <ul className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <li key={l.href}>
              <Link href={l.href} className="rounded-lg px-3 py-2 text-sm font-medium text-ink-soft transition hover:bg-white/70 hover:text-ink">
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
        <div className="hidden items-center gap-2 lg:flex">
          <Button variant="ghost" size="sm" icon={PlayCircle} onClick={demo}>
            Demo mode
          </Button>
          {session ? (
            <Button size="sm" href="/dashboard">
              Open dashboard
            </Button>
          ) : (
            <>
              <Button variant="outline" size="sm" href="/login">
                Login
              </Button>
              <Button size="sm" href="/check-in">
                Start a Check-In
              </Button>
            </>
          )}
        </div>
        <button className="rounded-lg p-2 text-ink lg:hidden" onClick={() => setOpen((o) => !o)} aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open}>
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>
      {open && (
        <div className="border-t border-line bg-white px-5 pb-5 pt-2 lg:hidden">
          <ul className="flex flex-col">
            {LINKS.map((l) => (
              <li key={l.href}>
                <Link href={l.href} onClick={() => setOpen(false)} className="block rounded-lg px-2 py-3 text-[15px] font-medium text-ink-soft hover:bg-slate-50">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Button variant="outline" href="/login">
              Login
            </Button>
            <Button onClick={demo} icon={PlayCircle}>
              Demo mode
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}

export function PublicFooter() {
  return (
    <footer className="border-t border-line bg-white">
      <div className="container grid gap-10 py-12 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="mt-3 max-w-xs text-sm text-ink-muted">
            Detect early. Support instantly. Connect when it matters. A first-line support layer — never a replacement for professional care.
          </p>
        </div>
        {[
          { h: "Product", l: [["Check-In", "/check-in"], ["AI Assistant", "/assistant"], ["Resources", "/resources"], ["Counselor Connect", "/counselor"]] },
          { h: "Institutions", l: [["University dashboard", "/university"], ["Counselor portal", "/counselor-portal"], ["Technology", "/technology"]] },
          { h: "Trust", l: [["Privacy Center", "/privacy"], ["Safety pathway", "/safety"], ["Anonymous feedback", "/feedback"]] },
        ].map((c) => (
          <div key={c.h}>
            <p className="text-sm font-semibold">{c.h}</p>
            <ul className="mt-3 space-y-2">
              {c.l.map(([label, href]) => (
                <li key={href}>
                  <Link href={href} className="text-sm text-ink-muted hover:text-sea-700">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-line">
        <div className="container flex flex-col gap-2 py-5 text-xs text-ink-muted sm:flex-row sm:items-center sm:justify-between">
          <p>Hackathon prototype · sample data only · not a medical device.</p>
          <p>If you are in immediate danger, call 112 or your local emergency number.</p>
        </div>
      </div>
    </footer>
  );
}
