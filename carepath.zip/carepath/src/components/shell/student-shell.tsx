"use client";

import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import {
  BarChart3, Bell, BookOpen, CalendarCheck, ClipboardCheck, EyeOff, HeartHandshake, LayoutDashboard, LifeBuoy, LogOut,
  MessageCircleHeart, MessagesSquare, MoreHorizontal, PlayCircle, Settings, ShieldCheck, X, type LucideIcon,
} from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { Button, Logo, Skeleton } from "@/components/ui";
import { ConsentModal } from "@/components/app/consent-modal";
import { useApp } from "@/lib/store";
import { cn, greeting } from "@/lib/utils";

export const NAV: { href: string; label: string; icon: LucideIcon }[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/assistant", label: "AI Assistant", icon: MessageCircleHeart },
  { href: "/check-in", label: "Check-In", icon: ClipboardCheck },
  { href: "/resources", label: "Resources", icon: BookOpen },
  { href: "/counselor", label: "Counselor", icon: CalendarCheck },
  { href: "/wellness", label: "Wellness", icon: BarChart3 },
  { href: "/feedback", label: "Feedback", icon: MessagesSquare },
  { href: "/privacy", label: "Privacy", icon: ShieldCheck },
  { href: "/settings", label: "Settings", icon: Settings },
];

const MOBILE = [NAV[0], NAV[1], NAV[2], NAV[3]];

export function StudentShell({ children }: { children: ReactNode }) {
  const { session, hydrated, signIn, startDemo, prefs } = useApp();
  const path = usePathname();
  const router = useRouter();
  const [consentOpen, setConsentOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);

  useEffect(() => {
    if (hydrated && session && !session.consent) setConsentOpen(true);
  }, [hydrated, session]);
  useEffect(() => setMoreOpen(false), [path]);

  if (!hydrated) {
    return (
      <div className="flex min-h-screen">
        <div className="hidden w-[260px] border-r border-line bg-white lg:block" />
        <div className="flex-1 space-y-4 p-6">
          <Skeleton className="h-8 w-64" />
          <div className="grid gap-4 md:grid-cols-3">
            <Skeleton className="h-40" />
            <Skeleton className="h-40" />
            <Skeleton className="h-40" />
          </div>
          <Skeleton className="h-72" />
        </div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="bg-hero flex min-h-screen items-center justify-center p-5">
        <main id="main" className="glass w-full max-w-md rounded-[28px] p-8 text-center">
          <Logo className="justify-center" />
          <h1 className="mt-6 text-2xl font-bold">A private space, just for you</h1>
          <p className="mt-2 text-sm text-ink-muted">Continue anonymously — no name or email needed — or sign in to keep your history across devices.</p>
          <div className="mt-6 space-y-2.5">
            <Button className="w-full" size="lg" icon={EyeOff} onClick={() => signIn({ mode: "anonymous", displayName: "Friend" })}>
              Continue anonymously
            </Button>
            <Button className="w-full" size="lg" variant="outline" href={`/login?next=${encodeURIComponent(path)}`}>
              Sign in or create account
            </Button>
            <Button
              className="w-full"
              variant="ghost"
              icon={PlayCircle}
              onClick={() => {
                startDemo();
                router.refresh();
              }}
            >
              Try Demo Mode
            </Button>
          </div>
          <Link href="/safety" className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-rose-700 hover:underline">
            <LifeBuoy className="h-4 w-4" aria-hidden /> Need help right now?
          </Link>
        </main>
      </div>
    );
  }

  return (
    <MotionConfig reducedMotion={prefs.reduceMotion ? "always" : "user"}>
    <div className="min-h-screen lg:pl-[260px]">
      <Sidebar />
      <Topbar />
      <main id="main" className="mx-auto w-full max-w-[1200px] px-4 pb-40 pt-5 sm:px-6 lg:px-8 lg:pb-12 lg:pt-8">
        <AnimatePresence mode="wait">
          <motion.div key={path} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}>
            {children}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Mobile bottom navigation */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden" aria-label="Primary">
        <ul className="grid grid-cols-5">
          {MOBILE.map((n) => {
            const active = path.startsWith(n.href);
            return (
              <li key={n.href}>
                <Link href={n.href} className={cn("flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium", active ? "text-sea-700" : "text-ink-muted")} aria-current={active ? "page" : undefined}>
                  <span className={cn("grid h-8 w-12 place-items-center rounded-full transition", active && "bg-sea-50")}>
                    <n.icon className="h-5 w-5" aria-hidden />
                  </span>
                  {n.label.replace("AI ", "")}
                </Link>
              </li>
            );
          })}
          <li>
            <button onClick={() => setMoreOpen(true)} className="flex w-full flex-col items-center gap-1 py-2.5 text-[11px] font-medium text-ink-muted" aria-haspopup="dialog">
              <span className="grid h-8 w-12 place-items-center rounded-full">
                <MoreHorizontal className="h-5 w-5" aria-hidden />
              </span>
              More
            </button>
          </li>
        </ul>
      </nav>
      <AnimatePresence>
        {moreOpen && (
          <div className="fixed inset-0 z-[60] lg:hidden" role="dialog" aria-modal="true" aria-label="More navigation">
            <motion.div className="absolute inset-0 bg-ink/30" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMoreOpen(false)} />
            <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 30, stiffness: 300 }} className="absolute inset-x-0 bottom-0 rounded-t-3xl bg-white p-5 pb-8">
              <div className="mb-3 flex items-center justify-between">
                <p className="font-semibold">More</p>
                <button onClick={() => setMoreOpen(false)} aria-label="Close" className="rounded-lg p-1.5 hover:bg-slate-100">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[...NAV.slice(4), { href: "/safety", label: "Get help", icon: LifeBuoy }].map((n) => (
                  <Link key={n.href} href={n.href} className={cn("flex flex-col items-center gap-2 rounded-2xl border border-line p-4 text-sm font-medium", n.href === "/safety" ? "text-rose-700" : "text-ink-soft")}>
                    <n.icon className="h-5 w-5" aria-hidden />
                    {n.label}
                  </Link>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ConsentModal open={consentOpen} onDone={() => setConsentOpen(false)} />
    </div>
    </MotionConfig>
  );
}

function Sidebar() {
  const path = usePathname();
  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-[260px] flex-col border-r border-line bg-white/80 backdrop-blur-xl lg:flex" aria-label="Sidebar">
      <div className="flex h-16 items-center px-6">
        <Link href="/" aria-label="CarePath home">
          <Logo />
        </Link>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-2" aria-label="Student">
        <ul className="space-y-0.5">
          {NAV.map((n) => {
            const active = path.startsWith(n.href);
            return (
              <li key={n.href}>
                <Link
                  href={n.href}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
                    active ? "text-sea-800" : "text-ink-muted hover:bg-slate-50 hover:text-ink",
                  )}
                >
                  {active && <motion.span layoutId="nav-active" className="absolute inset-0 rounded-xl bg-sea-50 ring-1 ring-sea-100" transition={{ type: "spring", stiffness: 400, damping: 34 }} />}
                  <n.icon className="relative h-[18px] w-[18px]" aria-hidden />
                  <span className="relative">{n.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <div className="space-y-3 p-4">
        <div className="rounded-2xl bg-gradient-to-br from-sea-50 to-calm-50 p-4">
          <HeartHandshake className="h-5 w-5 text-sea-700" aria-hidden />
          <p className="mt-2 text-sm font-semibold">Talk to a person</p>
          <p className="mt-0.5 text-xs text-ink-muted">Counselors are available this week.</p>
          <Button href="/counselor" size="sm" variant="primary" className="mt-3 w-full">
            Book a session
          </Button>
        </div>
        <Link href="/safety" className="flex items-center justify-center gap-2 rounded-xl border border-rose-200 bg-rose-50/60 px-3 py-2.5 text-sm font-semibold text-rose-700 transition hover:bg-rose-50">
          <LifeBuoy className="h-4 w-4" aria-hidden /> Get help now
        </Link>
      </div>
    </aside>
  );
}

function useClickOutside(onOut: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onOut();
    };
    const k = (e: KeyboardEvent) => e.key === "Escape" && onOut();
    document.addEventListener("mousedown", h);
    document.addEventListener("keydown", k);
    return () => {
      document.removeEventListener("mousedown", h);
      document.removeEventListener("keydown", k);
    };
  }, [onOut]);
  return ref;
}

function Topbar() {
  const { session, bookings, checkIns, signOut, prefs } = useApp();
  const router = useRouter();
  const [notif, setNotif] = useState(false);
  const [menu, setMenu] = useState(false);
  const nRef = useClickOutside(() => setNotif(false));
  const mRef = useClickOutside(() => setMenu(false));
  const anon = session?.mode === "anonymous" || prefs.anonymousMode;
  const today = new Date().toDateString();
  const checkedToday = checkIns.some((c) => new Date(c.date).toDateString() === today);
  const upcoming = bookings.filter((b) => b.status === "confirmed").length;

  const notifications = [
    ...(!checkedToday ? [{ t: "Daily check-in", b: "Take 2 minutes to log how you’re feeling.", href: "/check-in" }] : []),
    ...(upcoming ? [{ t: "Upcoming session", b: "Your counselor session is confirmed.", href: "/counselor" }] : []),
    { t: "New resource", b: "“Exam Stress Reset” was added to your recommendations.", href: "/resources" },
  ];

  return (
    <header className="sticky top-0 z-30 border-b border-line/70 bg-mist/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-[1200px] items-center gap-3 px-4 sm:px-6 lg:px-8">
        <Link href="/" className="lg:hidden" aria-label="Home">
          <Logo compact />
        </Link>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[15px] font-semibold">
            {greeting()}, {session?.displayName ?? "there"}
          </p>
          <p className="hidden text-xs text-ink-muted sm:block">{new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}</p>
        </div>

        <Link
          href="/privacy"
          className="hidden items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-800 transition hover:bg-emerald-100 sm:inline-flex"
        >
          {anon ? <EyeOff className="h-3.5 w-3.5" aria-hidden /> : <ShieldCheck className="h-3.5 w-3.5" aria-hidden />}
          {anon ? "Anonymous mode" : "Private & encrypted"}
        </Link>

        <div className="relative" ref={nRef}>
          <button onClick={() => setNotif((o) => !o)} className="relative grid h-10 w-10 place-items-center rounded-xl text-ink-soft hover:bg-white" aria-label={`Notifications (${notifications.length})`} aria-expanded={notif}>
            <Bell className="h-5 w-5" aria-hidden />
            <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-sea-500 ring-2 ring-mist" aria-hidden />
          </button>
          <AnimatePresence>
            {notif && (
              <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="absolute right-0 mt-2 w-[min(340px,calc(100vw-32px))] overflow-hidden rounded-2xl border border-line bg-white shadow-lift">
                <p className="border-b border-line px-4 py-3 text-sm font-semibold">Notifications</p>
                <ul>
                  {notifications.map((n) => (
                    <li key={n.t}>
                      <button
                        onClick={() => {
                          setNotif(false);
                          router.push(n.href);
                        }}
                        className="block w-full px-4 py-3 text-left hover:bg-slate-50"
                      >
                        <span className="block text-sm font-medium">{n.t}</span>
                        <span className="block text-xs text-ink-muted">{n.b}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="relative" ref={mRef}>
          <button onClick={() => setMenu((o) => !o)} className="flex items-center gap-2 rounded-xl p-1 pr-2 hover:bg-white" aria-label="Profile menu" aria-expanded={menu}>
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-sea-400 to-calm-500 text-sm font-bold text-white">
              {anon ? "?" : (session?.displayName ?? "S").charAt(0)}
            </span>
          </button>
          <AnimatePresence>
            {menu && (
              <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="absolute right-0 mt-2 w-60 overflow-hidden rounded-2xl border border-line bg-white p-1.5 shadow-lift">
                <div className="px-3 py-2.5">
                  <p className="text-sm font-semibold">{anon ? "Anonymous student" : session?.displayName}</p>
                  <p className="truncate text-xs text-ink-muted">{anon ? "Stored only on this device" : session?.email}</p>
                </div>
                <div className="my-1 h-px bg-line" />
                {[
                  ["Privacy Center", "/privacy", ShieldCheck],
                  ["Settings", "/settings", Settings],
                  ["Counselor portal (staff)", "/counselor-portal", HeartHandshake],
                  ["University dashboard (staff)", "/university", BarChart3],
                ].map(([l, h, I]) => {
                  const Icon = I as LucideIcon;
                  return (
                    <Link key={h as string} href={h as string} onClick={() => setMenu(false)} className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-ink-soft hover:bg-slate-50">
                      <Icon className="h-4 w-4" aria-hidden /> {l as string}
                    </Link>
                  );
                })}
                <div className="my-1 h-px bg-line" />
                <button
                  onClick={() => {
                    signOut();
                    router.push("/");
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-ink-soft hover:bg-slate-50"
                >
                  <LogOut className="h-4 w-4" aria-hidden /> Sign out
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
}
