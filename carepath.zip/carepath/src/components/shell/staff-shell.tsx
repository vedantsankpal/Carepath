"use client";

import { ArrowLeft, Building2, HeartHandshake, Lock } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { Logo } from "@/components/ui";
import { cn } from "@/lib/utils";

export function StaffShell({ children, role }: { children: ReactNode; role: "counselor" | "admin" }) {
  const path = usePathname();
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-line bg-white/85 backdrop-blur-xl">
        <div className="container flex h-16 items-center gap-3">
          <Link href="/" aria-label="CarePath home">
            <Logo />
          </Link>
          <span className="hidden rounded-full bg-lav-50 px-2.5 py-1 text-xs font-semibold text-[#4b3f8f] ring-1 ring-lav-200 sm:inline">
            {role === "counselor" ? "Counselor workspace" : "Institution workspace"}
          </span>
          <nav className="ml-auto flex items-center gap-1" aria-label="Staff">
            {[
              { href: "/counselor-portal", label: "Counselor portal", icon: HeartHandshake },
              { href: "/university", label: "University", icon: Building2 },
            ].map((n) => (
              <Link key={n.href} href={n.href} aria-current={path === n.href ? "page" : undefined} className={cn("inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium", path === n.href ? "bg-sea-50 text-sea-800" : "text-ink-muted hover:bg-slate-50")}>
                <n.icon className="h-4 w-4" aria-hidden />
                <span className="hidden sm:inline">{n.label}</span>
              </Link>
            ))}
            <Link href="/dashboard" className="ml-1 inline-flex items-center gap-1 rounded-lg px-3 py-2 text-sm text-ink-muted hover:bg-slate-50">
              <ArrowLeft className="h-4 w-4" aria-hidden /> <span className="hidden md:inline">Student app</span>
            </Link>
          </nav>
        </div>
      </header>
      <div className="border-b border-line bg-sea-50/60">
        <p className="container flex items-center gap-2 py-2 text-xs text-sea-900">
          <Lock className="h-3.5 w-3.5" aria-hidden />
          {role === "counselor"
            ? "Role-based access: you see pseudonymous IDs and only the context students chose to share."
            : "Aggregated & anonymised data only. Groups under 10 students are suppressed. Sample data for demo."}
        </p>
      </div>
      <main id="main" className="container py-8">
        {children}
      </main>
    </div>
  );
}
