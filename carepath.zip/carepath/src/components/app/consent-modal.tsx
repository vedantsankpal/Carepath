"use client";

import { EyeOff, Lock, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui";
import { Modal } from "@/components/ui/modal";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";

function Check({ id, checked, onChange, label, hint, required }: { id: string; checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string; required?: boolean }) {
  return (
    <label htmlFor={id} className={cn("flex cursor-pointer items-start gap-3 rounded-2xl border p-4 transition", checked ? "border-sea-300 bg-sea-50/60" : "border-line hover:bg-slate-50")}>
      <input id={id} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="mt-0.5 h-4 w-4 shrink-0 rounded accent-sea-600" />
      <span>
        <span className="block text-sm font-medium text-ink">
          {label} {required && <span className="text-xs font-normal text-ink-muted">(required)</span>}
        </span>
        {hint && <span className="mt-0.5 block text-xs text-ink-muted">{hint}</span>}
      </span>
    </label>
  );
}

export function ConsentModal({ open, onDone }: { open: boolean; onDone: () => void }) {
  const { giveConsent } = useApp();
  const [a, setA] = useState(false);
  const [b, setB] = useState(false);
  const [c, setC] = useState(false);
  const [d, setD] = useState(true);

  return (
    <Modal open={open} onClose={() => {}} dismissible={false} title="Before we begin" description="A quick, plain-language summary of how CarePath works. You can change optional choices anytime in the Privacy Center." size="lg">
      <div className="mb-4 grid gap-2 sm:grid-cols-3">
        {[
          [ShieldCheck, "Not a diagnosis", "Supportive guidance only"],
          [Lock, "Encrypted", "In transit & at rest"],
          [EyeOff, "You control sharing", "Nothing shared without consent"],
        ].map(([Icon, t, s]) => {
          const I = Icon as typeof Lock;
          return (
            <div key={t as string} className="rounded-2xl bg-mist p-3">
              <I className="h-4 w-4 text-sea-600" aria-hidden />
              <p className="mt-2 text-sm font-semibold">{t as string}</p>
              <p className="text-xs text-ink-muted">{s as string}</p>
            </div>
          );
        })}
      </div>
      <div className="space-y-2.5">
        <Check id="c-ai" required checked={a} onChange={setA} label="I understand that this AI assistant is not a replacement for professional mental-health care." />
        <Check id="c-data" required checked={b} onChange={setB} label="I agree to CarePath storing my check-ins to show me my own trends." hint="Only you can see them. You can export or delete them anytime." />
        <Check id="c-share" checked={c} onChange={setC} label="Let counselors see my recent check-in summary when I book a session." hint="Optional. You can also decide per booking." />
        <Check id="c-agg" checked={d} onChange={setD} label="Include my data in anonymised campus-wide trends." hint="Optional. Only aggregated groups of 10+ students are ever shown." />
      </div>
      <p className="mt-4 text-xs text-ink-muted">If you are in immediate danger, please contact emergency services (112) or a trusted person nearby right away.</p>
      <div className="mt-5 flex justify-end">
        <Button
          disabled={!a || !b}
          onClick={() => {
            giveConsent({ aiNotReplacement: a, dataProcessing: b, shareWithCounselor: c, anonymousAnalytics: d });
            onDone();
          }}
        >
          Agree and continue
        </Button>
      </div>
    </Modal>
  );
}
