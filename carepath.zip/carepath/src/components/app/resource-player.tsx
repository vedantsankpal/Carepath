"use client";

import { motion, useReducedMotion } from "framer-motion";
import { ArrowLeft, ArrowRight, Bookmark, BookmarkCheck, BookOpen, CheckCircle2, Clock, Headphones, PartyPopper, Play, Sparkles, Wind } from "lucide-react";
import { useEffect, useState } from "react";
import { Badge, Button } from "@/components/ui";
import { Modal } from "@/components/ui/modal";
import { useApp } from "@/lib/store";
import type { Resource, ResourceFormat } from "@/lib/types";
import { cn } from "@/lib/utils";

export const FORMAT_META: Record<ResourceFormat, { label: string; icon: typeof Wind }> = {
  exercise: { label: "Exercise", icon: Sparkles },
  guide: { label: "Guide", icon: BookOpen },
  audio: { label: "Guided", icon: Headphones },
  article: { label: "Read", icon: BookOpen },
};

export function ResourceCard({ r, onStart, compact }: { r: Resource; onStart: (r: Resource) => void; compact?: boolean }) {
  const { completedResources, savedResources, toggleSaved } = useApp();
  const done = completedResources.includes(r.id);
  const saved = savedResources.includes(r.id);
  const F = FORMAT_META[r.format];
  return (
    <article className="card group flex h-full flex-col p-5 transition hover:-translate-y-0.5 hover:shadow-lift">
      <div className="flex items-start justify-between gap-2">
        <Badge tone="sea">{r.category}</Badge>
        <button onClick={() => toggleSaved(r.id)} className="rounded-lg p-1 text-ink-faint hover:bg-slate-50 hover:text-sea-700" aria-label={saved ? `Remove ${r.title} from saved` : `Save ${r.title}`} aria-pressed={saved}>
          {saved ? <BookmarkCheck className="h-4 w-4 text-sea-600" /> : <Bookmark className="h-4 w-4" />}
        </button>
      </div>
      <h3 className="mt-3 font-semibold leading-snug">{r.title}</h3>
      {!compact && <p className="mt-1.5 flex-1 text-sm text-ink-muted">{r.description}</p>}
      <div className={cn("flex justify-between gap-2", compact ? "mt-auto flex-col items-start pt-3" : "mt-4 items-center")}>
        <span className="inline-flex flex-wrap items-center gap-x-3 gap-y-1 whitespace-nowrap text-xs text-ink-muted">
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" aria-hidden /> {r.minutes} min
          </span>
          <span className="inline-flex items-center gap-1">
            <F.icon className="h-3.5 w-3.5" aria-hidden /> {F.label}
          </span>
          {done && (
            <span className="inline-flex items-center gap-1 text-emerald-700">
              <CheckCircle2 className="h-3.5 w-3.5" aria-hidden /> Done
            </span>
          )}
        </span>
        <Button size="sm" variant={done ? "outline" : "soft"} icon={Play} onClick={() => onStart(r)} aria-label={`Start ${r.title}`} className={compact ? "w-full" : ""}>
          {done ? "Again" : "Start"}
        </Button>
      </div>
    </article>
  );
}

function Breather({ seconds }: { seconds: number }) {
  const reduce = useReducedMotion();
  const [phase, setPhase] = useState<"in" | "hold" | "out">("in");
  const [left, setLeft] = useState(seconds);
  useEffect(() => {
    const pattern: ["in" | "hold" | "out", number][] = [["in", 4000], ["hold", 4000], ["out", 6000]];
    let i = 0;
    let t: ReturnType<typeof setTimeout>;
    const next = () => {
      setPhase(pattern[i][0]);
      t = setTimeout(() => {
        i = (i + 1) % 3;
        next();
      }, pattern[i][1]);
    };
    next();
    const c = setInterval(() => setLeft((l) => Math.max(0, l - 1)), 1000);
    return () => {
      clearTimeout(t);
      clearInterval(c);
    };
  }, []);
  const scale = phase === "in" ? 1 : phase === "hold" ? 1 : 0.62;
  return (
    <div className="flex flex-col items-center py-4">
      <div className="relative grid h-56 w-56 place-items-center">
        <div className="absolute inset-0 rounded-full bg-sea-50" />
        <motion.div
          className="absolute inset-4 rounded-full bg-gradient-to-br from-sea-200 to-calm-200"
          animate={{ scale: reduce ? 0.85 : scale }}
          initial={{ scale: 0.62 }}
          transition={{ duration: phase === "in" ? 4 : phase === "out" ? 6 : 0.2, ease: "easeInOut" }}
        />
        <div className="relative text-center" aria-live="polite">
          <p className="text-lg font-semibold text-sea-900">{phase === "in" ? "Breathe in" : phase === "hold" ? "Hold" : "Breathe out"}</p>
          <p className="text-sm text-sea-800">{phase === "in" ? "4 seconds" : phase === "hold" ? "4 seconds" : "6 seconds"}</p>
        </div>
      </div>
      <p className="mt-3 text-sm tabular-nums text-ink-muted">
        {Math.floor(left / 60)}:{String(left % 60).padStart(2, "0")} remaining
      </p>
    </div>
  );
}

export function ResourcePlayer({ resource, onClose }: { resource: Resource | null; onClose: () => void }) {
  const { completeResource, toast, advanceDemo } = useApp();
  const [step, setStep] = useState(0);
  const [finished, setFinished] = useState(false);
  const [helpful, setHelpful] = useState<boolean | null>(null);

  useEffect(() => {
    setStep(0);
    setFinished(false);
    setHelpful(null);
  }, [resource?.id]);

  if (!resource) return <Modal open={false} onClose={onClose} title="">{null}</Modal>;
  const s = resource.steps[step];
  const last = step === resource.steps.length - 1;

  return (
    <Modal open={!!resource} onClose={onClose} title={resource.title} description={`${resource.category} · ${resource.minutes} min`} size="lg">
      {finished ? (
        <div className="py-4 text-center">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-emerald-50 text-emerald-700">
            <PartyPopper className="h-6 w-6" aria-hidden />
          </span>
          <p className="mt-4 text-lg font-semibold">Nice work taking that time for yourself.</p>
          <p className="mt-1 text-sm text-ink-muted">Did this help, even a little?</p>
          <div className="mt-4 flex justify-center gap-2">
            {[
              [true, "Yes, it helped"],
              [false, "Not really"],
            ].map(([v, l]) => (
              <button
                key={String(v)}
                onClick={() => setHelpful(v as boolean)}
                className={cn("chip", helpful === v && "chip-active")}
                aria-pressed={helpful === v}
              >
                {l as string}
              </button>
            ))}
          </div>
          {helpful === false && <p className="mx-auto mt-4 max-w-sm text-sm text-ink-muted">Thanks for being honest. Different things help different people — the AI assistant or a counselor might be a better next step.</p>}
          <div className="mt-6 flex justify-center gap-2">
            {helpful === false && (
              <Button variant="outline" href="/assistant">
                Talk it through
              </Button>
            )}
            <Button onClick={onClose}>Done</Button>
          </div>
        </div>
      ) : (
        <div>
          <div className="mb-5 flex gap-1.5" aria-hidden>
            {resource.steps.map((_, i) => (
              <span key={i} className={cn("h-1.5 flex-1 rounded-full transition-colors", i <= step ? "bg-sea-500" : "bg-slate-200")} />
            ))}
          </div>
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-ink-faint">
            Step {step + 1} of {resource.steps.length}
          </p>
          <motion.div key={step} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }}>
            <h3 className="mt-1 text-xl font-semibold">{s.title}</h3>
            <p className="mt-2 text-[15px] leading-relaxed text-ink-soft">{s.body}</p>
            {s.seconds && resource.breathing && <Breather seconds={s.seconds} />}
            {s.seconds && !resource.breathing && (
              <div className="mt-5 flex items-center gap-3 rounded-2xl bg-lav-50 p-4 text-sm text-[#4b3f8f]">
                <Headphones className="h-5 w-5" aria-hidden /> Take about {Math.round(s.seconds / 60)} minute{s.seconds >= 120 ? "s" : ""} here. There&apos;s no rush.
              </div>
            )}
          </motion.div>
          <div className="mt-7 flex items-center justify-between">
            <Button variant="ghost" icon={ArrowLeft} disabled={step === 0} onClick={() => setStep((x) => x - 1)}>
              Back
            </Button>
            <Button
              iconRight={last ? CheckCircle2 : ArrowRight}
              onClick={() => {
                if (last) {
                  completeResource(resource.id);
                  advanceDemo(5);
                  setFinished(true);
                  toast({ title: "Added to your wellness log", body: resource.title });
                } else setStep((x) => x + 1);
              }}
            >
              {last ? "Finish" : "Next"}
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
}
