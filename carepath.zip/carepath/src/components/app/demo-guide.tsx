"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronDown, ChevronRight, PlayCircle, X } from "lucide-react";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";

export const DEMO_STEPS = [
  { title: "Sign in or continue anonymously", href: "/login", hint: "Consent step included" },
  { title: "Open Check-In", href: "/check-in", hint: "2-minute, 4-step flow" },
  { title: "Complete mood & stress check", href: "/check-in", hint: "Try intensity 4–5 to see routing" },
  { title: "Get your support recommendation", href: "/check-in", hint: "AI-assisted, non-diagnostic" },
  { title: "Open a recommended resource", href: "/resources", hint: "Try the breathing exercise" },
  { title: "Talk to the AI Assistant", href: "/assistant", hint: "Use a quick prompt" },
  { title: "Choose Counselor Connect", href: "/counselor", hint: "From chat or sidebar" },
  { title: "Book a sample appointment", href: "/counselor", hint: "Counselor → date → time" },
  { title: "View your Wellness Dashboard", href: "/wellness", hint: "Trends & what helped" },
];

export function DemoGuide() {
  const { demoStep, setDemoStep, hydrated } = useApp();
  const [collapsed, setCollapsed] = useState(true);
  const router = useRouter();
  const path = usePathname();

  // Never cover emergency contacts with demo chrome.
  if (!hydrated || demoStep === null || path === "/safety") return null;
  const inApp = !["/", "/login", "/technology", "/university", "/counselor-portal"].includes(path);

  const go = (i: number) => {
    setDemoStep(i);
    router.push(DEMO_STEPS[i].href);
  };

  return (
    <AnimatePresence>
      <motion.aside
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={cn(
          "fixed right-3 z-[70] w-[min(320px,calc(100vw-24px))] rounded-2xl border border-line bg-white/95 shadow-lift backdrop-blur-xl sm:right-5",
          inApp ? "top-[72px] lg:bottom-5 lg:top-auto" : "bottom-4",
        )}
        aria-label="Demo guide"
      >
        <div className="flex items-center justify-between gap-2 px-4 py-3">
          <button className="flex items-center gap-2 text-left" onClick={() => setCollapsed((c) => !c)} aria-expanded={!collapsed}>
            <PlayCircle className="h-4 w-4 text-sea-600" aria-hidden />
            <span className="text-sm font-semibold">Demo journey</span>
            <span className="rounded-full bg-sea-50 px-2 py-0.5 text-xs font-medium text-sea-800">
              {Math.min(demoStep + 1, DEMO_STEPS.length)}/{DEMO_STEPS.length}
            </span>
            <ChevronDown className={cn("h-4 w-4 text-ink-muted transition", collapsed && "-rotate-90")} aria-hidden />
          </button>
          <button onClick={() => setDemoStep(null)} className="rounded-md p-1 text-ink-faint hover:bg-slate-100 hover:text-ink" aria-label="Close demo guide">
            <X className="h-4 w-4" />
          </button>
        </div>
        {collapsed && (
          <div className="flex items-center gap-3 px-4 py-3">
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold">{DEMO_STEPS[Math.min(demoStep, DEMO_STEPS.length - 1)].title}</p>
              <p className="truncate text-xs text-ink-muted">{DEMO_STEPS[Math.min(demoStep, DEMO_STEPS.length - 1)].hint}</p>
            </div>
            <button
              className="shrink-0 rounded-lg bg-sea-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-sea-700"
              onClick={() => (demoStep >= DEMO_STEPS.length - 1 ? setDemoStep(null) : go(demoStep + 1))}
            >
              {demoStep >= DEMO_STEPS.length - 1 ? "Finish" : "Next"}
            </button>
          </div>
        )}
        {!collapsed && (
          <ol className="max-h-[46vh] overflow-y-auto border-t border-line p-2">
            {DEMO_STEPS.map((s, i) => {
              const done = i < demoStep;
              const active = i === demoStep;
              return (
                <li key={i}>
                  <button
                    onClick={() => go(i)}
                    className={cn(
                      "flex w-full items-start gap-3 rounded-xl px-2.5 py-2 text-left transition",
                      active ? "bg-sea-50" : "hover:bg-slate-50",
                    )}
                  >
                    <span
                      className={cn(
                        "mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-[11px] font-bold",
                        done ? "bg-sea-600 text-white" : active ? "bg-white text-sea-700 ring-2 ring-sea-500" : "bg-slate-100 text-ink-muted",
                      )}
                    >
                      {done ? <Check className="h-3 w-3" /> : i + 1}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className={cn("block text-sm", active ? "font-semibold text-ink" : "text-ink-soft")}>{s.title}</span>
                      {active && <span className="block text-xs text-ink-muted">{s.hint}</span>}
                    </span>
                    {active && <ChevronRight className="mt-0.5 h-4 w-4 text-sea-600" aria-hidden />}
                  </button>
                </li>
              );
            })}
          </ol>
        )}
        {!collapsed && (
          <div className="flex gap-2 border-t border-line p-3">
            <button
              className="flex-1 rounded-lg border border-line py-2 text-sm font-medium text-ink-soft hover:bg-slate-50 disabled:opacity-40"
              disabled={demoStep === 0}
              onClick={() => go(Math.max(0, demoStep - 1))}
            >
              Back
            </button>
            <button
              className="flex-1 rounded-lg bg-sea-600 py-2 text-sm font-semibold text-white hover:bg-sea-700"
              onClick={() => (demoStep >= DEMO_STEPS.length - 1 ? setDemoStep(null) : go(demoStep + 1))}
            >
              {demoStep >= DEMO_STEPS.length - 1 ? "Finish" : "Next step"}
            </button>
          </div>
        )}
      </motion.aside>
    </AnimatePresence>
  );
}
