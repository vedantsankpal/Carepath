"use client";

import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import type { ReactNode } from "react";

/** Validated categorical order (CVD-safe on white). Assign in this order, never cycled. */
export const CHART = {
  teal: "#0f9189",
  blue: "#4f77e4",
  amber: "#c9822b",
  violet: "#8a6fd6",
  grid: "#edf1f4",
  axis: "#8a98a6",
};

const axisProps = { tick: { fill: CHART.axis, fontSize: 12 }, axisLine: false, tickLine: false } as const;

function TooltipBox({ active, payload, label, fmt }: { active?: boolean; payload?: { name: string; value: number; color: string }[]; label?: string; fmt?: (v: number, name: string) => string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-line bg-white px-3 py-2 text-xs shadow-lift">
      <p className="mb-1 font-semibold text-ink">{label}</p>
      {payload.map((p) => (
        <p key={p.name} className="flex items-center gap-2 text-ink-soft">
          <span className="h-2 w-2 rounded-full" style={{ background: p.color }} aria-hidden />
          {p.name}: <span className="font-semibold text-ink">{fmt ? fmt(p.value, p.name) : p.value}</span>
        </p>
      ))}
    </div>
  );
}

function LegendRow({ payload }: { payload?: { value: string; color: string }[] }) {
  return (
    <div className="flex flex-wrap justify-end gap-4 pb-2 text-xs text-ink-soft">
      {payload?.map((p) => (
        <span key={p.value} className="inline-flex items-center gap-1.5">
          <span className="h-2 w-3 rounded-full" style={{ background: p.color }} aria-hidden />
          {p.value}
        </span>
      ))}
    </div>
  );
}

export function ChartFrame({ height = 240, children, label }: { height?: number; children: ReactNode; label: string }) {
  return (
    <div style={{ height }} role="img" aria-label={label} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        {children as React.ReactElement}
      </ResponsiveContainer>
    </div>
  );
}

export interface SeriesSpec {
  key: string;
  name: string;
  color: string;
  dashed?: boolean;
}

/** Multi-series line/area over time. One y-axis only. */
export function TrendChart({
  data,
  xKey,
  series,
  yDomain,
  yTicks,
  yFormat,
  height = 240,
  area = true,
  label,
  tooltipFmt,
}: {
  data: Record<string, string | number | null>[];
  xKey: string;
  series: SeriesSpec[];
  yDomain?: [number, number];
  yTicks?: number[];
  yFormat?: (v: number) => string;
  height?: number;
  area?: boolean;
  label: string;
  tooltipFmt?: (v: number, name: string) => string;
}) {
  const Chart = area ? AreaChart : LineChart;
  return (
    <ChartFrame height={height} label={label}>
      <Chart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
        <defs>
          {series.map((s) => (
            <linearGradient key={s.key} id={`grad-${s.key}`} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0" stopColor={s.color} stopOpacity={0.18} />
              <stop offset="1" stopColor={s.color} stopOpacity={0} />
            </linearGradient>
          ))}
        </defs>
        <CartesianGrid vertical={false} stroke={CHART.grid} />
        <XAxis dataKey={xKey} {...axisProps} minTickGap={16} />
        <YAxis {...axisProps} domain={yDomain} ticks={yTicks} tickFormatter={yFormat} width={48} />
        <Tooltip content={<TooltipBox fmt={tooltipFmt} />} cursor={{ stroke: "#c8d3dc", strokeWidth: 1 }} />
        {series.length > 1 && <Legend verticalAlign="top" content={<LegendRow />} />}
        {series.map((s) =>
          area ? (
            <Area
              key={s.key}
              type="monotone"
              dataKey={s.key}
              name={s.name}
              stroke={s.color}
              strokeWidth={2}
              strokeDasharray={s.dashed ? "5 4" : undefined}
              fill={`url(#grad-${s.key})`}
              dot={data.length <= 14 ? { r: 3.5, strokeWidth: 2, stroke: "#fff", fill: s.color } : false}
              activeDot={{ r: 5, strokeWidth: 2, stroke: "#fff" }}
              connectNulls
              isAnimationActive={false}
            />
          ) : (
            <Line
              key={s.key}
              type="monotone"
              dataKey={s.key}
              name={s.name}
              stroke={s.color}
              strokeWidth={2}
              strokeDasharray={s.dashed ? "5 4" : undefined}
              dot={data.length <= 14 ? { r: 3.5, strokeWidth: 2, stroke: "#fff", fill: s.color } : false}
              activeDot={{ r: 5, strokeWidth: 2, stroke: "#fff" }}
              connectNulls
              isAnimationActive={false}
            />
          ),
        )}
      </Chart>
    </ChartFrame>
  );
}

export function BarsChart({
  data,
  xKey,
  series,
  height = 240,
  stacked,
  horizontal,
  label,
  highlightIndex,
  valueFmt,
}: {
  data: Record<string, string | number>[];
  xKey: string;
  series: SeriesSpec[];
  height?: number;
  stacked?: boolean;
  horizontal?: boolean;
  label: string;
  highlightIndex?: number;
  valueFmt?: (v: number) => string;
}) {
  return (
    <ChartFrame height={height} label={label}>
      <BarChart data={data} layout={horizontal ? "vertical" : "horizontal"} margin={{ top: 8, right: 12, left: horizontal ? 8 : -18, bottom: 0 }} barGap={2} barCategoryGap={horizontal ? 8 : "28%"}>
        <CartesianGrid vertical={horizontal} horizontal={!horizontal} stroke={CHART.grid} />
        {horizontal ? <XAxis type="number" {...axisProps} tickFormatter={valueFmt} /> : <XAxis dataKey={xKey} {...axisProps} />}
        {horizontal ? <YAxis type="category" dataKey={xKey} {...axisProps} width={112} /> : <YAxis {...axisProps} width={48} tickFormatter={valueFmt} />}
        <Tooltip content={<TooltipBox fmt={valueFmt ? (v) => valueFmt(v) : undefined} />} cursor={{ fill: "rgba(15,145,137,0.06)" }} />
        {series.length > 1 && <Legend verticalAlign="top" content={<LegendRow />} />}
        {series.map((s, si) => (
          <Bar
            key={s.key}
            dataKey={s.key}
            name={s.name}
            fill={s.color}
            stackId={stacked ? "s" : undefined}
            radius={stacked ? (si === series.length - 1 ? (horizontal ? [0, 4, 4, 0] : [4, 4, 0, 0]) : 0) : horizontal ? [0, 4, 4, 0] : [4, 4, 0, 0]}
            stroke="#fff"
            strokeWidth={stacked ? 2 : 0}
            maxBarSize={horizontal ? 18 : 36}
            animationDuration={800}
          >
            {highlightIndex !== undefined && series.length === 1
              ? data.map((_, i) => <Cell key={i} fill={i === highlightIndex ? s.color : `${s.color}73`} />)
              : null}
          </Bar>
        ))}
      </BarChart>
    </ChartFrame>
  );
}
