"use client";

import { Bell, LogOut, PlayCircle, RotateCcw, User } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Badge, Button, Card, CardHeader, PageHeader, Switch } from "@/components/ui";
import { useApp } from "@/lib/store";

export default function SettingsPage() {
  const { session, prefs, updatePrefs, signIn, signOut, startDemo, toast } = useApp();
  const router = useRouter();
  const [name, setName] = useState(session?.displayName ?? "");

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader eyebrow="Settings" title="Settings" subtitle="Personalise how CarePath works for you." />
      <div className="space-y-5">
        <Card className="p-6">
          <CardHeader icon={User} title="Profile" subtitle={session?.mode === "anonymous" ? "You’re using CarePath anonymously" : session?.email} action={<Badge tone={session?.mode === "anonymous" ? "sea" : "slate"}>{session?.mode === "anonymous" ? "Anonymous" : "Account"}</Badge>} />
          <form
            className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-end"
            onSubmit={(e) => {
              e.preventDefault();
              if (!session || name.trim().length < 1) return;
              signIn({ ...session, displayName: name.trim() });
              toast({ title: "Profile updated" });
            }}
          >
            <div className="flex-1">
              <label htmlFor="dn" className="label">
                What should we call you?
              </label>
              <input id="dn" className="input" value={name} onChange={(e) => setName(e.target.value)} maxLength={30} />
            </div>
            <Button type="submit" variant="outline">
              Save
            </Button>
          </form>
        </Card>

        <Card className="p-6">
          <CardHeader icon={Bell} title="Preferences" />
          <div className="mt-2 divide-y divide-line">
            <Switch id="s-rem" checked={prefs.reminders} onChange={(v) => updatePrefs({ reminders: v })} label="Gentle daily check-in reminder" description="A single, quiet nudge in the evening. Never more than one a day." />
            <Switch id="s-motion" checked={prefs.reduceMotion} onChange={(v) => updatePrefs({ reduceMotion: v })} label="Reduce motion" description="Minimise animations across the app." />
          </div>
        </Card>

        <Card className="p-6">
          <CardHeader icon={PlayCircle} title="Demo" subtitle="For hackathon presentations" />
          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              variant="soft"
              icon={RotateCcw}
              onClick={() => {
                startDemo();
                toast({ title: "Demo data restored", body: "Sample student “Aarav” with 30 days of history." });
                router.push("/dashboard");
              }}
            >
              Reset demo data
            </Button>
            <Button
              variant="ghost"
              icon={LogOut}
              onClick={() => {
                signOut();
                router.push("/");
              }}
            >
              Sign out
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
