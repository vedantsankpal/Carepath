"use client";

import { motion } from "framer-motion";
import { CalendarDays, Info, Lightbulb, Sparkles, ThumbsUp, TrendingUp } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { BarsChart, CHART, TrendChart } from "@/components/charts";
import { Button, Card, CardHeader, EmptyState, PageHeader } from "@/components/ui";
import { staggerItem } from "@/components/ui/motion";
import { FACTORS, MOODS } from "@/lib/assessment";
import { DEMO_RESOURCE_USAGE, DEMO_SUPPORT_USAGE } from "@/lib/data/demo";
import { getResource } from "@/lib/data/resources";
import { useApp } from "@/lib/store";
import { addDays, cn, toISODate } from "@/lib/utils";
import { moodWord, streak, summary, topFactors, trendSeries } from "@/lib/wellness";

export default function WellnessPage() {
  const { checkIns, bookings, completedResources, chat, session, advanceDemo } = useApp();
  const [range, setRange] = useState<14 | 30>(30);
  useEffect(() => advanceDemo(8), [advanceDemo]);

  const isDemo = session?.id === "demo_student";
  const data = useMemo(() => trendSeries(checkIns, range), [checkIns, range]);
  const s7 = summary(checkIns, 7);
  const s30 = summary(checkIns, 30);
  const st = streak(checkIns);
  const themes = topFactors(checkIns.filter((c) => new Date(c.date) > addDays(new Date(), -30)), 5);

  const resourceUsage = isDemo
    ? DEMO_RESOURCE_USAGE
    : completedResources.map((id) => ({ resourceId: id, uses: 1, helpful: 1 }));
  const resourceData = resourceUsage
    .map((u) => ({ name: getResource(u.resourceId)?.title.replace(/^\d+-Minute /, "") ?? u.resourceId, sessions: u.uses }))
    .slice(0, 5);

  const supportData = isDemo
    ? DEMO_SUPPORT_USAGE
    : [{ week: "This week", assistant: chat.filter((m) => m.role === "user").length, resources: completedResources.length, counselor: bookings.filter((b) => b.status !== "cancelled").length }];

  const days28 = Array.from({ length: 28 }, (_, i) => toISODate(addDays(new Date(), -(27 - i))));
  const byDay = new Map(checkIns.map((c) => [toISODate(new Date(c.date)), c.mood]));

  if (checkIns.length === 0) {
    return (
      <div>
        <PageHeader eyebrow="Wellness dashboard" title="Your wellness, over time" />
        <EmptyState icon={TrendingUp} title="Nothing to show yet" body="Your trends appear after a few check-ins. It only takes two minutes." action={<Button href="/check-in">Start a check-in</Button>} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        eyebrow="Wellness dashboard"
        title="Your wellness, over time"
        subtitle="Patterns from what you’ve shared. These are self-reported trends to help you reflect — not a clinical assessment."
        action={
          <div className="flex rounded-xl bg-white p-1 ring-1 ring-line" role="tablist" aria-label="Range">
            {([14, 30] as const).map((r) => (
              <button key={r} role="tab" aria-selected={range === r} onClick={() => setRange(r)} className={cn("rounded-lg px-3.5 py-1.5 text-sm font-semibold transition", range === r ? "bg-sea-600 text-white" : "text-ink-muted")}>
                {r} days
              </button>
            ))}
          </div>
        }
      />

      <motion.div initial="hidden" animate="show" variants={{ hidden: {}, show: { transition: { staggerChildren: 0.05 } } }} className="grid gap-5 lg:grid-cols-3">
        <motion.div variants={staggerItem} className="grid grid-cols-2 gap-3 lg:col-span-3 lg:grid-cols-4">
          {[
            ["Typical mood (7d)", moodWord(s7.moodAvg), s7.moodDelta !== null && s7.moodDelta > 0.1 ? "Lifting vs last week" : s7.moodDelta !== null && s7.moodDelta < -0.1 ? "Dipped vs last week" : "Similar to last week"],
            ["Avg. stress (7d)", s7.stressAvg?.toFixed(1) ?? "—", "out of 5"],
            ["Check-in consistency", `${s30.consistency}%`, `${s30.daysCheckedIn} of 30 days`],
            ["Current streak", `${st} day${st === 1 ? "" : "s"}`, "Keep it gentle — no pressure"],
          ].map(([l, v, h]) => (
            <Card key={l} className="p-4 sm:p-5">
              <p className="text-xs text-ink-muted sm:text-sm">{l}</p>
              <p className="mt-1 text-2xl font-bold">{v}</p>
              <p className="mt-0.5 text-xs text-ink-muted">{h}</p>
            </Card>
          ))}
        </motion.div>

        <motion.div variants={staggerItem} className="lg:col-span-2">
          <Card className="h-full p-6">
            <CardHeader icon={TrendingUp} title="Mood & stress trend" subtitle="1 = low · 5 = high. Gaps are days without a check-in." />
            <div className="mt-4">
              <TrendChart
                label={`Mood and stress trend over ${range} days`}
                data={data}
                xKey="label"
                yDomain={[1, 5]}
                yTicks={[1, 2, 3, 4, 5]}
                series={[
                  { key: "mood", name: "Mood", color: CHART.teal },
                  { key: "stress", name: "Stress", color: CHART.blue, dashed: true },
                ]}
                tooltipFmt={(v, n) => (n === "Mood" ? `${v} · ${MOODS.find((m) => m.value === v)?.label}` : `${v} / 5`)}
                height={260}
              />
            </div>
          </Card>
        </motion.div>

        <motion.div variants={staggerItem}>
          <Card className="h-full p-6">
            <CardHeader icon={CalendarDays} title="Check-in consistency" subtitle="Last 4 weeks" />
            <div className="mt-5 grid grid-cols-7 gap-1.5" role="img" aria-label={`Checked in on ${s30.daysCheckedIn} of the last 30 days`}>
              {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
                <span key={i} className="text-center text-[10px] font-medium text-ink-faint">
                  {d}
                </span>
              ))}
              {Array.from({ length: (new Date(`${days28[0]}T00:00:00`).getDay() + 6) % 7 }).map((_, i) => (
                <span key={`pad${i}`} />
              ))}
              {days28.map((d) => {
                const m = byDay.get(d);
                return (
                  <span
                    key={d}
                    title={`${d}: ${m ? MOODS.find((x) => x.value === m)?.label : "No check-in"}`}
                    className={cn(
                      "aspect-square rounded-md",
                      !m && "bg-slate-100",
                      m === 1 && "bg-sea-100",
                      m === 2 && "bg-sea-200",
                      m === 3 && "bg-sea-300",
                      m === 4 && "bg-sea-500",
                      m === 5 && "bg-sea-700",
                    )}
                  />
                );
              })}
            </div>
            <div className="mt-4 flex items-center justify-between text-[11px] text-ink-muted">
              <span>Lower mood</span>
              <span className="flex gap-1" aria-hidden>
                {["bg-sea-100", "bg-sea-200", "bg-sea-300", "bg-sea-500", "bg-sea-700"].map((c) => (
                  <span key={c} className={cn("h-3 w-3 rounded", c)} />
                ))}
              </span>
              <span>Higher mood</span>
            </div>
            <p className="mt-4 text-sm text-ink-muted">Grey squares are days you didn’t check in — that’s completely fine.</p>
          </Card>
        </motion.div>

        <motion.div variants={staggerItem}>
          <Card className="h-full p-6">
            <CardHeader title="Support usage" subtitle={isDemo ? "Last 4 weeks" : "So far"} />
            <div className="mt-3">
              <BarsChart
                label="Support usage by week"
                data={supportData}
                xKey="week"
                series={[
                  { key: "assistant", name: "AI chats", color: CHART.teal },
                  { key: "resources", name: "Resources", color: CHART.blue },
                  { key: "counselor", name: "Counselor", color: CHART.amber },
                ]}
                height={220}
              />
            </div>
          </Card>
        </motion.div>

        <motion.div variants={staggerItem}>
          <Card className="h-full p-6">
            <CardHeader title="Resource engagement" subtitle="Times completed" />
            {resourceData.length ? (
              <div className="mt-3">
                <BarsChart label="Resources completed" data={resourceData} xKey="name" horizontal series={[{ key: "sessions", name: "Completed", color: CHART.teal }]} height={220} />
              </div>
            ) : (
              <div className="mt-4">
                <EmptyState icon={Sparkles} title="No resources yet" body="Try a 2-minute exercise." action={<Button href="/resources" size="sm">Browse</Button>} />
              </div>
            )}
          </Card>
        </motion.div>

        <motion.div variants={staggerItem}>
          <Card className="h-full p-6">
            <CardHeader title="What’s been on your mind" subtitle="Themes from your check-ins (30d)" />
            {themes.length ? (
              <ul className="mt-4 space-y-3">
                {themes.map(([f, n]) => {
                  const max = themes[0][1];
                  return (
                    <li key={f}>
                      <div className="flex justify-between text-sm">
                        <span>{FACTORS.find((x) => x.value === f)?.label}</span>
                        <span className="tabular-nums text-ink-muted">{n}×</span>
                      </div>
                      <div className="mt-1 h-2 overflow-hidden rounded-full bg-slate-100">
                        <motion.div className="h-full rounded-full bg-sea-500" initial={{ width: 0 }} animate={{ width: `${(n / max) * 100}%` }} transition={{ duration: 0.8 }} />
                      </div>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p className="mt-4 text-sm text-ink-muted">Themes appear when you add what’s affecting you in a check-in.</p>
            )}
          </Card>
        </motion.div>

        <motion.div variants={staggerItem} className="lg:col-span-3">
          <Card className="p-6">
            <CardHeader icon={Lightbulb} title="What has helped you recently?" subtitle="Based on resources you marked as helpful and how your check-ins changed afterwards" />
            <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {(isDemo
                ? [
                    { t: "2-Minute Breathing", b: "You found this helpful 8 of 9 times. Evenings after using it tended to have lower stress ratings.", icon: ThumbsUp },
                    { t: "Planning before exams", b: "The Exam Stress Reset came before your mood started lifting in the last two weeks.", icon: TrendingUp },
                    { t: "Talking to someone", b: "Your check-ins after your last counselor session were more settled. Keep that door open.", icon: Sparkles },
                  ]
                : [{ t: "Keep checking in", b: "After a week of check-ins, you’ll see which practices seem to help you most.", icon: Sparkles }]
              ).map((x) => (
                <div key={x.t} className="rounded-2xl border border-line bg-gradient-to-br from-white to-mist p-4">
                  <x.icon className="h-5 w-5 text-sea-600" aria-hidden />
                  <p className="mt-2 font-semibold">{x.t}</p>
                  <p className="mt-1 text-sm text-ink-muted">{x.b}</p>
                </div>
              ))}
            </div>
            <p className="mt-5 flex items-start gap-2 rounded-2xl bg-mist p-3 text-xs text-ink-muted">
              <Info className="mt-px h-3.5 w-3.5 shrink-0" aria-hidden />
              These observations describe patterns in your own entries and don’t imply cause and effect or any medical finding. If your mood has been low for more than two weeks, consider talking to a counselor.
            </p>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  );
}
