"use client";

import { Bookmark, SearchX, Search, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { ResourceCard, ResourcePlayer } from "@/components/app/resource-player";
import { Button, EmptyState, PageHeader, Skeleton } from "@/components/ui";
import { RESOURCES, RESOURCE_CATEGORIES } from "@/lib/data/resources";
import { useApp } from "@/lib/store";
import type { Resource, ResourceCategory } from "@/lib/types";
import { cn } from "@/lib/utils";

const DURATIONS = [
  { id: "any", label: "Any length" },
  { id: "short", label: "≤ 3 min" },
  { id: "mid", label: "4–6 min" },
  { id: "long", label: "7+ min" },
] as const;

export default function ResourcesPage() {
  const { savedResources, advanceDemo } = useApp();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<ResourceCategory | "All">("All");
  const [dur, setDur] = useState<(typeof DURATIONS)[number]["id"]>("any");
  const [savedOnly, setSavedOnly] = useState(false);
  const [playing, setPlaying] = useState<Resource | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 450);
    advanceDemo(4);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const results = useMemo(() => {
    const term = q.trim().toLowerCase();
    return RESOURCES.filter((r) => {
      if (cat !== "All" && r.category !== cat) return false;
      if (savedOnly && !savedResources.includes(r.id)) return false;
      if (dur === "short" && r.minutes > 3) return false;
      if (dur === "mid" && (r.minutes < 4 || r.minutes > 6)) return false;
      if (dur === "long" && r.minutes < 7) return false;
      if (term && !`${r.title} ${r.description} ${r.category}`.toLowerCase().includes(term)) return false;
      return true;
    });
  }, [q, cat, dur, savedOnly, savedResources]);

  const clear = () => {
    setQ("");
    setCat("All");
    setDur("any");
    setSavedOnly(false);
  };

  return (
    <div>
      <PageHeader eyebrow="Self-help library" title="Resources" subtitle="Short, practical exercises and guides. Most take less than five minutes." />

      <div className="card mb-6 p-4 sm:p-5">
        <div className="flex flex-col gap-3 md:flex-row">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-faint" aria-hidden />
            <label htmlFor="res-search" className="sr-only">
              Search resources
            </label>
            <input id="res-search" value={q} onChange={(e) => setQ(e.target.value)} className="input pl-10 pr-9" placeholder="Search e.g. “sleep”, “exam”, “breathing”" type="search" />
            {q && (
              <button onClick={() => setQ("")} className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-1 text-ink-faint hover:text-ink" aria-label="Clear search">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <div className="flex gap-2">
            <label htmlFor="res-dur" className="sr-only">
              Duration
            </label>
            <select id="res-dur" value={dur} onChange={(e) => setDur(e.target.value as typeof dur)} className="input w-auto pr-8">
              {DURATIONS.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.label}
                </option>
              ))}
            </select>
            <button onClick={() => setSavedOnly((s) => !s)} aria-pressed={savedOnly} className={cn("chip shrink-0 rounded-xl px-3.5", savedOnly && "chip-active")}>
              <Bookmark className="h-4 w-4" aria-hidden /> Saved
            </button>
          </div>
        </div>
        <div className="mt-4 flex gap-2 overflow-x-auto pb-1 [scrollbar-width:thin]" role="group" aria-label="Filter by category">
          {(["All", ...RESOURCE_CATEGORIES] as const).map((c) => (
            <button key={c} onClick={() => setCat(c)} aria-pressed={cat === c} className={cn("chip shrink-0", cat === c && "chip-active")}>
              {c}
            </button>
          ))}
        </div>
      </div>

      <p className="mb-3 text-sm text-ink-muted" aria-live="polite">
        {loading ? "Loading resources…" : `${results.length} resource${results.length === 1 ? "" : "s"}`}
      </p>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-48 rounded-2xl" />
          ))}
        </div>
      ) : results.length === 0 ? (
        <EmptyState
          icon={SearchX}
          title="No resources match those filters"
          body={savedOnly && savedResources.length === 0 ? "You haven’t saved any resources yet. Tap the bookmark on any card to save it." : "Try a different search term or clear the filters."}
          action={
            <Button variant="outline" size="sm" onClick={clear}>
              Clear filters
            </Button>
          }
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((r) => (
            <ResourceCard key={r.id} r={r} onStart={setPlaying} />
          ))}
        </div>
      )}
      <ResourcePlayer resource={playing} onClose={() => setPlaying(null)} />
    </div>
  );
}
