"use client";

import { motion } from "framer-motion";
import {
  ArrowRight, BookOpen, CalendarCheck, CalendarPlus, CheckCircle2, ClipboardCheck, EyeOff, Flame, Lock, MessageCircleHeart, ShieldCheck, TrendingUp, Video,
} from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { TrendChart, CHART } from "@/components/charts";
import { ResourceCard, ResourcePlayer } from "@/components/app/resource-player";
import { Badge, Button, Card, CardHeader, EmptyState } from "@/components/ui";
import { staggerItem } from "@/components/ui/motion";
import { MOODS, assessSupportTier, recommendResources } from "@/lib/assessment";
import { getCounselor } from "@/lib/data/counselors";
import { useApp } from "@/lib/store";
import type { MoodLevel, Resource } from "@/lib/types";
import { cn, formatDate, formatTime, toISODate, uid } from "@/lib/utils";
import { moodWord, streak, summary, topFactors, trendSeries } from "@/lib/wellness";

export default function DashboardPage() {
  const { checkIns, bookings, session, prefs, addCheckIn, toast } = useApp();
  const [range, setRange] = useState<7 | 30>(7);
  const [playing, setPlaying] = useState<Resource | null>(null);

  const todays = checkIns.filter((c) => toISODate(new Date(c.date)) === toISODate(new Date()));
  const latestToday = todays[todays.length - 1];
  const [picked, setPicked] = useState<MoodLevel | null>(null);
  const currentMood = picked ?? latestToday?.mood ?? null;

  const data = useMemo(() => trendSeries(checkIns, range), [checkIns, range]);
  const s = useMemo(() => summary(checkIns, 7), [checkIns]);
  const st = streak(checkIns);
  const factors = topFactors(checkIns.slice(-10)).map(([f]) => f);
  const recs = recommendResources(factors.length ? factors : ["general"], 3);
  const next = bookings
    .filter((b) => b.status === "confirmed" && b.date >= toISODate(new Date()))
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))[0];
  const counselor = next ? getCounselor(next.counselorId) : undefined;
  const anon = session?.mode === "anonymous" || prefs.anonymousMode;

  const quickLog = (m: MoodLevel) => {
    setPicked(m);
    const intensity = m <= 2 ? 3 : 2;
    addCheckIn({
      id: uid("ci"),
      date: new Date().toISOString(),
      mood: m,
      intensity,
      factors: [],
      feelsUnsafe: null,
      tier: assessSupportTier({ mood: m, intensity, feelsUnsafe: null, recent: checkIns }),
    });
    toast({ title: "Mood logged", body: "Add more detail anytime with a full check-in." });
  };

  return (
    <motion.div initial="hidden" animate="show" variants={{ hidden: {}, show: { transition: { staggerChildren: 0.06 } } }} className="grid gap-5 lg:grid-cols-3">
      {/* A. Today's check-in */}
      <motion.div variants={staggerItem} className="lg:col-span-2">
        <Card className="relative h-full overflow-hidden p-6">
          <div className="absolute -right-16 -top-20 h-56 w-56 rounded-full bg-gradient-to-br from-sea-100/70 to-calm-100/40 blur-2xl" aria-hidden />
          <div className="relative">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="eyebrow">Today’s check-in</p>
              {st > 0 && (
                <Badge tone="green" icon={Flame}>
                  {st}-day check-in streak
                </Badge>
              )}
            </div>
            <h2 className="mt-2 text-xl font-bold sm:text-2xl">How are you feeling today?</h2>
            <div className="mt-5 grid grid-cols-5 gap-2 sm:gap-3" role="radiogroup" aria-label="Today's mood">
              {MOODS.map((m) => (
                <button
                  key={m.value}
                  role="radio"
                  aria-checked={currentMood === m.value}
                  onClick={() => quickLog(m.value)}
                  className={cn(
                    "flex flex-col items-center gap-1.5 rounded-2xl border bg-white/80 py-3 text-xs font-medium transition hover:-translate-y-0.5 sm:py-4 sm:text-sm",
                    currentMood === m.value ? "border-sea-400 bg-sea-50 text-sea-800 shadow-glow" : "border-line text-ink-soft hover:border-sea-200",
                  )}
                >
                  <span className="text-2xl sm:text-3xl" aria-hidden>
                    {m.emoji}
                  </span>
                  {m.label}
                </button>
              ))}
            </div>
            <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm text-ink-muted">
                {currentMood ? (
                  <span className="inline-flex items-center gap-1.5 text-emerald-700">
                    <CheckCircle2 className="h-4 w-4" aria-hidden /> Logged for today. A full check-in gives you better suggestions.
                  </span>
                ) : (
                  "Tap to log in one second, or take the 2-minute check-in."
                )}
              </p>
              <Button href="/check-in" variant={currentMood ? "outline" : "primary"} size="sm" iconRight={ArrowRight}>
                Full check-in
              </Button>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* C. Quick support */}
      <motion.div variants={staggerItem}>
        <Card className="h-full p-6">
          <CardHeader title="Quick support" subtitle="Pick what feels right" />
          <div className="mt-4 space-y-2.5">
            {[
              { href: "/assistant", icon: MessageCircleHeart, t: "Talk to AI Assistant", s: "Private, any time", tint: "bg-sea-50 text-sea-700" },
              { href: "/resources", icon: BookOpen, t: "Find Resources", s: "2–10 minute exercises", tint: "bg-lav-50 text-[#4b3f8f]" },
              { href: "/counselor", icon: CalendarCheck, t: "Connect to Counselor", s: "Video, chat or in person", tint: "bg-calm-50 text-calm-700" },
            ].map((q) => (
              <Link key={q.href} href={q.href} className="group flex items-center gap-3 rounded-2xl border border-line p-3 transition hover:border-sea-200 hover:bg-sea-50/40">
                <span className={cn("grid h-10 w-10 place-items-center rounded-xl", q.tint)}>
                  <q.icon className="h-5 w-5" aria-hidden />
                </span>
                <span className="flex-1">
                  <span className="block text-sm font-semibold">{q.t}</span>
                  <span className="block text-xs text-ink-muted">{q.s}</span>
                </span>
                <ArrowRight className="h-4 w-4 text-ink-faint transition group-hover:translate-x-0.5 group-hover:text-sea-600" aria-hidden />
              </Link>
            ))}
          </div>
        </Card>
      </motion.div>

      {/* B. Wellness trend */}
      <motion.div variants={staggerItem} className="lg:col-span-2">
        <Card className="h-full p-6">
          <CardHeader
            icon={TrendingUp}
            title="Wellness trend"
            subtitle="Self-reported mood and stress · 1 (low) to 5 (high)"
            action={
              <div className="flex rounded-xl bg-slate-100 p-1" role="tablist" aria-label="Range">
                {([7, 30] as const).map((r) => (
                  <button key={r} role="tab" aria-selected={range === r} onClick={() => setRange(r)} className={cn("rounded-lg px-3 py-1 text-xs font-semibold transition", range === r ? "bg-white text-ink shadow-soft" : "text-ink-muted")}>
                    {r}d
                  </button>
                ))}
              </div>
            }
          />
          {checkIns.length === 0 ? (
            <div className="mt-5">
              <EmptyState icon={ClipboardCheck} title="Your trend will appear here" body="Log a few check-ins and you’ll start to see patterns in how you feel." action={<Button href="/check-in" size="sm">Start a check-in</Button>} />
            </div>
          ) : (
            <>
              <div className="mt-4 grid grid-cols-3 gap-3">
                {[
                  ["Avg. mood (7d)", moodWord(s.moodAvg), s.moodDelta],
                  ["Avg. stress (7d)", s.stressAvg ? s.stressAvg.toFixed(1) : "—", s.stressDelta !== null ? -s.stressDelta : null],
                  ["Check-in days", `${s.daysCheckedIn}/7`, null],
                ].map(([l, v, d]) => (
                  <div key={l as string} className="rounded-2xl bg-mist p-3">
                    <p className="text-xs text-ink-muted">{l as string}</p>
                    <p className="mt-0.5 text-lg font-bold">{v as string}</p>
                    {d !== null && d !== undefined && Math.abs(d as number) >= 0.1 && (
                      <p className={cn("text-[11px] font-medium", (d as number) > 0 ? "text-emerald-700" : "text-ink-muted")}>{(d as number) > 0 ? "Improving vs last week" : "Heavier than last week"}</p>
                    )}
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <TrendChart
                  label={`Mood and stress over the last ${range} days`}
                  data={data}
                  xKey="label"
                  yDomain={[1, 5]}
                  yTicks={[1, 2, 3, 4, 5]}
                  series={[
                    { key: "mood", name: "Mood", color: CHART.teal },
                    { key: "stress", name: "Stress", color: CHART.blue, dashed: true },
                  ]}
                  tooltipFmt={(v, n) => (n === "Mood" ? `${v} · ${MOODS.find((m) => m.value === v)?.label ?? ""}` : `${v} / 5`)}
                  height={220}
                />
              </div>
            </>
          )}
        </Card>
      </motion.div>

      {/* E. Upcoming session */}
      <motion.div variants={staggerItem}>
        <Card className="h-full p-6">
          <CardHeader icon={CalendarCheck} title="Upcoming session" />
          {next && counselor ? (
            <div className="mt-5">
              <div className="flex items-center gap-3">
                <span className={cn("grid h-12 w-12 place-items-center rounded-2xl text-sm font-bold", counselor.tint)}>{counselor.initials}</span>
                <div>
                  <p className="font-semibold">{counselor.name}</p>
                  <p className="text-sm text-ink-muted">{counselor.title}</p>
                </div>
              </div>
              <div className="mt-4 space-y-2 rounded-2xl bg-mist p-4 text-sm">
                <p className="flex justify-between"><span className="text-ink-muted">Date</span><span className="font-medium">{formatDate(next.date, { weekday: "long", day: "numeric", month: "short" })}</span></p>
                <p className="flex justify-between"><span className="text-ink-muted">Time</span><span className="font-medium">{formatTime(next.time)}</span></p>
                <p className="flex justify-between"><span className="text-ink-muted">Type</span><span className="inline-flex items-center gap-1 font-medium"><Video className="h-3.5 w-3.5" aria-hidden />{next.sessionType}</span></p>
              </div>
              <Button href="/counselor" variant="outline" size="sm" className="mt-4 w-full">
                Manage booking
              </Button>
            </div>
          ) : (
            <div className="mt-5">
              <EmptyState icon={CalendarPlus} title="No sessions booked" body="Talking to someone can help, even if things feel manageable." action={<Button href="/counselor" size="sm">Book a session</Button>} />
            </div>
          )}
        </Card>
      </motion.div>

      {/* D. Recommended */}
      <motion.div variants={staggerItem} className="lg:col-span-2">
        <Card className="h-full p-6">
          <CardHeader
            icon={BookOpen}
            title="Recommended for you"
            subtitle={factors.length ? `Based on what you’ve mentioned recently: ${factors.slice(0, 2).join(" & ")}` : "Short practices many students find helpful"}
            action={
              <Link href="/resources" className="hidden text-sm font-semibold text-sea-700 hover:underline sm:block">
                View all
              </Link>
            }
          />
          <div className="mt-5 grid gap-3 sm:grid-cols-3">
            {recs.map((r) => (
              <ResourceCard key={r.id} r={r} onStart={setPlaying} compact />
            ))}
          </div>
        </Card>
      </motion.div>

      {/* F. Privacy */}
      <motion.div variants={staggerItem}>
        <Card className="h-full bg-gradient-to-br from-white to-sea-50/50 p-6">
          <CardHeader icon={ShieldCheck} title="Your data is protected" subtitle="Privacy Center" />
          <ul className="mt-5 space-y-3 text-sm">
            <li className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-ink-soft"><CheckCircle2 className="h-4 w-4 text-emerald-600" aria-hidden /> Consent</span>
              <Badge tone="green">{session?.consent ? `Given · v${session.consent.version}` : "Pending"}</Badge>
            </li>
            <li className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-ink-soft"><EyeOff className="h-4 w-4 text-sea-600" aria-hidden /> Anonymous mode</span>
              <Badge tone={anon ? "sea" : "slate"}>{anon ? "On" : "Off"}</Badge>
            </li>
            <li className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-ink-soft"><Lock className="h-4 w-4 text-sea-600" aria-hidden /> Counselor sharing</span>
              <Badge tone="slate">{session?.consent?.shareWithCounselor ? "Opt-in" : "Off"}</Badge>
            </li>
          </ul>
          <Button href="/privacy" variant="outline" size="sm" className="mt-5 w-full">
            Manage data controls
          </Button>
        </Card>
      </motion.div>

      <ResourcePlayer resource={playing} onClose={() => setPlaying(null)} />
    </motion.div>
  );
}
