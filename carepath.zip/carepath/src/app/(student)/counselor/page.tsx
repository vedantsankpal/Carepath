"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft, CalendarCheck, CalendarX, Check, CheckCircle2, Clock, Globe2, Lock, MapPin, MessageSquare, PhoneCall, ShieldCheck, Video,
} from "lucide-react";
import { useSearchParams } from "next/navigation";
import { Suspense, useMemo, useState } from "react";
import { Badge, Button, Card, EmptyState, PageHeader } from "@/components/ui";
import { COUNSELORS, getCounselor } from "@/lib/data/counselors";
import { createBooking } from "@/lib/services/api";
import { useApp } from "@/lib/store";
import type { Booking, Counselor, SessionType } from "@/lib/types";
import { cn, formatDate, formatTime, toISODate } from "@/lib/utils";

const TYPE_ICON: Record<SessionType, typeof Video> = { Video: Video, "In person": MapPin, Chat: MessageSquare };

function CounselorInner() {
  const { bookings, cancelBooking, toast, session } = useApp();
  const params = useSearchParams();
  const urgent = params.get("urgent") === "1";
  const [filter, setFilter] = useState<SessionType | "All">("All");
  const [selected, setSelected] = useState<Counselor | null>(null);
  const [callbackSent, setCallbackSent] = useState(false);

  const list = COUNSELORS.filter((c) => filter === "All" || c.sessionTypes.includes(filter));
  const mine = bookings
    .filter((b) => b.status !== "cancelled" && b.date >= toISODate(new Date()))
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));

  return (
    <div>
      <PageHeader
        eyebrow="Counselor Connect"
        title="Connect with a Counselor"
        subtitle="Trained campus counselors — by video, chat or in person. You decide what you share."
      />

      {urgent && (
        <Card className="mb-6 border-rose-200 bg-rose-50/50 p-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <PhoneCall className="h-6 w-6 shrink-0 text-rose-700" aria-hidden />
            <div className="flex-1">
              <p className="font-semibold">Request an urgent callback</p>
              <p className="text-sm text-ink-soft">The on-duty counselor will be alerted to call you back as soon as possible during service hours. If you are in danger right now, call 112.</p>
            </div>
            <Button
              variant="danger"
              disabled={callbackSent}
              onClick={() => {
                setCallbackSent(true);
                toast({ title: "Callback requested", body: "The on-duty counselor has been notified (demo).", tone: "info" });
              }}
            >
              {callbackSent ? "Requested" : "Request callback"}
            </Button>
          </div>
        </Card>
      )}

      <AnimatePresence mode="wait">
        {selected ? (
          <motion.div key="flow" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <BookingFlow counselor={selected} onBack={() => setSelected(null)} shareDefault={!!session?.consent?.shareWithCounselor} />
          </motion.div>
        ) : (
          <motion.div key="list" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
            <div>
              <div className="mb-4 flex flex-wrap gap-2" role="group" aria-label="Session type">
                {(["All", "Video", "In person", "Chat"] as const).map((t) => (
                  <button key={t} onClick={() => setFilter(t)} aria-pressed={filter === t} className={cn("chip", filter === t && "chip-active")}>
                    {t}
                  </button>
                ))}
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                {list.map((c) => (
                  <Card key={c.id} as="article" className="flex flex-col p-5 transition hover:shadow-lift">
                    <div className="flex items-start gap-3">
                      <span className={cn("grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-sm font-bold", c.tint)} aria-hidden>
                        {c.initials}
                      </span>
                      <div className="min-w-0">
                        <h3 className="font-semibold">{c.name}</h3>
                        <p className="text-sm text-ink-muted">{c.title}</p>
                      </div>
                      <Badge tone="green" className="ml-auto shrink-0">
                        {c.nextAvailable}
                      </Badge>
                    </div>
                    <p className="mt-3 flex-1 text-sm text-ink-soft">{c.bio}</p>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {c.specializations.map((s) => (
                        <Badge key={s} tone="sea">
                          {s}
                        </Badge>
                      ))}
                    </div>
                    <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-ink-muted">
                      <span className="inline-flex items-center gap-1">
                        <Globe2 className="h-3.5 w-3.5" aria-hidden /> {c.languages.join(", ")}
                      </span>
                      <span className="inline-flex items-center gap-2">
                        {c.sessionTypes.map((t) => {
                          const I = TYPE_ICON[t];
                          return (
                            <span key={t} className="inline-flex items-center gap-1">
                              <I className="h-3.5 w-3.5" aria-hidden /> {t}
                            </span>
                          );
                        })}
                      </span>
                    </div>
                    <Button className="mt-4 w-full" icon={CalendarCheck} onClick={() => setSelected(c)}>
                      Book Session
                    </Button>
                  </Card>
                ))}
              </div>
            </div>

            <aside className="space-y-4">
              <Card className="p-5">
                <p className="font-semibold">Your sessions</p>
                {mine.length === 0 ? (
                  <div className="mt-3">
                    <EmptyState icon={CalendarX} title="No upcoming sessions" body="Book a time that works for you." />
                  </div>
                ) : (
                  <ul className="mt-3 space-y-3">
                    {mine.map((b) => {
                      const c = getCounselor(b.counselorId)!;
                      return (
                        <li key={b.id} className="rounded-2xl border border-line p-3.5">
                          <p className="text-sm font-semibold">{c.name}</p>
                          <p className="mt-0.5 text-xs text-ink-muted">
                            {formatDate(b.date)} · {formatTime(b.time)} · {b.sessionType}
                          </p>
                          <div className="mt-2 flex items-center justify-between">
                            <Badge tone="green" icon={Check}>
                              Confirmed
                            </Badge>
                            <button
                              className="text-xs font-medium text-ink-muted hover:text-rose-700"
                              onClick={() => {
                                cancelBooking(b.id);
                                toast({ title: "Session cancelled", body: "The slot has been released.", tone: "info" });
                              }}
                            >
                              Cancel
                            </button>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </Card>
              <Card className="bg-gradient-to-br from-white to-sea-50/60 p-5">
                <ShieldCheck className="h-5 w-5 text-sea-600" aria-hidden />
                <p className="mt-2 text-sm font-semibold">What counselors see</p>
                <p className="mt-1 text-sm text-ink-muted">Only your booking details — and a short check-in summary if you choose to share it. Never your AI chats.</p>
              </Card>
            </aside>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function BookingFlow({ counselor, onBack, shareDefault }: { counselor: Counselor; onBack: () => void; shareDefault: boolean }) {
  const { addBooking, advanceDemo, toast } = useApp();
  const dates = useMemo(() => Object.keys(counselor.availability).sort().slice(0, 10), [counselor]);
  const [date, setDate] = useState<string | null>(null);
  const [time, setTime] = useState<string | null>(null);
  const [type, setType] = useState<SessionType>(counselor.sessionTypes[0]);
  const [share, setShare] = useState(shareDefault);
  const [reason, setReason] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<Booking | null>(null);
  const step = done ? 4 : !date ? 1 : !time ? 2 : 3;

  const confirm = async () => {
    if (!date || !time) return;
    setLoading(true);
    setError(null);
    try {
      const b = await createBooking({ counselorId: counselor.id, date, time, sessionType: type, shareCheckInContext: share, reason: reason || undefined });
      addBooking(b);
      setDone(b);
      advanceDemo(8);
      toast({ title: "Session confirmed", body: `${counselor.name} · ${formatDate(date)} at ${formatTime(time)}` });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not book this slot.");
    } finally {
      setLoading(false);
    }
  };

  if (done) {
    const I = TYPE_ICON[done.sessionType];
    return (
      <Card className="mx-auto max-w-lg overflow-hidden text-center">
        <div className="bg-gradient-to-br from-sea-50 to-calm-50 px-6 py-8">
          <motion.span initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 260, damping: 18 }} className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-sea-600 text-white shadow-lift">
            <CheckCircle2 className="h-8 w-8" aria-hidden />
          </motion.span>
          <h2 className="mt-4 text-xl font-bold">Your session is confirmed</h2>
          <p className="mt-1 text-sm text-ink-muted">Reaching out takes courage. We’ll send you a reminder.</p>
        </div>
        <div className="space-y-3 p-6 text-left text-sm">
          <Row label="Counselor" value={counselor.name} />
          <Row label="Date" value={formatDate(done.date, { weekday: "long", day: "numeric", month: "long" })} />
          <Row label="Time" value={formatTime(done.time)} />
          <Row label="Session" value={<span className="inline-flex items-center gap-1"><I className="h-3.5 w-3.5" aria-hidden />{done.sessionType}</span>} />
          <Row label="Check-in context" value={done.shareCheckInContext ? "Shared (summary only)" : "Not shared"} />
          <div className="flex flex-col gap-2 pt-3 sm:flex-row">
            <Button variant="outline" className="flex-1" onClick={onBack}>
              Back to counselors
            </Button>
            <Button className="flex-1" href="/wellness" onClick={() => advanceDemo(8)}>
              View my wellness
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
      <Card className="min-w-0 p-5 sm:p-7">
        <button onClick={onBack} className="mb-5 inline-flex items-center gap-1 text-sm font-medium text-ink-muted hover:text-ink">
          <ArrowLeft className="h-4 w-4" aria-hidden /> All counselors
        </button>
        <ol className="mb-6 flex items-center gap-2 text-xs font-semibold" aria-label="Booking steps">
          {["Counselor", "Date", "Time", "Confirm"].map((s, i) => (
            <li key={s} className="flex items-center gap-2">
              <span className={cn("grid h-6 w-6 place-items-center rounded-full", i < step ? "bg-sea-600 text-white" : i === step ? "bg-sea-50 text-sea-800 ring-2 ring-sea-500" : "bg-slate-100 text-ink-muted")}>
                {i < step ? <Check className="h-3.5 w-3.5" /> : i + 1}
              </span>
              <span className={cn("hidden sm:inline", i <= step ? "text-ink" : "text-ink-muted")}>{s}</span>
              {i < 3 && <span className="h-px w-4 bg-line sm:w-8" aria-hidden />}
            </li>
          ))}
        </ol>

        <h2 className="font-semibold">Select a date</h2>
        <div className="-mx-1 mt-3 flex gap-2 overflow-x-auto px-1 pb-2" role="radiogroup" aria-label="Date">
          {dates.map((d) => {
            const dt = new Date(`${d}T00:00:00`);
            return (
              <button
                key={d}
                role="radio"
                aria-checked={date === d}
                onClick={() => {
                  setDate(d);
                  setTime(null);
                  advanceDemo(7);
                }}
                className={cn("flex w-[68px] shrink-0 flex-col items-center rounded-2xl border py-3 transition", date === d ? "border-sea-500 bg-sea-50 shadow-glow" : "border-line hover:border-sea-200")}
              >
                <span className="text-[11px] font-medium uppercase text-ink-muted">{dt.toLocaleDateString("en-IN", { weekday: "short" })}</span>
                <span className="text-xl font-bold">{dt.getDate()}</span>
                <span className="text-[11px] text-ink-muted">{dt.toLocaleDateString("en-IN", { month: "short" })}</span>
              </button>
            );
          })}
        </div>

        <h2 className="mt-6 font-semibold">Select a time</h2>
        {!date ? (
          <p className="mt-2 text-sm text-ink-muted">Choose a date to see available times.</p>
        ) : (
          <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-4" role="radiogroup" aria-label="Time">
            {counselor.availability[date].map((t) => (
              <button key={t} role="radio" aria-checked={time === t} onClick={() => setTime(t)} className={cn("rounded-xl border py-2.5 text-sm font-medium transition", time === t ? "border-sea-500 bg-sea-600 text-white" : "border-line hover:border-sea-300")}>
                {formatTime(t)}
              </button>
            ))}
          </div>
        )}

        <h2 className="mt-6 font-semibold">Session type</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {counselor.sessionTypes.map((t) => {
            const I = TYPE_ICON[t];
            return (
              <button key={t} onClick={() => setType(t)} aria-pressed={type === t} className={cn("chip", type === t && "chip-active")}>
                <I className="h-4 w-4" aria-hidden /> {t}
              </button>
            );
          })}
        </div>

        <label htmlFor="reason" className="label mt-6">
          What would you like to talk about? <span className="font-normal text-ink-muted">(optional)</span>
        </label>
        <textarea id="reason" rows={2} value={reason} maxLength={500} onChange={(e) => setReason(e.target.value)} className="input resize-none" placeholder="A few words is plenty — or leave blank." />

        <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-2xl border border-line p-4">
          <input type="checkbox" checked={share} onChange={(e) => setShare(e.target.checked)} className="mt-0.5 h-4 w-4 accent-sea-600" />
          <span>
            <span className="block text-sm font-medium">Share my recent check-in summary</span>
            <span className="block text-xs text-ink-muted">Mood trend and themes only. Your chats and notes are never shared.</span>
          </span>
        </label>
      </Card>

      <aside>
        <Card className="sticky top-24 p-5">
          <div className="flex items-center gap-3">
            <span className={cn("grid h-12 w-12 place-items-center rounded-2xl text-sm font-bold", counselor.tint)}>{counselor.initials}</span>
            <div>
              <p className="font-semibold">{counselor.name}</p>
              <p className="text-sm text-ink-muted">{counselor.title}</p>
            </div>
          </div>
          <div className="mt-4 space-y-2.5 rounded-2xl bg-mist p-4 text-sm">
            <Row label="Date" value={date ? formatDate(date) : "—"} />
            <Row label="Time" value={time ? formatTime(time) : "—"} />
            <Row label="Type" value={type} />
            <Row label="Duration" value={<span className="inline-flex items-center gap-1"><Clock className="h-3.5 w-3.5" aria-hidden />45 min</span>} />
          </div>
          {error && (
            <p className="mt-3 rounded-xl bg-rose-50 p-3 text-sm text-rose-800" role="alert">
              {error}
            </p>
          )}
          <Button className="mt-4 w-full" size="lg" disabled={!date || !time} loading={loading} onClick={confirm}>
            Confirm Session
          </Button>
          <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-ink-muted">
            <Lock className="h-3 w-3" aria-hidden /> Free & confidential for enrolled students
          </p>
        </Card>
      </aside>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <p className="flex items-center justify-between gap-4">
      <span className="text-ink-muted">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </p>
  );
}

export default function CounselorPage() {
  return (
    <Suspense>
      <CounselorInner />
    </Suspense>
  );
}
