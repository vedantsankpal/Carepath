"use client";

import { motion } from "framer-motion";
import { Building2, CheckCircle2, EyeOff, HeartHandshake, Lightbulb, MessageSquare, Star } from "lucide-react";
import { useState, type FormEvent } from "react";
import { Button, Card, PageHeader, Switch } from "@/components/ui";
import { submitFeedback } from "@/lib/services/api";
import type { FeedbackKind } from "@/lib/types";
import { cn } from "@/lib/utils";

const KINDS: { id: FeedbackKind; label: string; icon: typeof Star; hint: string }[] = [
  { id: "feedback", label: "General feedback", icon: MessageSquare, hint: "How is CarePath working for you?" },
  { id: "campus", label: "Campus concern", icon: Building2, hint: "Something on campus affecting student wellbeing" },
  { id: "resource", label: "Resource suggestion", icon: Lightbulb, hint: "A topic or format you'd like to see" },
  { id: "counselor", label: "Counselor experience", icon: HeartHandshake, hint: "How did your session go?" },
];

export default function FeedbackPage() {
  const [kind, setKind] = useState<FeedbackKind>("feedback");
  const [message, setMessage] = useState("");
  const [rating, setRating] = useState(0);
  const [anonymous, setAnonymous] = useState(true);
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [error, setError] = useState("");

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (message.trim().length < 5) {
      setError("Please write at least a few words.");
      return;
    }
    setError("");
    setStatus("loading");
    try {
      await submitFeedback({ kind, message, rating: kind === "counselor" ? rating || undefined : undefined, anonymous });
      setStatus("done");
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Couldn’t send feedback. Please try again.");
    }
  };

  if (status === "done") {
    return (
      <Card className="mx-auto max-w-lg p-8 text-center">
        <motion.span initial={{ scale: 0.6 }} animate={{ scale: 1 }} className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-emerald-50 text-emerald-700">
          <CheckCircle2 className="h-7 w-7" aria-hidden />
        </motion.span>
        <h1 className="mt-4 text-xl font-bold">Thank you — your voice matters.</h1>
        <p className="mt-2 text-sm text-ink-muted">
          {anonymous ? "Your feedback was submitted anonymously. No name, email or device ID was attached." : "Your feedback was submitted."} It’s reviewed in aggregate by the student wellbeing team.
        </p>
        <Button
          className="mt-6"
          variant="outline"
          onClick={() => {
            setStatus("idle");
            setMessage("");
            setRating(0);
          }}
        >
          Send more feedback
        </Button>
      </Card>
    );
  }

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader eyebrow="Anonymous feedback" title="Help us improve student support." subtitle="Tell us what’s working, what isn’t, and what’s happening on campus." />
      <div className="mb-5 flex items-center gap-3 rounded-2xl bg-sea-50 p-4 text-sm text-sea-900 ring-1 ring-sea-100">
        <EyeOff className="h-5 w-5 shrink-0" aria-hidden />
        <p>
          <strong>You can submit feedback anonymously.</strong> Anonymous submissions are stored without any identifier linking them to you.
        </p>
      </div>
      <Card className="p-6 sm:p-8">
        <form onSubmit={submit} noValidate>
          <fieldset>
            <legend className="label">What kind of feedback?</legend>
            <div className="grid gap-2.5 sm:grid-cols-2">
              {KINDS.map((k) => (
                <button type="button" key={k.id} onClick={() => setKind(k.id)} aria-pressed={kind === k.id} className={cn("flex items-start gap-3 rounded-2xl border p-4 text-left transition", kind === k.id ? "border-sea-400 bg-sea-50/60 ring-2 ring-sea-500/10" : "border-line hover:bg-slate-50")}>
                  <k.icon className={cn("mt-0.5 h-5 w-5", kind === k.id ? "text-sea-700" : "text-ink-muted")} aria-hidden />
                  <span>
                    <span className="block text-sm font-semibold">{k.label}</span>
                    <span className="block text-xs text-ink-muted">{k.hint}</span>
                  </span>
                </button>
              ))}
            </div>
          </fieldset>

          {kind === "counselor" && (
            <fieldset className="mt-6">
              <legend className="label">How would you rate your session?</legend>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button type="button" key={n} onClick={() => setRating(n)} aria-label={`${n} star${n > 1 ? "s" : ""}`} aria-pressed={rating === n} className="rounded-lg p-1">
                    <Star className={cn("h-7 w-7 transition", n <= rating ? "fill-amber-400 text-amber-400" : "text-slate-300")} />
                  </button>
                ))}
              </div>
            </fieldset>
          )}

          <label htmlFor="fb-msg" className="label mt-6">
            Your message
          </label>
          <textarea
            id="fb-msg"
            rows={5}
            maxLength={2000}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            aria-invalid={!!error}
            aria-describedby="fb-help"
            className={cn("input resize-none", error && "border-rose-300")}
            placeholder="e.g. It would help to have counselor slots after 6 pm during exam weeks."
          />
          <div id="fb-help" className="mt-1.5 flex justify-between text-xs">
            <span className={error ? "font-medium text-rose-700" : "text-ink-muted"}>{error || "Please don’t include names of other students."}</span>
            <span className="tabular-nums text-ink-faint">{message.length}/2000</span>
          </div>

          <div className="mt-4 border-t border-line pt-2">
            <Switch id="fb-anon" checked={anonymous} onChange={setAnonymous} label="Submit anonymously" description="Recommended. Turn off only if you want the team to follow up with you." />
          </div>

          <div className="mt-4 flex justify-end">
            <Button type="submit" loading={status === "loading"}>
              Submit feedback
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
