"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, CalendarCheck, CheckCircle2, HeartHandshake, Info, LifeBuoy, Loader2, MessageCircleHeart, Phone, RotateCcw, ShieldCheck } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { ResourceCard, ResourcePlayer } from "@/components/app/resource-player";
import { Button, Card } from "@/components/ui";
import { FACTORS, INTENSITY_LABELS, MOODS, TIER_COPY } from "@/lib/assessment";
import { HELP_CONTACTS, PRINCIPLE } from "@/lib/config";
import { getResource } from "@/lib/data/resources";
import { submitCheckIn } from "@/lib/services/api";
import { useApp } from "@/lib/store";
import type { CheckIn, Intensity, MoodLevel, Resource, StressFactor, SupportTier } from "@/lib/types";
import { cn, uid } from "@/lib/utils";

const STEPS = ["Mood", "What's affecting you", "Intensity", "Your support"];

export default function CheckInPage() {
  const { checkIns, addCheckIn, advanceDemo } = useApp();
  const [step, setStep] = useState(0);
  const [mood, setMood] = useState<MoodLevel | null>(null);
  const [factors, setFactors] = useState<StressFactor[]>([]);
  const [intensity, setIntensity] = useState<Intensity | null>(null);
  const [unsafe, setUnsafe] = useState<CheckIn["feelsUnsafe"]>(null);
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ tier: SupportTier; resources: Resource[] } | null>(null);
  const [playing, setPlaying] = useState<Resource | null>(null);

  const canNext = step === 0 ? mood !== null : step === 1 ? factors.length > 0 : intensity !== null && unsafe !== null;

  const toggle = (f: StressFactor) => setFactors((prev) => (prev.includes(f) ? prev.filter((x) => x !== f) : [...prev, f]));

  const finish = async () => {
    if (!mood || !intensity) return;
    setStep(3);
    setLoading(true);
    advanceDemo(2);
    const r = await submitCheckIn({ mood, intensity, factors, feelsUnsafe: unsafe, recent: checkIns.slice(-5) });
    const ci: CheckIn = { id: uid("ci"), date: new Date().toISOString(), mood, intensity, factors, feelsUnsafe: unsafe, note: note || undefined, tier: r.tier };
    addCheckIn(ci);
    setResult({ tier: r.tier, resources: r.resources.map(getResource).filter(Boolean) as Resource[] });
    setLoading(false);
    advanceDemo(4);
  };

  const reset = () => {
    setStep(0);
    setMood(null);
    setFactors([]);
    setIntensity(null);
    setUnsafe(null);
    setNote("");
    setResult(null);
  };

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-6">
        <p className="eyebrow">2-minute check-in</p>
        <h1 className="mt-1.5 text-2xl font-bold sm:text-[28px]">Let’s see how you’re doing</h1>
        <p className="mt-1 text-sm text-ink-muted">There are no right answers. This helps suggest support — it isn’t a test or a diagnosis.</p>
      </div>

      {/* Progress */}
      <ol className="mb-6 grid grid-cols-4 gap-2" aria-label="Check-in progress">
        {STEPS.map((s, i) => (
          <li key={s} aria-current={i === step ? "step" : undefined}>
            <div className="h-1.5 overflow-hidden rounded-full bg-slate-200">
              <motion.div className="h-full rounded-full bg-sea-500" initial={false} animate={{ width: i < step || (i === 3 && result) ? "100%" : i === step ? "50%" : "0%" }} transition={{ duration: 0.5 }} />
            </div>
            <p className={cn("mt-1.5 hidden text-xs sm:block", i === step ? "font-semibold text-ink" : "text-ink-muted")}>{s}</p>
          </li>
        ))}
      </ol>

      <Card className="overflow-hidden p-6 sm:p-8">
        <AnimatePresence mode="wait">
          <motion.div key={step + (result ? "r" : "")} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.25 }}>
            {step === 0 && (
              <fieldset>
                <legend className="text-xl font-semibold">How are you feeling today?</legend>
                <div className="mt-6 grid grid-cols-5 gap-2 sm:gap-3">
                  {MOODS.map((m) => (
                    <button
                      key={m.value}
                      type="button"
                      onClick={() => setMood(m.value)}
                      aria-pressed={mood === m.value}
                      className={cn(
                        "flex flex-col items-center gap-2 rounded-2xl border py-4 text-xs font-medium transition hover:-translate-y-0.5 sm:text-sm",
                        mood === m.value ? "border-sea-400 bg-sea-50 text-sea-800 shadow-glow" : "border-line text-ink-soft hover:border-sea-200",
                      )}
                    >
                      <span className="text-3xl sm:text-4xl" aria-hidden>
                        {m.emoji}
                      </span>
                      {m.label}
                    </button>
                  ))}
                </div>
              </fieldset>
            )}

            {step === 1 && (
              <fieldset>
                <legend className="text-xl font-semibold">What is affecting you most?</legend>
                <p className="mt-1 text-sm text-ink-muted">Choose any that apply.</p>
                <div className="mt-6 flex flex-wrap gap-2.5">
                  {FACTORS.map((f) => (
                    <button key={f.value} type="button" onClick={() => toggle(f.value)} aria-pressed={factors.includes(f.value)} className={cn("chip px-4 py-2", factors.includes(f.value) && "chip-active")}>
                      {factors.includes(f.value) && <CheckCircle2 className="h-4 w-4" aria-hidden />}
                      {f.label}
                    </button>
                  ))}
                </div>
                <label htmlFor="note" className="label mt-6">
                  Anything you’d like to add? <span className="font-normal text-ink-muted">(optional, private)</span>
                </label>
                <textarea id="note" value={note} onChange={(e) => setNote(e.target.value)} rows={2} maxLength={300} className="input resize-none" placeholder="e.g. two exams on the same day next week" />
              </fieldset>
            )}

            {step === 2 && (
              <div>
                <fieldset>
                  <legend className="text-xl font-semibold">How intense does the stress feel?</legend>
                  <div className="mt-6 grid grid-cols-5 gap-2" role="radiogroup" aria-label="Stress intensity">
                    {([1, 2, 3, 4, 5] as Intensity[]).map((v) => (
                      <button
                        key={v}
                        type="button"
                        role="radio"
                        aria-checked={intensity === v}
                        onClick={() => setIntensity(v)}
                        className={cn("group flex flex-col items-center gap-2 rounded-2xl border p-3 transition", intensity === v ? "border-sea-400 bg-sea-50 shadow-glow" : "border-line hover:border-sea-200")}
                      >
                        <span className="flex h-12 items-end gap-0.5" aria-hidden>
                          {[1, 2, 3, 4, 5].map((b) => (
                            <span
                              key={b}
                              className={cn("w-1.5 rounded-full transition-colors", b <= v ? (v >= 4 ? "bg-calm-500" : "bg-sea-500") : "bg-slate-200")}
                              style={{ height: `${b * 18 + 10}%` }}
                            />
                          ))}
                        </span>
                        <span className="text-lg font-bold tabular-nums">{v}</span>
                        <span className="text-center text-[11px] leading-tight text-ink-muted">{INTENSITY_LABELS[v]}</span>
                      </button>
                    ))}
                  </div>
                </fieldset>
                <fieldset className="mt-8 rounded-2xl border border-line bg-mist p-4 sm:p-5">
                  <legend className="sr-only">Safety question</legend>
                  <p className="text-sm font-semibold">Are you having thoughts of harming yourself, or feeling unsafe right now?</p>
                  <p className="mt-0.5 text-xs text-ink-muted">We ask everyone this. Your answer helps us show the right support.</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {([
                      ["no", "No"],
                      ["unsure", "I’m not sure"],
                      ["yes", "Yes"],
                    ] as const).map(([v, l]) => (
                      <button key={v} type="button" aria-pressed={unsafe === v} onClick={() => setUnsafe(v)} className={cn("chip", unsafe === v && "chip-active")}>
                        {l}
                      </button>
                    ))}
                  </div>
                </fieldset>
              </div>
            )}

            {step === 3 && loading && (
              <div className="flex flex-col items-center py-12 text-center" role="status">
                <div className="relative grid h-20 w-20 place-items-center">
                  <span className="absolute inset-0 animate-ping rounded-full bg-sea-200/60" />
                  <span className="relative grid h-14 w-14 place-items-center rounded-full bg-sea-600 text-white">
                    <Loader2 className="h-6 w-6 animate-spin" aria-hidden />
                  </span>
                </div>
                <p className="mt-6 font-semibold">Finding the right support for you…</p>
                <p className="mt-1 text-sm text-ink-muted">Matching resources to what you shared</p>
              </div>
            )}

            {step === 3 && !loading && result && <Result tier={result.tier} resources={result.resources} onPlay={setPlaying} onReset={reset} />}
          </motion.div>
        </AnimatePresence>

        {step < 3 && (
          <div className="mt-8 flex items-center justify-between border-t border-line pt-5">
            <Button variant="ghost" icon={ArrowLeft} onClick={() => setStep((s) => s - 1)} disabled={step === 0}>
              Back
            </Button>
            <Button iconRight={ArrowRight} disabled={!canNext} onClick={() => (step === 2 ? finish() : setStep((s) => s + 1))}>
              {step === 2 ? "See my support" : "Continue"}
            </Button>
          </div>
        )}
      </Card>

      <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-xs text-ink-muted">
        <ShieldCheck className="h-3.5 w-3.5 text-sea-600" aria-hidden /> {PRINCIPLE}
      </p>
      <ResourcePlayer resource={playing} onClose={() => setPlaying(null)} />
    </div>
  );
}

function Result({ tier, resources, onPlay, onReset }: { tier: SupportTier; resources: Resource[]; onPlay: (r: Resource) => void; onReset: () => void }) {
  const copy = TIER_COPY[tier];
  const { advanceDemo } = useApp();
  const tone = {
    sea: "from-sea-50 to-white ring-sea-100 text-sea-800",
    calm: "from-calm-50 to-white ring-calm-100 text-calm-800",
    amber: "from-amber-50 to-white ring-amber-200 text-amber-900",
    rose: "from-rose-50 to-white ring-rose-200 text-rose-800",
  }[copy.tone];
  const Icon = tier === "immediate" ? LifeBuoy : tier === "concerning" ? HeartHandshake : CheckCircle2;

  return (
    <div>
      <div className={cn("rounded-2xl bg-gradient-to-br p-5 ring-1", tone)}>
        <Icon className="h-6 w-6" aria-hidden />
        <h2 className="mt-3 text-xl font-bold text-ink">{copy.title}</h2>
        <p className="mt-1.5 text-[15px] text-ink-soft">{copy.body}</p>
      </div>

      {tier === "immediate" && (
        <div className="mt-5 space-y-2.5">
          {HELP_CONTACTS.map((c) => (
            <a key={c.id} href={`tel:${c.phone}`} className="flex items-center gap-4 rounded-2xl border border-line p-4 transition hover:border-rose-200 hover:bg-rose-50/40">
              <span className={cn("grid h-10 w-10 place-items-center rounded-xl", c.kind === "emergency" ? "bg-rose-600 text-white" : "bg-rose-50 text-rose-700")}>
                <Phone className="h-4 w-4" aria-hidden />
              </span>
              <span className="flex-1">
                <span className="block font-semibold">{c.name}</span>
                <span className="block text-xs text-ink-muted">
                  {c.description} · {c.hours}
                </span>
              </span>
              <span className="text-sm font-bold tabular-nums">{c.phone}</span>
            </a>
          ))}
          <p className="text-xs text-ink-muted">If you’re in immediate danger, call 112 now. Stay with someone you trust if you can.</p>
          <div className="flex flex-col gap-2 pt-2 sm:flex-row">
            <Button href="/safety" variant="danger" icon={LifeBuoy} className="flex-1">
              Open safety support
            </Button>
            <Button href="/counselor?urgent=1" variant="outline" className="flex-1">
              Request urgent counselor callback
            </Button>
          </div>
        </div>
      )}

      {tier === "concerning" && (
        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <Button href="/counselor" icon={CalendarCheck} className="flex-1" onClick={() => advanceDemo(6)}>
            Book a counselor session
          </Button>
          <Button href="/assistant" variant="outline" icon={MessageCircleHeart} className="flex-1">
            Talk it through first
          </Button>
        </div>
      )}

      {tier !== "immediate" && (
        <>
          <p className="mt-6 text-sm font-semibold">Suggested for you</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-3">
            {resources.map((r) => (
              <ResourceCard key={r.id} r={r} onStart={onPlay} compact />
            ))}
          </div>
        </>
      )}

      {(tier === "low" || tier === "moderate") && (
        <div className="mt-5 rounded-2xl bg-mist p-4 text-sm text-ink-soft">
          <Info className="mr-1.5 inline h-4 w-4 text-sea-600" aria-hidden />
          Want to talk it through? The{" "}
          <Link href="/assistant" className="font-semibold text-sea-700 hover:underline">
            AI assistant
          </Link>{" "}
          is here any time, and{" "}
          <Link href="/counselor" className="font-semibold text-sea-700 hover:underline">
            counselors
          </Link>{" "}
          are always an option.
        </div>
      )}

      <div className="mt-6 flex justify-between border-t border-line pt-5">
        <Button variant="ghost" icon={RotateCcw} onClick={onReset}>
          New check-in
        </Button>
        <Button variant="outline" href="/wellness">
          View my trends
        </Button>
      </div>
    </div>
  );
}
