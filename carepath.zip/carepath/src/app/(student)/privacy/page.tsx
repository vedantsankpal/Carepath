"use client";

import { Download, EyeOff, Fingerprint, KeyRound, Lock, Minimize2, ShieldCheck, Trash2, Users } from "lucide-react";
import { useState } from "react";
import { Badge, Button, Card, CardHeader, PageHeader, Switch } from "@/components/ui";
import { Modal } from "@/components/ui/modal";
import { useApp } from "@/lib/store";
import { formatDate } from "@/lib/utils";

const PRINCIPLES = [
  { icon: Fingerprint, t: "Consent-driven", b: "Nothing optional is collected or shared without your explicit opt-in." },
  { icon: Minimize2, t: "Minimal data", b: "We only store what powers your own experience. No contacts, location or device fingerprinting." },
  { icon: Lock, t: "Encryption", b: "TLS in transit and AES-256 at rest in production deployments." },
  { icon: KeyRound, t: "Role-based access", b: "Counselors see only consented summaries. Administrators see aggregates only." },
  { icon: EyeOff, t: "Anonymous mode", b: "Use CarePath with no name or email. Data stays on your device." },
  { icon: Users, t: "Aggregates only", b: "Campus insights suppress any group smaller than 10 students." },
];

const ACCESS = [
  { who: "You", what: "Everything you enter", tone: "green" as const },
  { who: "Your counselor", what: "Booking + check-in summary (only if you opt in)", tone: "sea" as const },
  { who: "University admin", what: "Anonymous, aggregated trends only", tone: "calm" as const },
  { who: "AI assistant", what: "Current conversation only — not used for training", tone: "lav" as const },
];

export default function PrivacyPage() {
  const { session, prefs, updatePrefs, updateConsent, checkIns, bookings, chat, deleteAllData, toast } = useApp();
  const [confirm, setConfirm] = useState(false);
  const c = session?.consent;

  const exportData = () => {
    const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), profile: { mode: session?.mode, displayName: session?.displayName }, consent: c, checkIns, bookings, chat }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "carepath-my-data.json";
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Export ready", body: "Your data was downloaded as JSON." });
  };

  return (
    <div>
      <PageHeader eyebrow="Privacy Center" title="Your data is protected" subtitle="See exactly what’s stored, who can see it, and change your choices at any time." />

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="bg-gradient-to-br from-sea-600 to-calm-700 p-6 text-white lg:col-span-1">
          <ShieldCheck className="h-8 w-8" aria-hidden />
          <p className="mt-4 text-xl font-bold">Privacy-first by design</p>
          <p className="mt-2 text-sm text-white/80">CarePath is a support tool, not a surveillance tool. You stay in control.</p>
          <div className="mt-6 space-y-2 text-sm">
            <p className="flex justify-between"><span className="text-white/75">Consent version</span><span className="font-semibold">{c?.version ?? "—"}</span></p>
            <p className="flex justify-between"><span className="text-white/75">Given on</span><span className="font-semibold">{c ? formatDate(c.acceptedAt, { day: "numeric", month: "short", year: "numeric" }) : "—"}</span></p>
            <p className="flex justify-between"><span className="text-white/75">Mode</span><span className="font-semibold">{session?.mode === "anonymous" || prefs.anonymousMode ? "Anonymous" : "Account"}</span></p>
          </div>
        </Card>

        <Card className="p-6 lg:col-span-2">
          <CardHeader title="Your choices" subtitle="Changes apply immediately" />
          <div className="mt-2 divide-y divide-line">
            <Switch id="p-anon" checked={prefs.anonymousMode || session?.mode === "anonymous"} onChange={(v) => updatePrefs({ anonymousMode: v })} label="Anonymous mode" description="Hide your name across the app and from counselors until you choose to share it." />
            <Switch id="p-share" checked={!!c?.shareWithCounselor} onChange={(v) => updateConsent({ shareWithCounselor: v })} label="Share check-in summary with counselors" description="Only when you book a session. You can override this per booking." />
            <Switch id="p-agg" checked={!!c?.anonymousAnalytics} onChange={(v) => updateConsent({ anonymousAnalytics: v })} label="Contribute to anonymous campus trends" description="Helps your university plan support. Never individually identifiable." />
            <div className="flex items-center justify-between py-3">
              <span>
                <span className="block text-sm font-medium">AI is not a replacement for professional care</span>
                <span className="block text-sm text-ink-muted">Required acknowledgement</span>
              </span>
              <Badge tone="green">Acknowledged</Badge>
            </div>
          </div>
        </Card>

        <Card className="p-6 lg:col-span-2">
          <CardHeader title="Privacy principles" />
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {PRINCIPLES.map((p) => (
              <div key={p.t} className="flex gap-3 rounded-2xl border border-line p-4">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-sea-50 text-sea-700">
                  <p.icon className="h-4 w-4" aria-hidden />
                </span>
                <span>
                  <span className="block text-sm font-semibold">{p.t}</span>
                  <span className="block text-sm text-ink-muted">{p.b}</span>
                </span>
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-5">
          <Card className="p-6">
            <CardHeader title="Who can see what" />
            <ul className="mt-4 space-y-3">
              {ACCESS.map((a) => (
                <li key={a.who}>
                  <Badge tone={a.tone}>{a.who}</Badge>
                  <p className="mt-1 text-sm text-ink-muted">{a.what}</p>
                </li>
              ))}
            </ul>
          </Card>
          <Card className="p-6">
            <CardHeader title="Data controls" subtitle={`${checkIns.length} check-ins · ${chat.length} messages · ${bookings.length} bookings`} />
            <div className="mt-4 space-y-2">
              <Button variant="outline" className="w-full" icon={Download} onClick={exportData}>
                Export my data
              </Button>
              <Button variant="ghost" className="w-full text-rose-700 hover:bg-rose-50 hover:text-rose-800" icon={Trash2} onClick={() => setConfirm(true)}>
                Delete all my data
              </Button>
            </div>
          </Card>
        </div>
      </div>

      <Modal open={confirm} onClose={() => setConfirm(false)} title="Delete all your data?" description="This permanently removes your check-ins, chats, bookings and saved resources from this device. This can’t be undone." size="sm">
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => setConfirm(false)} data-autofocus>
            Keep my data
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              deleteAllData();
              setConfirm(false);
              toast({ title: "Your data was deleted", tone: "info" });
            }}
          >
            Delete everything
          </Button>
        </div>
      </Modal>
    </div>
  );
}
