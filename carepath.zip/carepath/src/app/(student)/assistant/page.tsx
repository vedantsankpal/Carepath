"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  AlertCircle, ArrowUp, BookOpen, CalendarCheck, ClipboardCheck, Info, LifeBuoy, Phone, RotateCcw, ShieldCheck, Sparkles, Trash2,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import { ResourcePlayer } from "@/components/app/resource-player";
import { Button } from "@/components/ui";
import { DISCLAIMER, HELP_CONTACTS } from "@/lib/config";
import { getResource } from "@/lib/data/resources";
import { sendChat } from "@/lib/services/api";
import { useApp } from "@/lib/store";
import type { ChatMessage, ChatSuggestion, Resource } from "@/lib/types";
import { cn, uid } from "@/lib/utils";

const QUICK = [
  { label: "I'm feeling stressed", text: "I'm feeling stressed." },
  { label: "I'm feeling lonely", text: "I'm feeling lonely lately." },
  { label: "I can't focus", text: "I can't focus on anything." },
  { label: "Academic pressure", text: "The academic pressure is getting to me — exams and deadlines." },
  { label: "I want to talk to someone", text: "I want to talk to someone." },
];

const WELCOME: ChatMessage = {
  id: "welcome",
  role: "assistant",
  content:
    "Hi, I’m your CarePath wellness assistant. This is a private space to talk about whatever’s on your mind — stress, sleep, relationships, or anything else.\n\nI can listen, share practical ideas and help you find the right support. I’m not a therapist and I won’t diagnose anything, but I can connect you with a real counselor whenever you’d like.",
  createdAt: new Date(0).toISOString(),
};

function renderText(t: string) {
  return t.split("\n\n").map((p, i) => (
    <p key={i} className={i ? "mt-2.5" : ""}>
      {p.split(/(\*[^*]+\*)/g).map((seg, j) => (seg.startsWith("*") && seg.endsWith("*") ? <em key={j}>{seg.slice(1, -1)}</em> : seg))}
    </p>
  ));
}

export default function AssistantPage() {
  const { chat, setChat, advanceDemo } = useApp();
  const router = useRouter();
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [playing, setPlaying] = useState<Resource | null>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const messages = [WELCOME, ...chat];

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [chat.length, typing]);

  const send = async (text: string) => {
    const t = text.trim();
    if (!t || typing) return;
    setError(null);
    const userMsg: ChatMessage = { id: uid("m"), role: "user", content: t, createdAt: new Date().toISOString() };
    const history = [...chat, userMsg];
    setChat(() => history);
    setInput("");
    setTyping(true);
    advanceDemo(5);
    try {
      const reply = await sendChat(history.map((m) => ({ role: m.role, content: m.content })));
      setChat((prev) => [
        ...prev,
        { id: uid("m"), role: "assistant", content: reply.content, tier: reply.tier, suggestions: reply.suggestions, createdAt: new Date().toISOString() },
      ]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn’t reach the assistant.");
    } finally {
      setTyping(false);
      inputRef.current?.focus();
    }
  };

  const retry = () => {
    const lastUser = [...chat].reverse().find((m) => m.role === "user");
    if (!lastUser) return;
    setChat((prev) => prev.filter((m) => m.id !== lastUser.id));
    send(lastUser.content);
  };

  const onSuggestion = (s: ChatSuggestion) => {
    if (s.kind === "resource") {
      const r = getResource(s.resourceId);
      if (r) setPlaying(r);
    } else if (s.kind === "counselor") {
      advanceDemo(6);
      router.push("/counselor");
    } else if (s.kind === "safety") router.push("/safety");
    else router.push("/check-in");
  };

  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send(input);
    }
  };

  return (
    <div className="flex h-[calc(100dvh-64px-140px)] min-h-[520px] flex-col lg:h-[calc(100dvh-64px-64px)]">
      {/* Header */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-sea-400 to-calm-500 text-white shadow-soft">
            <Sparkles className="h-5 w-5" aria-hidden />
          </span>
          <div>
            <h1 className="text-xl font-bold">AI Wellness Assistant</h1>
            <p className="text-sm text-ink-muted">A supportive first step — not a diagnosis.</p>
          </div>
        </div>
        <div className="flex gap-2">
          {chat.length > 0 && (
            <Button variant="ghost" size="sm" icon={Trash2} onClick={() => setChat(() => [])} aria-label="Clear conversation">
              <span className="hidden sm:inline">Clear</span>
            </Button>
          )}
          <Button
            size="sm"
            icon={CalendarCheck}
            onClick={() => {
              advanceDemo(6);
              router.push("/counselor");
            }}
          >
            Connect with a Counselor
          </Button>
        </div>
      </div>

      {/* Conversation */}
      <div className="card flex min-h-0 flex-1 flex-col overflow-hidden">
        <div ref={listRef} className="flex-1 space-y-5 overflow-y-auto px-4 py-6 sm:px-8" aria-live="polite" aria-label="Conversation">
          {messages.map((m) => (
            <motion.div key={m.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={cn("flex gap-3", m.role === "user" && "justify-end")}>
              {m.role === "assistant" && (
                <span className="mt-1 grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-sea-400 to-calm-500 text-white" aria-hidden>
                  <Sparkles className="h-4 w-4" />
                </span>
              )}
              <div className={cn("max-w-[85%] sm:max-w-[72%]", m.role === "user" && "flex flex-col items-end")}>
                <div
                  className={cn(
                    "rounded-3xl px-4 py-3 text-[15px] leading-relaxed",
                    m.role === "user" ? "rounded-br-lg bg-sea-600 text-white" : "rounded-bl-lg bg-mist text-ink-soft ring-1 ring-line",
                    m.tier === "immediate" && "bg-rose-50/70 ring-rose-200",
                  )}
                >
                  <span className="sr-only">{m.role === "user" ? "You said:" : "Assistant said:"}</span>
                  {renderText(m.content)}
                </div>

                {m.tier === "immediate" && (
                  <div className="mt-3 rounded-2xl border border-rose-200 bg-white p-4">
                    <p className="flex items-center gap-2 text-sm font-semibold text-rose-800">
                      <LifeBuoy className="h-4 w-4" aria-hidden /> Reach a person now
                    </p>
                    <div className="mt-3 grid gap-2 sm:grid-cols-2">
                      {HELP_CONTACTS.slice(0, 2).map((c) => (
                        <a key={c.id} href={`tel:${c.phone}`} className="flex items-center gap-3 rounded-xl border border-line p-3 transition hover:bg-rose-50/50">
                          <Phone className="h-4 w-4 text-rose-700" aria-hidden />
                          <span>
                            <span className="block text-sm font-semibold">{c.phone}</span>
                            <span className="block text-xs text-ink-muted">{c.name}</span>
                          </span>
                        </a>
                      ))}
                    </div>
                    <Link href="/safety" className="mt-3 inline-block text-sm font-semibold text-rose-700 hover:underline">
                      See all support options →
                    </Link>
                  </div>
                )}

                {m.tier === "concerning" && (
                  <p className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-xs font-medium text-amber-900 ring-1 ring-amber-200">
                    <Info className="h-3.5 w-3.5" aria-hidden /> A counselor may be the best next step
                  </p>
                )}

                {m.suggestions && m.suggestions.length > 0 && (
                  <div className="mt-2.5 flex flex-wrap gap-2">
                    {m.suggestions.map((s, i) => {
                      const Icon = s.kind === "resource" ? BookOpen : s.kind === "counselor" ? CalendarCheck : s.kind === "safety" ? LifeBuoy : ClipboardCheck;
                      return (
                        <button
                          key={i}
                          onClick={() => onSuggestion(s)}
                          className={cn(
                            "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm font-medium transition",
                            s.kind === "safety" ? "border-rose-200 bg-rose-50 text-rose-800 hover:bg-rose-100" : s.kind === "counselor" ? "border-sea-300 bg-sea-50 text-sea-800 hover:bg-sea-100" : "border-line bg-white text-ink-soft hover:border-sea-200 hover:bg-sea-50/50",
                          )}
                        >
                          <Icon className="h-3.5 w-3.5" aria-hidden />
                          {s.label}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </motion.div>
          ))}

          <AnimatePresence>
            {typing && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex gap-3" aria-label="Assistant is typing">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-sea-400 to-calm-500 text-white" aria-hidden>
                  <Sparkles className="h-4 w-4" />
                </span>
                <div className="flex items-center gap-1.5 rounded-3xl rounded-bl-lg bg-mist px-4 py-4 ring-1 ring-line">
                  {[0, 1, 2].map((i) => (
                    <motion.span key={i} className="h-2 w-2 rounded-full bg-sea-400" animate={{ y: [0, -4, 0], opacity: [0.5, 1, 0.5] }} transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.15 }} />
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {error && (
            <div className="flex items-center gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900" role="alert">
              <AlertCircle className="h-4 w-4 shrink-0" aria-hidden />
              <span className="flex-1">{error}</span>
              <Button size="sm" variant="outline" icon={RotateCcw} onClick={retry}>
                Retry
              </Button>
            </div>
          )}
        </div>

        {/* Composer */}
        <div className="border-t border-line bg-white p-3 sm:p-4">
          {chat.length === 0 && (
            <div className="mb-3 flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none]">
              {QUICK.map((q) => (
                <button key={q.label} onClick={() => send(q.text)} className="chip shrink-0">
                  {q.label}
                </button>
              ))}
            </div>
          )}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
            className="flex items-end gap-2 rounded-2xl border border-line bg-mist p-2 transition focus-within:border-sea-300 focus-within:ring-4 focus-within:ring-sea-500/10"
          >
            <label htmlFor="chat-input" className="sr-only">
              Message the wellness assistant
            </label>
            <textarea
              id="chat-input"
              ref={inputRef}
              rows={1}
              value={input}
              maxLength={2000}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKey}
              placeholder="Share what’s on your mind…"
              className="max-h-32 min-h-[40px] flex-1 resize-none bg-transparent px-2 py-2 text-[15px] placeholder:text-ink-faint focus:outline-none"
            />
            <button type="submit" disabled={!input.trim() || typing} className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-sea-600 text-white transition hover:bg-sea-700 disabled:bg-slate-300" aria-label="Send message">
              <ArrowUp className="h-5 w-5" />
            </button>
          </form>
          <p className="mt-2 flex items-start gap-1.5 text-[11px] leading-snug text-ink-muted sm:items-center">
            <ShieldCheck className="mt-px h-3.5 w-3.5 shrink-0 text-sea-600 sm:mt-0" aria-hidden />
            {DISCLAIMER} In an emergency, call 112.
          </p>
        </div>
      </div>
      <ResourcePlayer resource={playing} onClose={() => setPlaying(null)} />
    </div>
  );
}
