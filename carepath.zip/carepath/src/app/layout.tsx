import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AppProvider } from "@/lib/store";
import { Toaster } from "@/components/ui/motion";
import { DemoGuide } from "@/components/app/demo-guide";

export const metadata: Metadata = {
  title: { default: "CarePath — Student Mental Health & Support", template: "%s · CarePath" },
  description: "Private, accessible and AI-assisted mental health support designed for students. Detect early. Support instantly. Connect when it matters.",
};

export const viewport: Viewport = { themeColor: "#f6f9fb", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:shadow-lift">
          Skip to content
        </a>
        <AppProvider>
          {children}
          <Toaster />
          <DemoGuide />
        </AppProvider>
      </body>
    </html>
  );
}
