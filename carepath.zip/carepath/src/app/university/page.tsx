"use client";

import { ArrowDownRight, ArrowRight, ArrowUpRight, BookOpen, CalendarCheck, ClipboardCheck, Download, MessagesSquare, ShieldCheck, TrendingUp } from "lucide-react";
import { BarsChart, CHART, TrendChart } from "@/components/charts";
import { StaffShell } from "@/components/shell/staff-shell";
import { Badge, Button, Card, CardHeader } from "@/components/ui";
import { AnimatedNumber, FadeIn } from "@/components/ui/motion";
import {
  CAMPUS_BY_YEAR, CAMPUS_CATEGORIES, CAMPUS_OVERVIEW as O, CAMPUS_RESOURCE_USAGE, CAMPUS_WEEKLY, FEEDBACK_THEMES, K_ANONYMITY_THRESHOLD,
} from "@/lib/data/institution";
import { cn } from "@/lib/utils";

export default function UniversityDashboard() {
  const kpis = [
    { l: "Total check-ins", v: O.checkIns, d: O.checkInsDelta, i: ClipboardCheck },
    { l: "Resource sessions", v: O.resourceSessions, d: O.resourceDelta, i: BookOpen },
    { l: "Counselor bookings", v: O.bookings, d: O.bookingsDelta, i: CalendarCheck },
    { l: "Anonymous feedback", v: O.feedback, d: O.feedbackDelta, i: MessagesSquare },
  ];
  const peak = CAMPUS_WEEKLY.reduce((m, w, i, a) => (w.checkIns > a[m].checkIns ? i : m), 0);

  return (
    <StaffShell role="admin">
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="eyebrow">University dashboard</p>
          <h1 className="mt-1 text-2xl font-bold sm:text-[28px]">Campus wellbeing overview</h1>
          <p className="mt-1 text-sm text-ink-muted">Last 8 weeks · Demo University · <Badge tone="lav">Sample data</Badge></p>
        </div>
        <Button variant="outline" size="sm" icon={Download} onClick={() => window.print()}>
          Export report
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {kpis.map((k, i) => (
          <FadeIn key={k.l} delay={i * 0.05}>
            <Card className="p-5">
              <div className="flex items-center justify-between">
                <k.i className="h-5 w-5 text-sea-600" aria-hidden />
                <span className={cn("inline-flex items-center gap-0.5 text-xs font-semibold", k.d >= 0 ? "text-emerald-700" : "text-ink-muted")}>
                  {k.d >= 0 ? <ArrowUpRight className="h-3.5 w-3.5" aria-hidden /> : <ArrowDownRight className="h-3.5 w-3.5" aria-hidden />}
                  {Math.abs(k.d)}%
                </span>
              </div>
              <p className="mt-3 text-2xl font-bold sm:text-3xl">
                <AnimatedNumber value={k.v} />
              </p>
              <p className="text-sm text-ink-muted">{k.l}</p>
            </Card>
          </FadeIn>
        ))}
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <Card className="p-6 lg:col-span-2">
          <CardHeader icon={TrendingUp} title="Aggregate wellbeing trend" subtitle="Average self-reported mood across consenting students (1–5)" />
          <div className="mt-4">
            <TrendChart label="Campus average mood by week" data={CAMPUS_WEEKLY} xKey="week" yDomain={[2.5, 4]} yTicks={[2.5, 3, 3.5, 4]} series={[{ key: "wellbeing", name: "Avg. mood", color: CHART.teal }]} tooltipFmt={(v) => v.toFixed(1)} height={250} />
          </div>
          <p className="mt-3 rounded-xl bg-mist p-3 text-sm text-ink-soft">
            <strong>Insight:</strong> mood dipped during the mid-semester assessment window (weeks of Aug 25 – Sep 01) and recovered afterwards. Consider extra counselor capacity and exam-support resources ahead of end-semester exams.
          </p>
        </Card>

        <Card className="p-6">
          <CardHeader title="Check-in volume" subtitle="Weekly · peak highlighted" />
          <div className="mt-4">
            <BarsChart label="Weekly check-ins" data={CAMPUS_WEEKLY} xKey="week" series={[{ key: "checkIns", name: "Check-ins", color: CHART.teal }]} highlightIndex={peak} height={250} />
          </div>
        </Card>

        <Card className="p-6">
          <CardHeader title="Common support categories" subtitle="% of check-ins mentioning each theme" />
          <div className="mt-4">
            <BarsChart label="Support categories" data={CAMPUS_CATEGORIES} xKey="name" horizontal series={[{ key: "value", name: "Share", color: CHART.blue }]} valueFmt={(v) => `${v}%`} height={270} />
          </div>
        </Card>

        <Card className="p-6">
          <CardHeader title="Resource usage" subtitle="Completed sessions" />
          <div className="mt-4">
            <BarsChart label="Resource usage" data={CAMPUS_RESOURCE_USAGE} xKey="name" horizontal series={[{ key: "sessions", name: "Sessions", color: CHART.teal }]} height={270} />
          </div>
        </Card>

        <Card className="p-6">
          <CardHeader title="Counselor bookings" subtitle="Weekly" />
          <div className="mt-4">
            <BarsChart label="Weekly counselor bookings" data={CAMPUS_WEEKLY} xKey="week" series={[{ key: "bookings", name: "Bookings", color: CHART.amber }]} height={270} />
          </div>
        </Card>

        <Card className="p-6 lg:col-span-2">
          <CardHeader icon={MessagesSquare} title="Anonymous feedback themes" subtitle="Grouped automatically · individual messages are not shown here" />
          <ul className="mt-4 divide-y divide-line">
            {FEEDBACK_THEMES.map((f) => (
              <li key={f.theme} className="flex items-center gap-3 py-3">
                <span className="flex-1 text-sm font-medium">{f.theme}</span>
                <span className="text-sm tabular-nums text-ink-muted">{f.count} mentions</span>
                <Badge tone={f.trend === "up" ? "amber" : f.trend === "down" ? "green" : "slate"} icon={f.trend === "up" ? ArrowUpRight : f.trend === "down" ? ArrowDownRight : ArrowRight}>
                  {f.trend === "up" ? "Rising" : f.trend === "down" ? "Easing" : "Stable"}
                </Badge>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="p-6">
          <CardHeader title="Participation by year" subtitle="% of cohort using CarePath" />
          <div className="mt-4">
            <BarsChart label="Participation by year of study" data={CAMPUS_BY_YEAR} xKey="group" series={[{ key: "participation", name: "Participation", color: CHART.violet }]} valueFmt={(v) => `${v}%`} height={200} />
          </div>
        </Card>
      </div>

      <Card className="mt-5 flex flex-col gap-4 bg-gradient-to-br from-white to-sea-50/60 p-6 sm:flex-row sm:items-center">
        <ShieldCheck className="h-8 w-8 shrink-0 text-sea-600" aria-hidden />
        <div>
          <p className="font-semibold">Privacy safeguards on this dashboard</p>
          <p className="mt-1 text-sm text-ink-muted">
            Only students who opted in contribute. Any group with fewer than {K_ANONYMITY_THRESHOLD} students is suppressed. No individual check-ins, chats, names or counselor notes are ever accessible to administrators.
          </p>
        </div>
      </Card>
    </StaffShell>
  );
}
