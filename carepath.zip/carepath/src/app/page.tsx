import { PublicFooter, PublicNav } from "@/components/landing/public-nav";
import { ClosingCTA, EcosystemSection, GapSection, Hero, PathwayStrip, SafetyPrivacySection, UniversitiesSection } from "@/components/landing/sections";

export default function Home() {
  return (
    <>
      <PublicNav />
      <main id="main">
        <Hero />
        <PathwayStrip />
        <GapSection />
        <EcosystemSection />
        <SafetyPrivacySection />
        <UniversitiesSection />
        <ClosingCTA />
      </main>
      <PublicFooter />
    </>
  );
}
