"use client";

import { motion } from "framer-motion";
import { Brain, Cloud, Database, FileCheck2, GraduationCap, KeyRound, Layers, Lock, MonitorSmartphone, Network, Server, ShieldCheck, Workflow, type LucideIcon } from "lucide-react";
import { PublicFooter, PublicNav } from "@/components/landing/public-nav";
import { RoadmapTimeline } from "@/components/landing/sections";
import { FadeIn } from "@/components/ui/motion";

const LAYERS: { icon: LucideIcon; t: string; s: string }[] = [
  { icon: GraduationCap, t: "Student", s: "Anonymous or university SSO" },
  { icon: MonitorSmartphone, t: "Web / Mobile App", s: "Responsive PWA, accessible by default" },
  { icon: Layers, t: "React / Next.js", s: "App Router, TypeScript, Tailwind" },
  { icon: Server, t: "Node.js / Express or FastAPI", s: "REST API · this prototype uses Next.js route handlers" },
  { icon: Brain, t: "AI / NLP Engine", s: "Safety screen → LLM or rule engine → non-diagnostic filter" },
  { icon: Workflow, t: "Wellness Assessment", s: "Conservative, rule-based support routing" },
  { icon: FileCheck2, t: "Authentication & Consent", s: "Versioned consent records, per-feature opt-ins" },
  { icon: Database, t: "PostgreSQL / Firebase", s: "Encrypted at rest, row-level security" },
  { icon: Network, t: "Counselor Portal + Resources + Safety Escalation", s: "Role-scoped views of the same platform" },
];

const PILLARS: [LucideIcon, string, string][] = [
  [Network, "REST APIs", "/api/chat, /api/check-in, /api/bookings, /api/feedback, /api/insights — swap in an external backend via NEXT_PUBLIC_API_BASE_URL."],
  [Cloud, "Cloud hosting", "Stateless frontend on any edge/cloud host; API and database in an India-region cloud for data residency."],
  [Lock, "Encryption", "TLS 1.2+ in transit, AES-256 at rest, field-level encryption for counselor notes."],
  [KeyRound, "RBAC", "Student, counselor and administrator roles with least-privilege, audited access."],
  [ShieldCheck, "Consent management", "Versioned consent with granular opt-ins; aggregates enforce k-anonymity (k ≥ 10)."],
];

const ENDPOINTS = [
  ["POST", "/api/chat", "Safety-screened assistant reply"],
  ["POST", "/api/check-in", "Support tier + resource suggestions"],
  ["GET", "/api/resources?q=&category=", "Search the library"],
  ["POST", "/api/bookings", "Validate slot & confirm session"],
  ["POST", "/api/feedback", "Anonymous feedback intake"],
  ["GET", "/api/insights", "Aggregated campus metrics only"],
];

export default function TechnologyPage() {
  return (
    <>
      <PublicNav />
      <main id="main" className="bg-hero -mt-16 pt-16">
        <section className="container max-w-5xl py-14">
          <FadeIn className="max-w-2xl">
            <p className="eyebrow">Technology</p>
            <h1 className="mt-2 text-3xl font-bold sm:text-5xl">Built to pilot on one campus and scale to many.</h1>
            <p className="mt-4 text-lg text-ink-muted">A modular architecture where safety and consent sit in the request path — not bolted on afterwards.</p>
          </FadeIn>

          <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1fr]">
            <ol className="relative" aria-label="System architecture, top to bottom">
              {LAYERS.map((l, i) => (
                <motion.li
                  key={l.t}
                  initial={{ opacity: 0, x: -12 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06 }}
                  className="relative pb-3 pl-14 last:pb-0"
                >
                  {i < LAYERS.length - 1 && <span className="absolute bottom-0 left-[21px] top-11 w-px bg-gradient-to-b from-sea-300 to-calm-200" aria-hidden />}
                  <span className="absolute left-0 top-0 grid h-11 w-11 place-items-center rounded-2xl border border-line bg-white text-sea-700 shadow-soft">
                    <l.icon className="h-5 w-5" aria-hidden />
                  </span>
                  <div className="glass rounded-2xl px-4 py-3">
                    <p className="font-semibold">{l.t}</p>
                    <p className="text-sm text-ink-muted">{l.s}</p>
                  </div>
                </motion.li>
              ))}
            </ol>

            <div className="space-y-4">
              {PILLARS.map(([Icon, t, b], i) => (
                <FadeIn key={t} delay={i * 0.05}>
                  <div className="card flex gap-4 p-5">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-sea-50 text-sea-700">
                      <Icon className="h-5 w-5" aria-hidden />
                    </span>
                    <div>
                      <p className="font-semibold">{t}</p>
                      <p className="mt-0.5 text-sm text-ink-muted">{b}</p>
                    </div>
                  </div>
                </FadeIn>
              ))}
              <FadeIn>
                <div className="card overflow-hidden">
                  <p className="border-b border-line px-5 py-3 text-sm font-semibold">API surface (prototype)</p>
                  <table className="w-full text-sm">
                    <tbody>
                      {ENDPOINTS.map(([m, p, d]) => (
                        <tr key={p} className="border-b border-line last:border-0">
                          <td className="px-5 py-2.5">
                            <span className="rounded-md bg-slate-100 px-1.5 py-0.5 font-mono text-[11px] font-bold text-ink-soft">{m}</span>
                          </td>
                          <td className="py-2.5 font-mono text-xs text-ink">{p}</td>
                          <td className="hidden px-5 py-2.5 text-ink-muted sm:table-cell">{d}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        <section className="border-t border-line bg-white py-16">
          <div className="container max-w-5xl">
            <FadeIn className="mb-8">
              <p className="eyebrow">Roadmap</p>
              <h2 className="mt-2 text-2xl font-bold sm:text-3xl">Four phases to a multi-university platform.</h2>
            </FadeIn>
            <RoadmapTimeline />
          </div>
        </section>
      </main>
      <PublicFooter />
    </>
  );
}
