import { NextResponse } from "next/server";
import { RESOURCES } from "@/lib/data/resources";

export function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") ?? "").toLowerCase();
  const category = searchParams.get("category");
  const results = RESOURCES.filter(
    (r) =>
      (!category || r.category === category) &&
      (!q || `${r.title} ${r.description} ${r.category}`.toLowerCase().includes(q)),
  );
  return NextResponse.json({ resources: results });
}
