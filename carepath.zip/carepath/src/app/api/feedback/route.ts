import { NextResponse } from "next/server";
import type { FeedbackItem } from "@/lib/types";
import { uid } from "@/lib/utils";

const items: FeedbackItem[] = [];

export async function POST(req: Request) {
  const b = (await req.json().catch(() => null)) as Partial<FeedbackItem> | null;
  if (!b?.message || b.message.trim().length < 5) {
    return NextResponse.json({ error: "Please write at least a few words." }, { status: 400 });
  }
  const item: FeedbackItem = {
    id: uid("fb"),
    kind: b.kind ?? "feedback",
    message: b.message.trim().slice(0, 2000),
    rating: b.rating,
    anonymous: b.anonymous !== false,
    createdAt: new Date().toISOString(),
  };
  // Anonymous submissions store no user identifier at all.
  items.push(item);
  return NextResponse.json({ ok: true, id: item.id }, { status: 201 });
}
