import { NextResponse } from "next/server";
import { getCounselor } from "@/lib/data/counselors";
import type { Booking } from "@/lib/types";
import { uid } from "@/lib/utils";

// In-memory store for the prototype. Replace with a DB repository.
const bookings: Booking[] = [];

export async function GET() {
  return NextResponse.json({ bookings });
}

export async function POST(req: Request) {
  const b = (await req.json().catch(() => null)) as Partial<Booking> | null;
  const counselor = b?.counselorId ? getCounselor(b.counselorId) : undefined;
  if (!b || !counselor || !b.date || !b.time || !b.sessionType) {
    return NextResponse.json({ error: "counselorId, date, time and sessionType are required" }, { status: 400 });
  }
  const slots = counselor.availability[b.date] ?? [];
  if (!slots.includes(b.time)) {
    return NextResponse.json({ error: "That slot is no longer available" }, { status: 409 });
  }
  const booking: Booking = {
    id: uid("bk"),
    counselorId: counselor.id,
    date: b.date,
    time: b.time,
    sessionType: b.sessionType,
    shareCheckInContext: Boolean(b.shareCheckInContext),
    reason: b.reason?.slice(0, 500),
    status: "confirmed",
    createdAt: new Date().toISOString(),
  };
  bookings.push(booking);
  return NextResponse.json({ booking }, { status: 201 });
}
