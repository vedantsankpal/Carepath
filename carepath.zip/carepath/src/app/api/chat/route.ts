import { NextResponse } from "next/server";
import { generateReply, type ChatTurn } from "@/lib/ai/assistant";

export async function POST(req: Request) {
  let body: { messages?: ChatTurn[] };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }
  const messages = (body.messages ?? []).filter(
    (m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string",
  );
  if (!messages.length || messages[messages.length - 1].role !== "user") {
    return NextResponse.json({ error: "Last message must be from the user" }, { status: 400 });
  }
  if (messages[messages.length - 1].content.length > 2000) {
    return NextResponse.json({ error: "Message too long" }, { status: 413 });
  }
  const reply = await generateReply(messages);
  // Conversations are not persisted server-side in this prototype.
  return NextResponse.json(reply);
}
