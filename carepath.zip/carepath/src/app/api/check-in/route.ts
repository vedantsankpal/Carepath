import { NextResponse } from "next/server";
import { assessSupportTier, recommendResources } from "@/lib/assessment";
import type { CheckIn, Intensity, MoodLevel, StressFactor } from "@/lib/types";

export async function POST(req: Request) {
  const b = (await req.json().catch(() => null)) as {
    mood?: number; intensity?: number; factors?: StressFactor[]; feelsUnsafe?: CheckIn["feelsUnsafe"]; recent?: CheckIn[];
  } | null;
  if (!b || !b.mood || !b.intensity || b.mood < 1 || b.mood > 5 || b.intensity < 1 || b.intensity > 5) {
    return NextResponse.json({ error: "mood and intensity (1–5) are required" }, { status: 400 });
  }
  const tier = assessSupportTier({
    mood: b.mood as MoodLevel,
    intensity: b.intensity as Intensity,
    feelsUnsafe: b.feelsUnsafe ?? null,
    recent: b.recent,
  });
  return NextResponse.json({ tier, resources: recommendResources(b.factors ?? ["general"]).map((r) => r.id) });
}
