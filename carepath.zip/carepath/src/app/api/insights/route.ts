import { NextResponse } from "next/server";
import * as agg from "@/lib/data/institution";

/** Aggregated, anonymised campus insights only — no per-student records. */
export function GET() {
  return NextResponse.json({
    kAnonymity: agg.K_ANONYMITY_THRESHOLD,
    overview: agg.CAMPUS_OVERVIEW,
    weekly: agg.CAMPUS_WEEKLY,
    categories: agg.CAMPUS_CATEGORIES,
    resources: agg.CAMPUS_RESOURCE_USAGE,
  });
}
