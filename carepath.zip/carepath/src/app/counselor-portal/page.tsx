"use client";

import { AlertTriangle, CalendarClock, Check, ClipboardList, EyeOff, FileText, Inbox, Lock, MapPin, MessageSquare, Save, Video } from "lucide-react";
import { useMemo, useState } from "react";
import { StaffShell } from "@/components/shell/staff-shell";
import { Badge, Button, Card, CardHeader, EmptyState } from "@/components/ui";
import { getCounselor } from "@/lib/data/counselors";
import { COUNSELOR_APPOINTMENTS, COUNSELOR_REQUESTS } from "@/lib/data/institution";
import { useApp } from "@/lib/store";
import { cn, formatDate, formatTime } from "@/lib/utils";
import { summary, topFactors } from "@/lib/wellness";
import { FACTORS } from "@/lib/assessment";

type Req = (typeof COUNSELOR_REQUESTS)[number];

export default function CounselorPortal() {
  const { bookings, checkIns, hydrated } = useApp();
  const today = hydrated ? new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" }) : "";
  const [tab, setTab] = useState<"all" | "priority">("all");
  const [accepted, setAccepted] = useState<string[]>([]);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState<string | null>(null);

  // Bookings made in the student app in this browser appear as live requests (pseudonymised).
  const live: Req[] = useMemo(
    () =>
      bookings
        .filter((b) => b.status === "confirmed" && b.id !== "demo_bk_1")
        .map((b) => {
          const s = summary(checkIns, 7);
          const themes = topFactors(checkIns.slice(-7), 2).map(([f]) => FACTORS.find((x) => x.value === f)?.label ?? f);
          return {
            id: `S-${b.id.slice(-4).toUpperCase()}`,
            requested: "Just now",
            preferred: `${b.sessionType} · ${formatDate(b.date)} ${formatTime(b.time)} with ${getCounselor(b.counselorId)?.name.split(" ").slice(-1)[0]}`,
            priority: (checkIns[checkIns.length - 1]?.tier === "concerning" ? "priority" : "standard") as "priority" | "standard",
            context: b.shareCheckInContext
              ? { sharing: true, recentTrend: s.moodAvg ? `Avg. self-reported mood ${s.moodAvg.toFixed(1)}/5 over ${s.count} check-ins` : "No recent check-ins", themes, note: b.reason ? `Student note: “${b.reason}”` : "Booked via Counselor Connect." }
              : { sharing: false, recentTrend: "", themes: [], note: "Student chose not to share check-in context." },
          };
        }),
    [bookings, checkIns],
  );

  const requests = [...live, ...COUNSELOR_REQUESTS].filter((r) => tab === "all" || r.priority === "priority");
  const [selId, setSelId] = useState<string | null>(null);
  const sel = requests.find((r) => r.id === selId) ?? requests[0];
  const priorityCount = [...live, ...COUNSELOR_REQUESTS].filter((r) => r.priority === "priority").length;

  return (
    <StaffShell role="counselor">
      <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="eyebrow">Counselor portal</p>
          <h1 className="mt-1 text-2xl font-bold sm:text-[28px]">Good day, Dr. Rao</h1>
          <p className="mt-1 min-h-5 text-sm text-ink-muted" suppressHydrationWarning>{today}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { l: "Today’s sessions", v: COUNSELOR_APPOINTMENTS.length, i: CalendarClock },
          { l: "New requests", v: live.length + COUNSELOR_REQUESTS.length - accepted.length, i: Inbox },
          { l: "Priority cases", v: priorityCount, i: AlertTriangle },
          { l: "Notes to complete", v: 2, i: FileText },
        ].map((s) => (
          <Card key={s.l} className="p-5">
            <s.i className="h-5 w-5 text-sea-600" aria-hidden />
            <p className="mt-3 text-2xl font-bold tabular-nums">{s.v}</p>
            <p className="text-sm text-ink-muted">{s.l}</p>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-[1fr_1.3fr]">
        <div className="space-y-5">
          <Card className="p-5">
            <CardHeader icon={CalendarClock} title="Upcoming appointments" subtitle="Today" />
            <ul className="mt-4 divide-y divide-line">
              {COUNSELOR_APPOINTMENTS.map((a) => {
                const I = a.type === "Video" ? Video : a.type === "Chat" ? MessageSquare : MapPin;
                return (
                  <li key={a.id} className="flex items-center gap-3 py-3">
                    <span className="w-16 text-sm font-semibold tabular-nums">{formatTime(a.time)}</span>
                    <span className="flex-1">
                      <span className="block text-sm font-medium">{a.student}</span>
                      <span className="block text-xs text-ink-muted">{a.topic}</span>
                    </span>
                    <Badge tone="slate" icon={I}>
                      {a.type}
                    </Badge>
                  </li>
                );
              })}
            </ul>
          </Card>

          <Card className="p-5">
            <CardHeader
              icon={Inbox}
              title="Requests"
              action={
                <div className="flex rounded-lg bg-slate-100 p-0.5 text-xs font-semibold" role="tablist">
                  {(["all", "priority"] as const).map((t) => (
                    <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={cn("rounded-md px-2.5 py-1 capitalize", tab === t ? "bg-white shadow-soft" : "text-ink-muted")}>
                      {t}
                    </button>
                  ))}
                </div>
              }
            />
            <ul className="mt-4 space-y-2">
              {requests.map((r) => (
                <li key={r.id}>
                  <button onClick={() => setSelId(r.id)} className={cn("flex w-full items-center gap-3 rounded-2xl border p-3 text-left transition", sel?.id === r.id ? "border-sea-300 bg-sea-50/60" : "border-line hover:bg-slate-50")}>
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-slate-100 text-xs font-bold text-ink-soft">{r.id.slice(2, 4)}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-semibold">{r.id}</span>
                      <span className="block truncate text-xs text-ink-muted">{r.preferred}</span>
                    </span>
                    {accepted.includes(r.id) ? <Badge tone="green" icon={Check}>Scheduled</Badge> : r.priority === "priority" ? <Badge tone="amber">Priority</Badge> : <Badge tone="slate">{r.requested}</Badge>}
                  </button>
                </li>
              ))}
            </ul>
          </Card>
        </div>

        <Card className="p-6">
          {!sel ? (
            <EmptyState icon={Inbox} title="No requests" body="New requests will appear here." />
          ) : (
            <>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-ink-faint">Request</p>
                  <h2 className="text-xl font-bold">{sel.id}</h2>
                  <p className="text-sm text-ink-muted">
                    Requested {sel.requested} · {sel.preferred}
                  </p>
                </div>
                {sel.priority === "priority" && <Badge tone="amber" icon={AlertTriangle}>Priority — respond within 24h</Badge>}
              </div>

              <div className="mt-5 rounded-2xl border border-line p-4">
                <p className="flex items-center gap-2 text-sm font-semibold">
                  <ClipboardList className="h-4 w-4 text-sea-600" aria-hidden /> Student check-in context
                </p>
                {sel.context.sharing ? (
                  <div className="mt-3 space-y-2 text-sm">
                    <p className="text-ink-soft">{sel.context.recentTrend}</p>
                    {sel.context.themes.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {sel.context.themes.map((t) => (
                          <Badge key={t} tone="sea">
                            {t}
                          </Badge>
                        ))}
                      </div>
                    )}
                    <p className="text-ink-muted">{sel.context.note}</p>
                  </div>
                ) : (
                  <p className="mt-3 flex items-center gap-2 text-sm text-ink-muted">
                    <EyeOff className="h-4 w-4" aria-hidden /> {sel.context.note}
                  </p>
                )}
                <p className="mt-3 flex items-center gap-1.5 border-t border-line pt-3 text-xs text-ink-muted">
                  <Lock className="h-3 w-3" aria-hidden /> Name, contact details and AI conversations are not visible. Identity is revealed only at the session, by the student.
                </p>
              </div>

              <label htmlFor="notes" className="label mt-5">
                Session notes <span className="font-normal text-ink-muted">(private to counselors · encrypted)</span>
              </label>
              <textarea
                id="notes"
                rows={6}
                value={notes[sel.id] ?? ""}
                onChange={(e) => setNotes((n) => ({ ...n, [sel.id]: e.target.value }))}
                className="input resize-none"
                placeholder="Presenting concerns, agreed next steps, follow-up plan…"
              />
              <div className="mt-4 flex flex-col-reverse gap-2 sm:flex-row sm:justify-between">
                <Button
                  variant="outline"
                  icon={Save}
                  onClick={() => {
                    setSaved(sel.id);
                    setTimeout(() => setSaved(null), 1800);
                  }}
                >
                  {saved === sel.id ? "Saved" : "Save note"}
                </Button>
                <Button icon={Check} disabled={accepted.includes(sel.id)} onClick={() => setAccepted((a) => [...a, sel.id])}>
                  {accepted.includes(sel.id) ? "Session scheduled" : "Accept & schedule"}
                </Button>
              </div>
            </>
          )}
        </Card>
      </div>
    </StaffShell>
  );
}
