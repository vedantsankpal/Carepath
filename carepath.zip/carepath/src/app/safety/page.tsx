"use client";

import { motion } from "framer-motion";
import { ArrowRight, BookOpen, CalendarCheck, HeartHandshake, Info, LifeBuoy, MessageCircleHeart, Phone, ShieldCheck, Users, Wind } from "lucide-react";
import Link from "next/link";
import { PublicFooter, PublicNav } from "@/components/landing/public-nav";
import { Badge, Button } from "@/components/ui";
import { FadeIn } from "@/components/ui/motion";
import { HELP_CONTACTS, HELP_CONTACTS_NOTE, PRINCIPLE } from "@/lib/config";
import { cn } from "@/lib/utils";

const TIERS = [
  {
    level: "Low / Moderate",
    signal: "Everyday stress, low mood on some days",
    response: "Self-help + resources",
    actions: [
      { href: "/resources", label: "Self-help resources", icon: BookOpen },
      { href: "/assistant", label: "AI wellness assistant", icon: MessageCircleHeart },
    ],
    ring: "ring-sea-200",
    head: "bg-sea-50 text-sea-900",
    dot: "bg-sea-500",
  },
  {
    level: "Concerning signals",
    signal: "Persistent low mood, feeling unable to cope, ‘not sure’ on safety",
    response: "Counselor / human support",
    actions: [
      { href: "/counselor", label: "Book a counselor", icon: CalendarCheck },
      { href: "/counselor?urgent=1", label: "Request a callback", icon: Phone },
    ],
    ring: "ring-amber-200",
    head: "bg-amber-50 text-amber-900",
    dot: "bg-amber-500",
  },
  {
    level: "Immediate safety concern",
    signal: "Thoughts of self-harm or feeling unsafe right now",
    response: "Emergency support pathway",
    actions: [{ href: "#contacts", label: "Contact help now", icon: LifeBuoy }],
    ring: "ring-rose-200",
    head: "bg-rose-50 text-rose-900",
    dot: "bg-rose-500",
  },
];

export default function SafetyPage() {
  return (
    <>
      <PublicNav />
      <main id="main" className="bg-hero -mt-16 pt-16">
        <div className="container max-w-5xl py-10 sm:py-14">
          {/* Immediate help — first thing on the page */}
          <FadeIn>
            <section id="contacts" aria-labelledby="help-now" className="scroll-mt-24 rounded-[28px] border border-rose-100 bg-white p-6 shadow-lift sm:p-9">
              <div className="flex flex-col gap-6 lg:flex-row lg:items-start">
                <div className="lg:w-[38%]">
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-rose-50 text-rose-700">
                    <LifeBuoy className="h-6 w-6" aria-hidden />
                  </span>
                  <h1 id="help-now" className="mt-4 text-2xl font-bold sm:text-3xl">
                    You don’t have to go through this alone.
                  </h1>
                  <p className="mt-2 text-ink-muted">If you feel unsafe or might act on thoughts of harming yourself, please reach out to someone right now. If you are in immediate danger, call emergency services.</p>
                  <div className="mt-5 flex items-center gap-3 rounded-2xl bg-mist p-4">
                    <Wind className="h-5 w-5 shrink-0 text-sea-600" aria-hidden />
                    <p className="text-sm text-ink-soft">While you reach out: breathe in for 4, out for 6. Stay near someone you trust if you can.</p>
                  </div>
                </div>
                <div className="flex-1">
                  <ul className="grid gap-3 sm:grid-cols-2">
                    {HELP_CONTACTS.map((c) => (
                      <li key={c.id}>
                        <a href={`tel:${c.phone}`} className={cn("flex h-full flex-col rounded-2xl border p-5 transition hover:-translate-y-0.5 hover:shadow-lift", c.kind === "emergency" ? "border-rose-200 bg-rose-50/60" : "border-line bg-white")}>
                          <div className="flex items-center justify-between">
                            <Badge tone={c.kind === "emergency" ? "rose" : c.kind === "helpline" ? "calm" : "slate"}>{c.kind === "emergency" ? "Emergency" : c.kind === "helpline" ? "Helpline" : "Campus"}</Badge>
                            <span className="text-xs text-ink-muted">{c.hours}</span>
                          </div>
                          <p className="mt-3 font-semibold">{c.name}</p>
                          <p className="mt-0.5 flex-1 text-sm text-ink-muted">{c.description}</p>
                          <p className="mt-3 inline-flex items-center gap-2 text-lg font-bold tabular-nums text-ink">
                            <Phone className="h-4 w-4 text-rose-700" aria-hidden /> {c.phone}
                          </p>
                        </a>
                      </li>
                    ))}
                  </ul>
                  <p className="mt-3 flex items-start gap-1.5 text-xs text-ink-muted">
                    <Info className="mt-px h-3.5 w-3.5 shrink-0" aria-hidden /> {HELP_CONTACTS_NOTE} National numbers should be re-verified by the institution before deployment.
                  </p>
                </div>
              </div>
            </section>
          </FadeIn>

          {/* Escalation model */}
          <section className="mt-14" aria-labelledby="model">
            <FadeIn>
              <p className="eyebrow">Safety escalation</p>
              <h2 id="model" className="mt-2 text-2xl font-bold sm:text-3xl">The right level of support, every time.</h2>
              <p className="mt-2 max-w-2xl text-ink-muted">CarePath uses conservative rules to decide which kind of help to offer. When in doubt, it always routes toward people.</p>
            </FadeIn>
            <div className="relative mt-8 grid gap-4 md:grid-cols-3">
              {TIERS.map((t, i) => (
                <FadeIn key={t.level} delay={i * 0.08}>
                  <div className={cn("relative flex h-full flex-col overflow-hidden rounded-3xl bg-white shadow-soft ring-1", t.ring)}>
                    <div className={cn("px-5 py-4", t.head)}>
                      <p className="flex items-center gap-2 text-sm font-bold">
                        <span className={cn("h-2.5 w-2.5 rounded-full", t.dot)} aria-hidden /> {t.level}
                      </p>
                    </div>
                    <div className="flex flex-1 flex-col p-5">
                      <p className="text-xs font-semibold uppercase tracking-wide text-ink-faint">When</p>
                      <p className="mt-1 text-sm text-ink-soft">{t.signal}</p>
                      <p className="mt-4 text-xs font-semibold uppercase tracking-wide text-ink-faint">Response</p>
                      <p className="mt-1 flex items-center gap-1.5 font-semibold">
                        <ArrowRight className="h-4 w-4 text-ink-faint" aria-hidden /> {t.response}
                      </p>
                      <div className="mt-5 flex flex-1 flex-col justify-end gap-2">
                        {t.actions.map((a) => (
                          <Link key={a.href} href={a.href} className="flex items-center gap-2 rounded-xl border border-line px-3 py-2.5 text-sm font-medium text-ink-soft transition hover:bg-slate-50">
                            <a.icon className="h-4 w-4" aria-hidden /> {a.label}
                          </Link>
                        ))}
                      </div>
                    </div>
                  </div>
                </FadeIn>
              ))}
            </div>
            <motion.p initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="mt-8 flex items-center justify-center gap-2 rounded-2xl bg-white/80 px-5 py-4 text-center text-sm font-semibold text-ink-soft ring-1 ring-line">
              <ShieldCheck className="h-5 w-5 text-sea-600" aria-hidden /> {PRINCIPLE}
            </motion.p>
          </section>

          {/* Human in the loop */}
          <section className="mt-14 grid gap-4 md:grid-cols-3" aria-label="How humans stay involved">
            {[
              { icon: HeartHandshake, t: "Counselors review escalations", b: "Concerning check-ins that students choose to share appear in the counselor portal’s priority queue." },
              { icon: Users, t: "Institution-approved contacts", b: "Every number on this page is configured and verified by the university’s wellbeing team." },
              { icon: ShieldCheck, t: "No automated decisions about people", b: "The system only chooses which support to show. It never labels, reports or diagnoses a student." },
            ].map((x) => (
              <div key={x.t} className="card p-5">
                <x.icon className="h-5 w-5 text-sea-600" aria-hidden />
                <p className="mt-3 font-semibold">{x.t}</p>
                <p className="mt-1 text-sm text-ink-muted">{x.b}</p>
              </div>
            ))}
          </section>
          <div className="mt-10 text-center">
            <Button href="/dashboard" variant="outline">
              Back to my dashboard
            </Button>
          </div>
        </div>
      </main>
      <PublicFooter />
    </>
  );
}
