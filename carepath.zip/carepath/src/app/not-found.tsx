import Link from "next/link";

export default function NotFound() {
  return (
    <main id="main" className="bg-hero flex min-h-screen items-center justify-center p-6 text-center">
      <div className="glass max-w-md rounded-[28px] p-10">
        <p className="eyebrow">404</p>
        <h1 className="mt-2 text-2xl font-bold">This page took a mindful break.</h1>
        <p className="mt-2 text-sm text-ink-muted">The page you’re looking for doesn’t exist. Let’s get you back on the path.</p>
        <div className="mt-6 flex justify-center gap-2">
          <Link href="/" className="rounded-xl border border-line bg-white px-4 py-2.5 text-sm font-semibold">Home</Link>
          <Link href="/dashboard" className="rounded-xl bg-sea-600 px-4 py-2.5 text-sm font-semibold text-white">Dashboard</Link>
        </div>
      </div>
    </main>
  );
}
