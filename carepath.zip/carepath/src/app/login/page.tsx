"use client";

import { ArrowLeft, EyeOff, Lock, Mail, PlayCircle, ShieldCheck, User } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";
import { Button, Logo } from "@/components/ui";
import { ConsentModal } from "@/components/app/consent-modal";
import { useApp } from "@/lib/store";
import { APP } from "@/lib/config";
import { cn, sleep } from "@/lib/utils";

function LoginInner() {
  const { signIn, startDemo, advanceDemo } = useApp();
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || "/dashboard";
  const [tab, setTab] = useState<"signin" | "signup">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState<"form" | "anon" | null>(null);
  const [consentOpen, setConsentOpen] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (tab === "signup" && name.trim().length < 2) e.name = "Please enter a first name or nickname.";
    if (!/^\S+@\S+\.\S+$/.test(email)) e.email = "Enter a valid email address.";
    if (password.length < 8) e.password = "Use at least 8 characters.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setLoading("form");
    await sleep(700);
    signIn({ mode: "account", displayName: tab === "signup" ? name.trim() : email.split("@")[0].replace(/[._]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()), email, institution: APP.institution });
    setLoading(null);
    setConsentOpen(true);
  };

  const anonymous = async () => {
    setLoading("anon");
    await sleep(500);
    signIn({ mode: "anonymous", displayName: "Friend" });
    setLoading(null);
    setConsentOpen(true);
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1.05fr]">
      <main id="main" className="flex flex-col px-5 py-6 sm:px-10">
        <div className="flex items-center justify-between">
          <Link href="/" aria-label="Back to home">
            <Logo />
          </Link>
          <Link href="/" className="inline-flex items-center gap-1 text-sm text-ink-muted hover:text-ink">
            <ArrowLeft className="h-4 w-4" aria-hidden /> Home
          </Link>
        </div>

        <div className="mx-auto flex w-full max-w-[420px] flex-1 flex-col justify-center py-10">
          <h1 className="text-[28px] font-bold">{tab === "signin" ? "Welcome back" : "Create your private space"}</h1>
          <p className="mt-1.5 text-ink-muted">Everything you share here is private to you by default.</p>

          <Button variant="outline" size="lg" className="mt-7 w-full" icon={EyeOff} loading={loading === "anon"} onClick={anonymous}>
            Continue anonymously
          </Button>
          <p className="mt-2 text-center text-xs text-ink-muted">No name or email needed. Your data stays on this device.</p>

          <div className="my-6 flex items-center gap-3 text-xs text-ink-faint">
            <span className="h-px flex-1 bg-line" /> or use your university email <span className="h-px flex-1 bg-line" />
          </div>

          <div role="tablist" aria-label="Account" className="mb-5 grid grid-cols-2 rounded-xl bg-slate-100 p-1">
            {(["signin", "signup"] as const).map((t) => (
              <button
                key={t}
                role="tab"
                aria-selected={tab === t}
                onClick={() => {
                  setTab(t);
                  setErrors({});
                }}
                className={cn("rounded-lg py-2 text-sm font-semibold transition", tab === t ? "bg-white text-ink shadow-soft" : "text-ink-muted")}
              >
                {t === "signin" ? "Sign in" : "Sign up"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} noValidate className="space-y-4">
            {tab === "signup" && (
              <Field id="name" label="First name or nickname" icon={User} value={name} onChange={setName} error={errors.name} autoComplete="given-name" />
            )}
            <Field id="email" label="University email" icon={Mail} type="email" value={email} onChange={setEmail} error={errors.email} autoComplete="email" placeholder="you@university.edu" />
            <Field id="password" label="Password" icon={Lock} type="password" value={password} onChange={setPassword} error={errors.password} autoComplete={tab === "signin" ? "current-password" : "new-password"} />
            <Button type="submit" size="lg" className="w-full" loading={loading === "form"}>
              {tab === "signin" ? "Sign in" : "Create account"}
            </Button>
          </form>

          <button
            onClick={() => {
              startDemo();
              advanceDemo(1);
              router.push("/dashboard");
            }}
            className="mt-6 inline-flex items-center justify-center gap-2 rounded-xl bg-lav-50 px-4 py-3 text-sm font-semibold text-[#4b3f8f] ring-1 ring-lav-200 transition hover:bg-lav-100"
          >
            <PlayCircle className="h-4 w-4" aria-hidden /> Judges: try Demo Mode with sample student data
          </button>
        </div>
        <p className="text-center text-xs text-ink-muted">Prototype authentication — no data leaves your browser.</p>
      </main>

      <aside className="bg-hero relative hidden overflow-hidden lg:block" aria-hidden>
        <div className="absolute inset-0 flex items-center justify-center p-12">
          <div className="glass max-w-md rounded-[32px] p-9">
            <ShieldCheck className="h-8 w-8 text-sea-600" />
            <p className="mt-6 font-display text-3xl leading-snug">“Reaching out is a sign of strength, not weakness.”</p>
            <div className="mt-8 space-y-3 text-sm text-ink-soft">
              {["Private by default — you choose what to share", "AI support that never diagnoses", "Real counselors when you want them"].map((t) => (
                <p key={t} className="flex items-center gap-2.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-sea-500" /> {t}
                </p>
              ))}
            </div>
          </div>
        </div>
      </aside>

      <ConsentModal
        open={consentOpen}
        onDone={() => {
          setConsentOpen(false);
          advanceDemo(1);
          router.push(next);
        }}
      />
    </div>
  );
}

function Field({ id, label, icon: Icon, value, onChange, error, type = "text", autoComplete, placeholder }: { id: string; label: string; icon: typeof Mail; value: string; onChange: (v: string) => void; error?: string; type?: string; autoComplete?: string; placeholder?: string }) {
  return (
    <div>
      <label htmlFor={id} className="label">
        {label}
      </label>
      <div className="relative">
        <Icon className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-faint" aria-hidden />
        <input
          id={id}
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoComplete={autoComplete}
          placeholder={placeholder}
          aria-invalid={!!error}
          aria-describedby={error ? `${id}-err` : undefined}
          className={cn("input pl-10", error && "border-rose-300 focus:border-rose-400 focus:ring-rose-500/15")}
        />
      </div>
      {error && (
        <p id={`${id}-err`} className="mt-1.5 text-xs font-medium text-rose-700">
          {error}
        </p>
      )}
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginInner />
    </Suspense>
  );
}
