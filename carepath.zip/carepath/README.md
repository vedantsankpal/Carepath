# CarePath — Digital Mental Health & Psychological Support for Students

> Detect early. Support instantly. Connect when it matters.

A working hackathon prototype of an AI-assisted, human-centered, privacy-first support platform for students in higher education. One ecosystem connects **Student → AI assistance → Resources → Counselor → Safety escalation**.

*Technology can't replace human care — but it can help students reach it sooner.*

## Quick start

```bash
npm install
npm run dev          # http://localhost:3000
# or a production build
npm run build && npm start
```

Requires Node 18.18+ (tested on Node 22). No API keys or database needed — everything runs on mock data.

**Fastest demo:** open `/login` → **“Judges: try Demo Mode”**. This loads a sample student (Aarav) with 30 days of history and shows a 9-step demo guide in the corner.

## Demo journey (≈3 minutes)

1. `/login` — continue anonymously or sign in → consent step
2. `/check-in` — mood → stressors → intensity + safety question
3. Get a support recommendation (try intensity 5 + “Low”, or answer “Yes” to the safety question to see escalation)
4. Open a recommended resource (the breathing exercise has a guided animation)
5. `/assistant` — use a quick prompt, or type *“I have been feeling overwhelmed with college lately.”*
6. Tap **Connect with a Counselor**
7. `/counselor` — pick a counselor → date → time → confirm
8. `/wellness` — trends, consistency, what has helped
9. Staff views: `/counselor-portal` (your booking appears as a pseudonymous request) and `/university` (aggregates only)

## Pages

| Route | What it is |
|---|---|
| `/` | Landing: hero dashboard preview, support pathway, the gap, 7-module ecosystem, safety & privacy, universities, roadmap |
| `/login` | Sign in / sign up / continue anonymously + consent modal |
| `/dashboard` | Student dashboard: today's check-in, wellness trend (7d/30d), quick support, recommendations, upcoming session, privacy summary |
| `/assistant` | AI Wellness Assistant (chat, typing indicator, quick prompts, safety cards, persistent disclaimer) |
| `/check-in` | 4-step check-in with support routing (low / moderate / concerning / immediate) |
| `/resources` | Searchable, filterable library with a step-by-step player |
| `/counselor` | Counselor cards + booking flow + confirmation + manage/cancel |
| `/wellness` | Personal analytics: mood/stress trend, consistency, support usage, resource engagement, themes |
| `/feedback` | Anonymous feedback (general, campus concern, resource suggestion, counselor rating) |
| `/privacy` | Privacy Center: consent toggles, who-sees-what, export / delete data |
| `/safety` | Crisis escalation pathway + configurable help contacts (public, no login required) |
| `/counselor-portal` | Counselor dashboard: appointments, requests, priority, consented context, session notes |
| `/university` | Aggregated campus insights (k-anonymity, sample data) |
| `/technology` | Architecture, API surface, roadmap |

## Connecting a real LLM (optional)

Copy `.env.example` to `.env.local` and set `ANTHROPIC_API_KEY` (and optionally `AI_MODEL`). Without a key the deterministic mock engine answers. Either way:

1. Every message is safety-screened **before** any model call (`src/lib/ai/safety.ts`).
2. Immediate-risk messages always get a fixed, reviewed escalation response — never model-generated text.
3. Replies are post-filtered to remove diagnostic language.

## Configure help contacts

Edit `src/lib/config.ts → HELP_CONTACTS`. Campus numbers ship as `00000` placeholders; national numbers (112, Tele-MANAS 14416) must be re-verified by the institution before deployment.

## Project structure

```
src/
  app/
    page.tsx                 landing
    login/ safety/ technology/ university/ counselor-portal/
    (student)/               gated student app (shell with sidebar + mobile bottom nav)
      dashboard/ assistant/ check-in/ resources/ counselor/ wellness/ feedback/ privacy/ settings/
    api/                     REST route handlers: chat, check-in, bookings, feedback, resources, insights
  components/
    ui/                      Button, Card, Badge, Modal, Switch, motion helpers, toasts
    charts/                  Recharts wrappers (validated colour-blind-safe palette)
    landing/  shell/  app/   feature components (consent modal, resource player, demo guide)
  lib/
    types.ts                 domain models (DB-ready)
    config.ts                app + help-contact configuration
    assessment.ts            support-tier routing rules (non-diagnostic)
    ai/                      safety screen, mock engine, provider adapter
    services/api.ts          client service layer (swap BASE_URL for an external backend)
    store.tsx                client state (localStorage-persisted for the demo)
    data/                    mock resources, counselors, demo history, institution aggregates
```

See `docs/ARCHITECTURE.md` for the backend/data plan.

## Principles

- **AI-assisted, never diagnostic.** The system only decides which *kind* of support to offer.
- **Human-centered.** Concerning signals route to counselors; immediate concerns to emergency and human support.
- **Privacy-first.** Anonymous mode, granular consent, aggregated-only institutional views, export/delete.

*Prototype only — not a medical device. Sample data throughout.*
