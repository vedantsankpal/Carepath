# CarePath — Architecture

```
Student
  ↓
Web / Mobile app (Next.js, React, TypeScript, Tailwind)
  ↓  src/lib/services/api.ts  (NEXT_PUBLIC_API_BASE_URL)
REST API  (today: Next.js route handlers · later: Node/Express or FastAPI)
  ├─ AI / NLP engine         safety screen → LLM or rules → non-diagnostic filter
  ├─ Wellness assessment     rule-based support-tier routing
  ├─ Auth & consent          SSO / anonymous, versioned consent records
  └─ Data                    PostgreSQL (or Firebase)
  ↓
Counselor portal · Resources · Safety escalation · University insights
```

## Moving to a real backend

All UI calls go through `src/lib/services/api.ts`. Point `NEXT_PUBLIC_API_BASE_URL` at an external service implementing the same contracts:

| Method | Path | Body → Response |
|---|---|---|
| POST | `/chat` | `{messages:[{role,content}]}` → `{content, tier, suggestions[]}` |
| POST | `/check-in` | `{mood, intensity, factors[], feelsUnsafe, recent[]}` → `{tier, resources[]}` |
| GET | `/resources?q=&category=` | → `{resources[]}` |
| POST | `/bookings` | `{counselorId, date, time, sessionType, shareCheckInContext, reason?}` → `{booking}` (409 if slot taken) |
| POST | `/feedback` | `{kind, message, rating?, anonymous}` → `{ok, id}` |
| GET | `/insights` | → aggregated campus metrics only |

## Suggested PostgreSQL schema

```sql
users(id uuid pk, role text check (role in ('student','counselor','university_admin')),
      mode text, display_name text, email_hash text, institution_id uuid, created_at timestamptz)
consents(id uuid pk, user_id uuid fk, version text, ai_not_replacement bool, data_processing bool,
         share_with_counselor bool, anonymous_analytics bool, accepted_at timestamptz)
check_ins(id uuid pk, user_id uuid fk, mood smallint, intensity smallint, factors text[],
          feels_unsafe text, note_encrypted bytea, tier text, created_at timestamptz)
bookings(id uuid pk, user_id uuid fk, counselor_id uuid fk, starts_at timestamptz, session_type text,
         share_context bool, reason_encrypted bytea, status text)
session_notes(id uuid pk, booking_id uuid fk, counselor_id uuid fk, body_encrypted bytea, updated_at timestamptz)
feedback(id uuid pk, kind text, message text, rating smallint, created_at timestamptz)  -- no user_id when anonymous
resources(id text pk, title text, category text, minutes int, format text, steps jsonb)
```

## Security & privacy controls

- **Encryption:** TLS in transit; AES-256 at rest; field-level encryption for notes and free text.
- **RBAC + row-level security:** students read only their rows; counselors read bookings assigned to them and check-in *summaries* only when `share_context = true`; admins query aggregate views only.
- **k-anonymity:** aggregate views suppress groups with fewer than 10 students (`K_ANONYMITY_THRESHOLD`).
- **AI data:** conversations are not persisted server-side in the prototype; production should store them only with explicit opt-in and never use them for training.
- **Audit:** every counselor/admin read is logged.

## Safety design

- Screening runs on every chat message and every check-in, before any model call.
- Tiers: `low` / `moderate` → self-help; `concerning` → counselor first; `immediate` → emergency pathway with institution-configured contacts.
- Immediate-tier responses are fixed text reviewed by clinicians, never generated.
- Thresholds in `src/lib/assessment.ts` are conservative placeholders and must be reviewed by the partner institution's clinical team before any pilot.
